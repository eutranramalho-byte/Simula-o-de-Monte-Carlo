%% ========================================================================
%  ANÁLISE DE SENSIBILIDADE COMPLEMENTAR
%  Dois grupos de sensibilidade, tratados de forma compacta (1 figura +
%  1 tabela) para respeitar o limite de páginas do manuscrito:
%
%  GRUPO 1 - Horário médio de início da recarga lenta (EL):
%    Casos 8,9,10,6,4,7,5 -> horas médias 1h,2h,3h,16h,18h,19h,23h
%    (Caso 4 = baseline já simulado; Caso 5 = já simulado, EL 23h)
%
%  GRUPO 2 - Migração de VEs de EL para ER (ES fixo em 18%):
%    Casos 4,11,12,13,14 -> %ER = 12,17,22,27,32 (%EL = 70,65,60,55,50)
%    (Caso 4 = baseline já simulado, 70% EL / 18% ES / 12% ER)
%
%  Para "transformadores sobrecarregados", usa-se o PICO DO DIA POR
%  ITERAÇÃO (não uma hora fixa como 19h), pois o horário de maior
%  sobrecarga se desloca conforme o horário médio de recarga muda.
% ========================================================================
clear; clc; close all;
tam = 20; % Tamanho da fonte

Ali = 'JMLT308';
pastaBase = 'D:\1_UFOP\ELÉTRICA\9º periodo\TCC 1\Monte Carlo\Resultados';

%% ========================================================================
%  GRUPO 1 - HORÁRIO MÉDIO DE RECARGA LENTA (EL)
% ========================================================================
casosGrupo1 = [8, 9, 10, 6, 4, 7, 5];
horasGrupo1 = [1, 2, 3, 16, 18, 21, 23]; % correspondência direta com casosGrupo1
nCasos1 = length(casosGrupo1);

Media_Tensao_G1  = NaN(nCasos1,1);
IC_Inf_Tensao_G1 = NaN(nCasos1,1);
IC_Sup_Tensao_G1 = NaN(nCasos1,1);
Media_Trafo_G1   = NaN(nCasos1,1);
IC_Inf_Trafo_G1  = NaN(nCasos1,1);
IC_Sup_Trafo_G1  = NaN(nCasos1,1);

for i = 1:nCasos1
    pastaCaso = sprintf('%s\\caso%d\\Dados_Alimentador%s', pastaBase, casosGrupo1(i), Ali);

    % --- Tensão mínima diária (BT) ---
    BT_iter = open(fullfile(pastaCaso,'Tensao_minima_diaria_BT.mat')).Tensao_minima_diaria_BT;
    [m, ~, ~, ic_inf, ic_sup] = calcula_estatisticas_MC(BT_iter);
    Media_Tensao_G1(i)  = m;
    IC_Inf_Tensao_G1(i) = ic_inf;
    IC_Sup_Tensao_G1(i) = ic_sup;

    % --- Transformadores sobrecarregados (pico do dia, por iteração) ---
    [m_t, ~, ~, ic_inf_t, ic_sup_t] = calcula_estatisticas_trafo_pico(pastaCaso);
    Media_Trafo_G1(i)  = m_t;
    IC_Inf_Trafo_G1(i) = ic_inf_t;
    IC_Sup_Trafo_G1(i) = ic_sup_t;
end

%% ========================================================================
%  GRUPO 2 - MIGRAÇÃO DE VEs DE EL PARA ER (ES FIXO)
% ========================================================================
casosGrupo2 = [4, 11, 12, 13, 14];
percentER_G2 = [12, 17, 22, 27, 32]; % correspondência direta com casosGrupo2
nCasos2 = length(casosGrupo2);

Media_Tensao_G2  = NaN(nCasos2,1);
IC_Inf_Tensao_G2 = NaN(nCasos2,1);
IC_Sup_Tensao_G2 = NaN(nCasos2,1);
Media_Trafo_G2   = NaN(nCasos2,1);
IC_Inf_Trafo_G2  = NaN(nCasos2,1);
IC_Sup_Trafo_G2  = NaN(nCasos2,1);

for i = 1:nCasos2
    pastaCaso = sprintf('%s\\caso%d\\Dados_Alimentador%s', pastaBase, casosGrupo2(i), Ali);

    BT_iter = open(fullfile(pastaCaso,'Tensao_minima_diaria_BT.mat')).Tensao_minima_diaria_BT;
    [m, ~, ~, ic_inf, ic_sup] = calcula_estatisticas_MC(BT_iter);
    Media_Tensao_G2(i)  = m;
    IC_Inf_Tensao_G2(i) = ic_inf;
    IC_Sup_Tensao_G2(i) = ic_sup;

    [m_t, ~, ~, ic_inf_t, ic_sup_t] = calcula_estatisticas_trafo_pico(pastaCaso);
    Media_Trafo_G2(i)  = m_t;
    IC_Inf_Trafo_G2(i) = ic_inf_t;
    IC_Sup_Trafo_G2(i) = ic_sup_t;
end

%% ========================================================================
%  FIGURA ÚNICA: 2 PAINÉIS (GRUPO 1 e GRUPO 2), TENSÃO E TRANSFORMADORES
% ========================================================================
figure('Name', 'Sensibilidade Complementar - Horário de EL e Migração EL-ER', ...
    'Position', [100, 100, 1000, 400])

% --- Painel (a): Grupo 1 - horário médio de EL ---
subplot(1,2,1)
yyaxis left
errorbar(horasGrupo1, Media_Tensao_G1, Media_Tensao_G1-IC_Inf_Tensao_G1, IC_Sup_Tensao_G1-Media_Tensao_G1, ...
    '-o', 'LineWidth', 1.5, 'CapSize', 6);
ylabel('Tensão mínima diária (p.u.)');
yyaxis right
errorbar(horasGrupo1, Media_Trafo_G1, Media_Trafo_G1-IC_Inf_Trafo_G1, IC_Sup_Trafo_G1-Media_Trafo_G1, ...
    '-s', 'LineWidth', 1.5, 'CapSize', 6);
ylabel('Nº transformadores sobrecarregados (pico)');
xlabel('Horário médio de início da recarga EL (h)');
title('(a) Sensibilidade ao horário médio de EL');
grid on
ax = gca; ax.FontSize = tam;

% --- Painel (b): Grupo 2 - migração EL -> ER ---
subplot(1,2,2)
yyaxis left
errorbar(percentER_G2, Media_Tensao_G2, Media_Tensao_G2-IC_Inf_Tensao_G2, IC_Sup_Tensao_G2-Media_Tensao_G2, ...
    '-o', 'LineWidth', 1.5, 'CapSize', 6);
ylabel('Tensão mínima diária (p.u.)');
yyaxis right
errorbar(percentER_G2, Media_Trafo_G2, Media_Trafo_G2-IC_Inf_Trafo_G2, IC_Sup_Trafo_G2-Media_Trafo_G2, ...
    '-s', 'LineWidth', 1.5, 'CapSize', 6);
ylabel('Nº transformadores sobrecarregados (pico)');
xlabel('Participação de ERs na frota (%)');
title('(b) Sensibilidade à migração EL \rightarrow ER');
grid on
ax = gca; ax.FontSize = tam;

%% ========================================================================
%  TABELA ÚNICA COMBINADA (OS DOIS GRUPOS)
% ========================================================================
Grupo_Rotulo = [repmat({'Horário EL'}, nCasos1, 1); repmat({'Migração EL->ER'}, nCasos2, 1)];
Variavel_Rotulo = [strcat(string(horasGrupo1'), "h"); strcat(string(percentER_G2'), "% ER")];
Media_Tensao_Tab  = [Media_Tensao_G1;  Media_Tensao_G2];
IC_Inf_Tensao_Tab = [IC_Inf_Tensao_G1; IC_Inf_Tensao_G2];
IC_Sup_Tensao_Tab = [IC_Sup_Tensao_G1; IC_Sup_Tensao_G2];
Media_Trafo_Tab   = [Media_Trafo_G1;   Media_Trafo_G2];
IC_Inf_Trafo_Tab  = [IC_Inf_Trafo_G1;  IC_Inf_Trafo_G2];
IC_Sup_Trafo_Tab  = [IC_Sup_Trafo_G1;  IC_Sup_Trafo_G2];

Tabela_Sensibilidade_Complementar = table(Grupo_Rotulo, cellstr(Variavel_Rotulo), ...
    Media_Tensao_Tab, IC_Inf_Tensao_Tab, IC_Sup_Tensao_Tab, ...
    Media_Trafo_Tab, IC_Inf_Trafo_Tab, IC_Sup_Trafo_Tab, ...
    'VariableNames', {'Grupo', 'Variavel', 'Tensao_Media_pu', 'Tensao_IC95_Inf', 'Tensao_IC95_Sup', ...
    'Trafos_Media', 'Trafos_IC95_Inf', 'Trafos_IC95_Sup'});

disp('================================================================');
disp('   SENSIBILIDADE COMPLEMENTAR - HORÁRIO DE EL E MIGRAÇÃO EL->ER  ');
disp('================================================================');
disp(Tabela_Sensibilidade_Complementar);

fig_tab = figure('Name', 'Tabela de Sensibilidade Complementar', 'Position', [100, 100, 1100, 280]);
uit = uitable(fig_tab, 'Data', table2cell(Tabela_Sensibilidade_Complementar), ...
    'ColumnName', {'Grupo', 'Variável', 'Tensão Média (p.u.)', 'IC95% Inf.', 'IC95% Sup.', ...
    'Trafos Média', 'IC95% Inf.', 'IC95% Sup.'}, ...
    'RowName', [], 'Units', 'Normalized', 'Position', [0 0 1 1]);
uit.ColumnWidth = {110, 90, 110, 90, 90, 90, 90, 90};


%% ========================================================================
%  FUNÇÃO LOCAL - ESTATÍSTICA DE MONTE CARLO (TENSÃO MÍNIMA DIÁRIA)
% ========================================================================
function [media, desvio, n, ic_inf, ic_sup, p5, p50, p95] = calcula_estatisticas_MC(dadosBT)
    % dadosBT: matriz (24 x n_iteracoes) de tensão por hora e iteração
    valorDiarioPorIteracao = min(dadosBT, [], 1); % tensão mínima diária por iteração
    n = length(valorDiarioPorIteracao);
    media = mean(valorDiarioPorIteracao);
    desvio = std(valorDiarioPorIteracao);

    if n > 1
        erro_padrao = desvio / sqrt(n);
        t_critico = tinv(0.975, n-1);
        ic_inf = media - t_critico * erro_padrao;
        ic_sup = media + t_critico * erro_padrao;
    else
        ic_inf = media;
        ic_sup = media;
    end

    p5  = prctile(valorDiarioPorIteracao, 5);
    p50 = prctile(valorDiarioPorIteracao, 50);
    p95 = prctile(valorDiarioPorIteracao, 95);
end

%% ========================================================================
%  FUNÇÃO LOCAL - ESTATÍSTICA DO PICO DE TRANSFORMADORES SOBRECARREGADOS
% ========================================================================
function [media, desvio, n, ic_inf, ic_sup] = calcula_estatisticas_trafo_pico(pastaCaso)
    caminho3D = fullfile(pastaCaso, 'Demanda_Diario_Trafo_3D.mat');

    if isfile(caminho3D)
        dados3D = open(caminho3D).Demanda_Diario_Trafo_3D; % (trafos x 24h x iteracoes)
        nIter = size(dados3D, 3);
        picoPorIteracao = zeros(nIter, 1);
        for nt = 1:nIter
            contagemHoraria = sum(dados3D(:,:,nt) > 100, 1); % (1 x 24)
            picoPorIteracao(nt) = max(contagemHoraria);
        end
        n = nIter;
        media = mean(picoPorIteracao);
        desvio = std(picoPorIteracao);
        if n > 1
            erro_padrao = desvio / sqrt(n);
            t_critico = tinv(0.975, n-1);
            ic_inf = media - t_critico * erro_padrao;
            ic_sup = media + t_critico * erro_padrao;
        else
            ic_inf = media; ic_sup = media;
        end
    else
        % Fallback: apenas a curva média final (sem IC disponível)
        warning('Matriz 3D não encontrada em %s. Usando apenas a média final (sem IC).', pastaCaso);
        TrafoFinal = open(fullfile(pastaCaso,'Demanda_Diario_Trafo_final.mat')).Demanda_Diario_Trafo_final;
        contagemHoraria = zeros(1,24);
        for h = 1:24
            contagemHoraria(h) = sum(TrafoFinal{:,h+1} > 100);
        end
        media = max(contagemHoraria);
        desvio = NaN; n = NaN; ic_inf = NaN; ic_sup = NaN;
    end
end