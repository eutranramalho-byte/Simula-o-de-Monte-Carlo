clc; clear; close all;
tam = 15;

% Caminho onde estão os arquivos salvos (ajuste conforme seu pc)
caso_analise = 4; % Vamos analisar o cenário mais critico (100% VEs)
pasta_resultados = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_AlimentadorJMLT308\\Melhor_Pior_Caso', caso_analise);

% Nomes dos arquivos salvos pelo seu código original
arquivos_pior = {'Eletropostos_EL_PIOR.dss', 'Eletropostos_ES_PIOR.dss', 'Eletropostos_ER_PIOR.dss'};
arquivos_melhor = {'Eletropostos_EL_MELHOR.dss', 'Eletropostos_ES_MELHOR.dss', 'Eletropostos_ER_MELHOR.dss'};


[curva_total_pior, pico_pior] = reconstruir_curva(pasta_resultados, arquivos_pior);
[curva_total_melhor, pico_melhor] = reconstruir_curva(pasta_resultados, arquivos_melhor);


t = 1:24; % Horas

figure('Name', 'Investigação da Causa_Melhor vs Pior', 'Color', 'w', 'Position', [100 100 800 600]);

% Gráfico 1: Comparação das Curvas de Carga dos VEs
subplot(2,1,1);
plot(t, curva_total_pior, '-r', 'LineWidth', 2); hold on;
plot(t, curva_total_melhor, '-g', 'LineWidth', 2);
xline(19, '--k', 'Horário de Ponta');
legend('Pior Caso (Menor Tensão)', 'Melhor Caso (Maior Tensão)');
title(['Comparação da Demanda Total dos VEs - Cenário ' num2str(caso_analise)]);
xlabel('Hora do Dia'); ylabel('Potência Ativa Total (kW)');
grid on;
ax = gca;
ax.FontSize = tam-2;

% Análise de Diferença
diferenca_pico = curva_total_pior(19) - curva_total_melhor(19);
texto_analise = sprintf('Diferença de pico: %.2f kW', diferenca_pico);
text(2, max(curva_total_pior)*0.7, texto_analise, 'FontSize', 12, 'BackgroundColor', 'w');

% Gráfico 2: Diferença percentual
subplot(2,1,2);
area(t, curva_total_pior - curva_total_melhor, 'FaceColor', [0.8 0.8 0.8]);
title('Diferença de Potência (Pior - Melhor)');
xlabel('Hora do Dia'); ylabel('kW Adicional no Pior Caso');
grid on;
ax = gca;
ax.FontSize = tam-2;

function [curva_total, pico] = reconstruir_curva(pasta, lista_arquivos)
    curva_total = zeros(1, 24); % Vetor de 24h
    
    for k = 1:length(lista_arquivos)
        arquivo = fullfile(pasta, lista_arquivos{k});
        if ~isfile(arquivo)
            warning(['Arquivo não encontrado: ' arquivo]);
            continue;
        end
        
        fid = fopen(arquivo, 'r');
        txt = fscanf(fid, '%c');
        fclose(fid);
        
        % 1. Extrair os Loadshapes (Nome e Valores p.u.)
        padrao_loadshape = 'New Loadshape\.(\S+).*?mult=\[\s*([0-9\.\s\-]+)\s*\]';
        tokens_ls = regexp(txt, padrao_loadshape, 'tokens', 'ignorecase');
        
        % Dicionário para armazenar as curvas p.u. associadas ao nome
        mapa_loadshapes = containers.Map();
        
        for i = 1:length(tokens_ls)
            nome_ls = tokens_ls{i}{1};
            valores_pu = str2num(tokens_ls{i}{2}); %#ok<ST2NM>
            
            % Downsample para 24h se houver mais pontos
            if length(valores_pu) > 24
                valores_pu = mean(reshape(valores_pu(1:end), length(valores_pu)/24, 24));
            end
            
            mapa_loadshapes(nome_ls) = abs(valores_pu); % Usa módulo para injeção/carga
        end
        
        % 2. Extrair Storages (kWrated e Nome da Curva 'daily')
        padrao_storage = 'New Storage\.\S+.*?kWrated=([0-9\.]+).*?daily=(\S+)';
        tokens_st = regexp(txt, padrao_storage, 'tokens', 'ignorecase');
        
        % 3. Multiplicar p.u. por kWrated e somar na curva total
        for i = 1:length(tokens_st)
            kw_rated = str2double(tokens_st{i}{1});
            nome_daily = tokens_st{i}{2};
            
            % Se o Storage possui um Loadshape lido anteriormente, calcula e acumula
            if isKey(mapa_loadshapes, nome_daily)
                curva_pu = mapa_loadshapes(nome_daily);
                curva_kw = curva_pu * kw_rated; % Cálculo real de potência
                curva_total = curva_total + curva_kw;
            end
        end
    end
    
    pico = max(curva_total);
end




