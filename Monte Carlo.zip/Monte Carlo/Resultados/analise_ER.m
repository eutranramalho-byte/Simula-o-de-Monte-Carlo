%% Configurações Gerais
clc; clear; close all;
tam = 15;
Ali = 'JMLT308'; % Nome do Alimentador
cenarios = [2, 3, 4]; % Cenários a analisar
titulos = {'Cenário 2: Inserção Inicial (10%)', ...
           'Cenário 3: Expansão (50%)', ...
           'Cenário 4: Saturação (100%)'};

% Cria a figura
figure('Name', 'Convergência da Infraestrutura de Recarga', 'Color', 'w', 'Position', [100 50 800 900]);
t = tiledlayout(3, 1, 'TileSpacing', 'compact', 'Padding', 'compact');

%% Loop pelos Cenários
for i = 1:length(cenarios)
    c = cenarios(i);
    
    % --- 1. Definir o caminho e ler o arquivo do cenário específico ---
    % Caminho baseado no seu script anterior
    pastaOrigem = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s', c, Ali);
    arquivoER = fullfile(pastaOrigem, 'Relatorio_ER.xlsx');
    
    if ~isfile(arquivoER)
        warning('Arquivo não encontrado para o Cenário %d: %s', c, arquivoER);
        continue;
    end
    
    % Ler a tabela (preserve para manter nomes originais como "Qtd_ER_Input")
    Dados = readtable(arquivoER, 'VariableNamingRule', 'preserve');
    
    fprintf("\n\n Cenário %d: Minima = %d; Máxima = %d \n\n",c,round(mean(Dados.Taxa_Min(:))*100,2),round(mean(Dados.Taxa_Max(:))*100,2))
    

    % Selecionar o tile correspondente
    nexttile;
    
    % --- 2. Plotar EIXO ESQUERDO: Quantidade de Eletropostos ---
    yyaxis left
    % Plota a Quantidade Input (quanto tinha no começo da iteração)
    plot(Dados.Iteracao_MC, Dados.Qtd_ER_Input, '-s', 'LineWidth', 2, 'MarkerSize', 5);
    ylabel('Qtd. Eletropostos (Un.)');
    
    % Ajuste visual do eixo Y esquerdo (garantir inteiros)
    y_min = min(Dados.Qtd_ER_Input);
    y_max = max(Dados.Qtd_ER_Input);
    if y_min == y_max
        ylim([y_min-1, y_max+1]);
    else
        ylim([y_min-1, y_max+1]);
    end
    grid on;
    
    % --- 3. Plotar EIXO DIREITO: Taxas de Ocupação ---
    yyaxis right
    hold on;
    % Taxa Máxima (Laranja)
    pMax = plot(Dados.Iteracao_MC, Dados.Taxa_Max, '-^', 'LineWidth', 1.5, 'Color', [0.85, 0.33, 0.1]); 
    % Taxa Mínima (Verde)
    pMin = plot(Dados.Iteracao_MC, Dados.Taxa_Min, '-v', 'LineWidth', 1.5, 'Color', [0.47, 0.67, 0.19]);
    
    % Linhas de limite (30% e 70%)
    yline(0.7, '--r', 'Limite Sup. (70%)', 'LabelHorizontalAlignment', 'left', 'FontSize', 8, 'Alpha', 0.6);
    yline(0.3, '--b', 'Limite Inf. (30%)', 'LabelHorizontalAlignment', 'left', 'FontSize', 8, 'Alpha', 0.6);
    
    ylabel('Taxa de Ocupação (p.u.)');
    ylim([0, 1.1]); % Fixa de 0 a 110%
    
    % Títulos
    title(titulos{i}, 'FontWeight', 'bold');
    
    % Legenda apenas no primeiro gráfico para não poluir
    if i == 1
        legend([pMax, pMin], {'Taxa Máxima', 'Taxa Mínima'}, 'Location', 'northoutside', 'Orientation', 'horizontal');
    end
    hold off;
    ax = gca;
    ax.FontSize = tam-2;
end

% Rótulo comum do eixo X
xlabel(t, 'Iteração do Algoritmo (Monte Carlo)');

