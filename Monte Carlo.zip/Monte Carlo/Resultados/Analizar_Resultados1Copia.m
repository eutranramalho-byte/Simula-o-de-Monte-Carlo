%% ========================================================================
%  ANÁLISE DE RESULTADOS - SIMULAÇÃO DE MONTE CARLO (OpenDSS + SUMO)
% ========================================================================
clear; clc; close all; clearvars

plotartodos = false;

Ali='JMLT308';
ylimi = 1.06;
xlimi = 0.70;
tam = 24; % Tamanho da fonte
nomesCasos = {'Cenário 1: Base', 'Cenário 2: 10% VEs', 'Cenário 3: 50% VEs', 'Cenário 4: 100% VEs', 'Cenário 5: 100% VEs (EL 23h)'};

%% ========================================================================
%  CAMINHOS DAS PASTAS (CASOS 1 A 5)
% ========================================================================
pastaCaso1 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso1\\Dados_Alimentador%s',Ali);
pastaCaso2 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso2\\Dados_Alimentador%s',Ali);
pastaCaso3 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso3\\Dados_Alimentador%s',Ali);
pastaCaso4 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso4\\Dados_Alimentador%s',Ali);
pastaCaso5 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso5\\Dados_Alimentador%s',Ali);

pastaMonitor1 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso1\\Alimentador%s\\%s_Mon_monitor_power_1_sem_eletroposto.csv',Ali,Ali);
pastaMonitor2 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso2\\Alimentador%s\\%s_Mon_monitor_power_1_sem_eletroposto.csv',Ali,Ali);
pastaMonitor3 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso3\\Alimentador%s\\%s_Mon_monitor_power_1_sem_eletroposto.csv',Ali,Ali);
pastaMonitor4 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso4\\Alimentador%s\\%s_Mon_monitor_power_1_sem_eletroposto.csv',Ali,Ali);
pastaMonitor5 = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso5\\Alimentador%s\\%s_Mon_monitor_power_1_sem_eletroposto.csv',Ali,Ali);

%% ========================================================================
%  CARREGAMENTO DOS DADOS - CASOS 1 A 4 (ORIGINAL, MANTIDO)
% ========================================================================
P_perdas1 = open(fullfile(pastaCaso1,'P_Perdas_Final.mat')).P_Perdas_final;
Q_perdas1 = open(fullfile(pastaCaso1,'Q_Perdas_Final.mat')).Q_Perdas_final;
Trafo1    = open(fullfile(pastaCaso1,'Demanda_Diario_Trafo_final.mat')).Demanda_Diario_Trafo_final;
BT1       = open(fullfile(pastaCaso1,'Tensao_minima_diaria_BT_final.mat')).Tensao_minima_diaria_BT_final;
MT1       = open(fullfile(pastaCaso1,'Tensao_minima_diaria_MT_final.mat')).Tensao_minima_diaria_MT_final;

P_perdas2 = open(fullfile(pastaCaso2,'P_Perdas_Final.mat')).P_Perdas_final;
Q_perdas2 = open(fullfile(pastaCaso2,'Q_Perdas_Final.mat')).Q_Perdas_final;
Trafo2    = open(fullfile(pastaCaso2,'Demanda_Diario_Trafo_final.mat')).Demanda_Diario_Trafo_final;
BT2       = open(fullfile(pastaCaso2,'Tensao_minima_diaria_BT_final.mat')).Tensao_minima_diaria_BT_final;
MT2       = open(fullfile(pastaCaso2,'Tensao_minima_diaria_MT_final.mat')).Tensao_minima_diaria_MT_final;
V_minima_total_MT2 = open(fullfile(pastaCaso2,'Tensao_minima_diaria_MT.mat')).Tensao_minima_diaria_MT;
V_minima_total_BT2 = open(fullfile(pastaCaso2,'Tensao_minima_diaria_BT.mat')).Tensao_minima_diaria_BT;

P_perdas3 = open(fullfile(pastaCaso3,'P_Perdas_Final.mat')).P_Perdas_final;
Q_perdas3 = open(fullfile(pastaCaso3,'Q_Perdas_Final.mat')).Q_Perdas_final;
Trafo3    = open(fullfile(pastaCaso3,'Demanda_Diario_Trafo_final.mat')).Demanda_Diario_Trafo_final;
BT3       = open(fullfile(pastaCaso3,'Tensao_minima_diaria_BT_final.mat')).Tensao_minima_diaria_BT_final;
MT3       = open(fullfile(pastaCaso3,'Tensao_minima_diaria_MT_final.mat')).Tensao_minima_diaria_MT_final;
V_minima_total_MT3 = open(fullfile(pastaCaso3,'Tensao_minima_diaria_MT.mat')).Tensao_minima_diaria_MT;
V_minima_total_BT3 = open(fullfile(pastaCaso3,'Tensao_minima_diaria_BT.mat')).Tensao_minima_diaria_BT;

P_perdas4 = open(fullfile(pastaCaso4,'P_Perdas_Final.mat')).P_Perdas_final;
Q_perdas4 = open(fullfile(pastaCaso4,'Q_Perdas_Final.mat')).Q_Perdas_final;
Trafo4    = open(fullfile(pastaCaso4,'Demanda_Diario_Trafo_final.mat')).Demanda_Diario_Trafo_final;
BT4       = open(fullfile(pastaCaso4,'Tensao_minima_diaria_BT_final.mat')).Tensao_minima_diaria_BT_final;
MT4       = open(fullfile(pastaCaso4,'Tensao_minima_diaria_MT_final.mat')).Tensao_minima_diaria_MT_final;
V_minima_total_MT4 = open(fullfile(pastaCaso4,'Tensao_minima_diaria_MT.mat')).Tensao_minima_diaria_MT;
V_minima_total_BT4 = open(fullfile(pastaCaso4,'Tensao_minima_diaria_BT.mat')).Tensao_minima_diaria_BT;

V_pior_caso2   = open(fullfile(pastaCaso2,'V_pior_caso.mat')).pior_caso;
V_pior_caso3   = open(fullfile(pastaCaso3,'V_pior_caso.mat')).pior_caso;
V_pior_caso4   = open(fullfile(pastaCaso4,'V_pior_caso.mat')).pior_caso;
V_melhor_caso2 = open(fullfile(pastaCaso2,'V_melhor_caso.mat')).melhor_caso;
V_melhor_caso3 = open(fullfile(pastaCaso3,'V_melhor_caso.mat')).melhor_caso;
V_melhor_caso4 = open(fullfile(pastaCaso4,'V_melhor_caso.mat')).melhor_caso;

%% ========================================================================
%  CARREGAMENTO DOS DADOS - CASO 5
% ========================================================================
P_perdas5 = open(fullfile(pastaCaso5,'P_Perdas_Final.mat')).P_Perdas_final;
Q_perdas5 = open(fullfile(pastaCaso5,'Q_Perdas_Final.mat')).Q_Perdas_final;
Trafo5    = open(fullfile(pastaCaso5,'Demanda_Diario_Trafo_final.mat')).Demanda_Diario_Trafo_final;
BT5       = open(fullfile(pastaCaso5,'Tensao_minima_diaria_BT_final.mat')).Tensao_minima_diaria_BT_final;
MT5       = open(fullfile(pastaCaso5,'Tensao_minima_diaria_MT_final.mat')).Tensao_minima_diaria_MT_final;
V_minima_total_MT5 = open(fullfile(pastaCaso5,'Tensao_minima_diaria_MT.mat')).Tensao_minima_diaria_MT;
V_minima_total_BT5 = open(fullfile(pastaCaso5,'Tensao_minima_diaria_BT.mat')).Tensao_minima_diaria_BT;

V_pior_caso5   = open(fullfile(pastaCaso5,'V_pior_caso.mat')).pior_caso;
V_melhor_caso5 = open(fullfile(pastaCaso5,'V_melhor_caso.mat')).melhor_caso;

% Dados por iteração do Caso 1 
V_minima_total_BT1 = open(fullfile(pastaCaso1,'Tensao_minima_diaria_BT.mat')).Tensao_minima_diaria_BT;

%% ========================================================================
%  MATRIZES CONSOLIDADAS (CASOS 1 A 5)
% ========================================================================
V_BT = [BT1';BT2';BT3';BT4';BT5'];
V_MT = [MT1';MT2';MT3';MT4';MT5'];
P_Perdas = [P_perdas1';P_perdas2';P_perdas3';P_perdas4';P_perdas5'];
Q_Perdas = [Q_perdas1';Q_perdas2';Q_perdas3';Q_perdas4';Q_perdas5'];

% Transformadores sobrecarregados (% de carregamento > 100%)
trafos_sobrecarregados = zeros(5,24);
for n = 1:24
    trafos_sobrecarregados(1,n) = sum(Trafo1{:,n+1} > 100);
    trafos_sobrecarregados(2,n) = sum(Trafo2{:,n+1} > 100);
    trafos_sobrecarregados(3,n) = sum(Trafo3{:,n+1} > 100);
    trafos_sobrecarregados(4,n) = sum(Trafo4{:,n+1} > 100);
    trafos_sobrecarregados(5,n) = sum(Trafo5{:,n+1} > 100);
end
tempo = 1:24;

%% ========================================================================
%  GRÁFICOS DE TENSÂO
% ========================================================================
figure('Name','Perfil de tensão mínimo diário nas barras BT')
plot(tempo, V_BT', 'LineWidth', 3)
hold on
yline(0.92, '--k', 'LineWidth', 1.5);
yline(1.05, '--k', 'LineWidth', 1.5);
xlabel('Tempo (h)');
ylabel('Tensão (p.u)');
legend([nomesCasos, {'Limites regulatórios do PRODIST'}], 'Location', 'best');
ylim([0.8 1.06]);
grid on
hold off
ax = gca;
ax.FontSize = tam-2;

if plotartodos
    figure('Name','Perfil de tensão mínimo diário nas barras MT')
    plot(tempo, V_MT', 'LineWidth', 1.5)
    hold on
    yline(0.93, '--k', 'LineWidth', 1.5);
    yline(1.05, '--k', 'LineWidth', 1.5);
    xlabel('Tempo (h)'); ylabel('Tensão (p.u)');
    legend([nomesCasos, {'Limites regulatórios do PRODIST'}], 'Location', 'best');
    ylim([0.8 1.06]);
    grid on;
    hold off
    ax = gca;
    ax.FontSize = tam-2;
    
    figure('Name','Perdas de potencia ativa')
    plot(tempo, P_Perdas', 'LineWidth', 1.5)
    xlabel('Tempo (h)'); ylabel('Potência (kW)');
    legend(nomesCasos, 'Location', 'best'); grid on;
    ax = gca;
    ax.FontSize = tam-2;
    
    figure('Name','Quantidade de transformadores sobrecarregados')
    plot(tempo, trafos_sobrecarregados', 'LineWidth', 1.5)
    xlabel('Tempo (h)'); ylabel('Nº de Transformadores');
    legend(nomesCasos, 'Location', 'best'); grid on;
    ax = gca;
    ax.FontSize = tam-2;
    
    figure('Name','Estatisticas da tensão mínima nas barras BT para o caso de 100% de VEs')
    hold on
    boxplot(V_minima_total_BT4')
    xlabel('Tempo em horas');ylabel('Tensão em p.u');
    yline(0.92, '--k', 'LineWidth', 1.5);
    yline(1.05, '--k', 'LineWidth', 1.5);
    ylim([xlimi ylimi]);
    legend({'Limites regulatórios do PRODIST'})
    grid on
    hold off
    ax = gca;
    ax.FontSize = tam-2;
end
%% ========================================================================
%  COMPARATIVOS DE DEMANDA 
% ========================================================================
Demanda_P2 = open(fullfile(pastaCaso2,'P_Media.mat')).P_Media;
Demanda_P3 = open(fullfile(pastaCaso3,'P_Media.mat')).P_Media;
Demanda_P4 = open(fullfile(pastaCaso4,'P_Media.mat')).P_Media;
Demanda_Q2 = open(fullfile(pastaCaso2,'Q_Media.mat')).Q_Media;
Demanda_Q3 = open(fullfile(pastaCaso3,'Q_Media.mat')).Q_Media;
Demanda_Q4 = open(fullfile(pastaCaso4,'Q_Media.mat')).Q_Media;

% Caso 5
Demanda_P5 = open(fullfile(pastaCaso5,'P_Media.mat')).P_Media;
Demanda_Q5 = open(fullfile(pastaCaso5,'Q_Media.mat')).Q_Media;

demanda_diaria_caso1 = readtable(pastaMonitor1, 'Delimiter', ',', 'ReadVariableNames', true, 'VariableNamingRule', 'preserve');
demanda_diaria_caso2 = readtable(pastaMonitor2, 'Delimiter', ',', 'ReadVariableNames', true, 'VariableNamingRule', 'preserve');
demanda_diaria_caso3 = readtable(pastaMonitor3, 'Delimiter', ',', 'ReadVariableNames', true, 'VariableNamingRule', 'preserve');
demanda_diaria_caso4 = readtable(pastaMonitor4, 'Delimiter', ',', 'ReadVariableNames', true, 'VariableNamingRule', 'preserve');
demanda_diaria_caso5 = readtable(pastaMonitor5, 'Delimiter', ',', 'ReadVariableNames', true, 'VariableNamingRule', 'preserve');

V_minima = table(string(nomesCasos(2:5)'),[V_pior_caso2;V_pior_caso3;V_pior_caso4;V_pior_caso5],[V_melhor_caso2;V_melhor_caso3;V_melhor_caso4;V_melhor_caso5],'VariableNames',{'Cenários','Tensão_Min','Tensão_Max'});
MaxMin = V_minima.("Tensão_Max")-V_minima.("Tensão_Min");
V_minima.Difereca = MaxMin;
disp(V_minima)

P_C1 = demanda_diaria_caso1.("P1 (kW)") + demanda_diaria_caso1.("P2 (kW)") + demanda_diaria_caso1.("P3 (kW)");
P_C2 = demanda_diaria_caso2.("P1 (kW)") + demanda_diaria_caso2.("P2 (kW)") + demanda_diaria_caso2.("P3 (kW)");
P_C3 = demanda_diaria_caso3.("P1 (kW)") + demanda_diaria_caso3.("P2 (kW)") + demanda_diaria_caso3.("P3 (kW)");
P_C4 = demanda_diaria_caso4.("P1 (kW)") + demanda_diaria_caso4.("P2 (kW)") + demanda_diaria_caso4.("P3 (kW)");
P_C5 = demanda_diaria_caso5.("P1 (kW)") + demanda_diaria_caso5.("P2 (kW)") + demanda_diaria_caso5.("P3 (kW)");

if plotartodos
    figure('Name','Composição de Demanda - Cenário 2')
    area(tempo, [P_C1, (P_C2 - P_C1), (Demanda_P2(:) - P_C2)])
    title('Composição da Demanda Ativa - Cenário 2: 10% VEs')
    xlabel('Tempo (h)')
    ylabel('Potência Ativa (kW)')
    legend('Demanda Atual', 'Crescimento Natural', 'Carga VEs', 'Location', 'northwest')
    grid on
    
    figure('Name','Composição de Demanda - Cenário 3')
    area(tempo, [P_C1, (P_C3 - P_C1), (Demanda_P3(:) - P_C3)])
    title('Composição da Demanda Ativa - Cenário 3: 50% VEs')
    xlabel('Tempo (h)')
    ylabel('Potência Ativa (kW)')
    legend('Demanda Atual', 'Crescimento Natural', 'Carga VEs', 'Location', 'northwest')
    grid on
    
    figure('Name','Composição de Demanda - Cenário 4')
    area(tempo, [P_C1, (P_C4 - P_C1), (Demanda_P4(:) - P_C4)])
    title('Composição da Demanda Ativa - Cenário 4: 100% VEs')
    xlabel('Tempo (h)')
    ylabel('Potência Ativa (kW)')
    legend('Demanda Atual', 'Crescimento Natural', 'Carga VEs', 'Location', 'northwest')
    grid on
end
%% ========================================================================
%  PERDAS POR COMPONENTE 
% ========================================================================
PT_Trafo1 = open(fullfile(pastaCaso1,'PT_Perdas_Trafo_final.mat')).PT_Perdas_Trafo_final;
PT_Trafo2 = open(fullfile(pastaCaso2,'PT_Perdas_Trafo_final.mat')).PT_Perdas_Trafo_final;
PT_Trafo3 = open(fullfile(pastaCaso3,'PT_Perdas_Trafo_final.mat')).PT_Perdas_Trafo_final;
PT_Trafo4 = open(fullfile(pastaCaso4,'PT_Perdas_Trafo_final.mat')).PT_Perdas_Trafo_final;

QT_Trafo1 = open(fullfile(pastaCaso1,'QT_Perdas_Trafo_final.mat')).QT_Perdas_Trafo_final;
QT_Trafo2 = open(fullfile(pastaCaso2,'QT_Perdas_Trafo_final.mat')).QT_Perdas_Trafo_final;
QT_Trafo3 = open(fullfile(pastaCaso3,'QT_Perdas_Trafo_final.mat')).QT_Perdas_Trafo_final;
QT_Trafo4 = open(fullfile(pastaCaso4,'QT_Perdas_Trafo_final.mat')).QT_Perdas_Trafo_final;

PT_MT1 = open(fullfile(pastaCaso1,'PT_Perdas_MT_final.mat')).PT_Perdas_MT_final;
PT_MT2 = open(fullfile(pastaCaso2,'PT_Perdas_MT_final.mat')).PT_Perdas_MT_final;
PT_MT3 = open(fullfile(pastaCaso3,'PT_Perdas_MT_final.mat')).PT_Perdas_MT_final;
PT_MT4 = open(fullfile(pastaCaso4,'PT_Perdas_MT_final.mat')).PT_Perdas_MT_final;

QT_MT1 = open(fullfile(pastaCaso1,'QT_Perdas_MT_final.mat')).QT_Perdas_MT_final;
QT_MT2 = open(fullfile(pastaCaso2,'QT_Perdas_MT_final.mat')).QT_Perdas_MT_final;
QT_MT3 = open(fullfile(pastaCaso3,'QT_Perdas_MT_final.mat')).QT_Perdas_MT_final;
QT_MT4 = open(fullfile(pastaCaso4,'QT_Perdas_MT_final.mat')).QT_Perdas_MT_final;

PT_BT1 = open(fullfile(pastaCaso1,'PT_Perdas_BT_final.mat')).PT_Perdas_BT_final;
PT_BT2 = open(fullfile(pastaCaso2,'PT_Perdas_BT_final.mat')).PT_Perdas_BT_final;
PT_BT3 = open(fullfile(pastaCaso3,'PT_Perdas_BT_final.mat')).PT_Perdas_BT_final;
PT_BT4 = open(fullfile(pastaCaso4,'PT_Perdas_BT_final.mat')).PT_Perdas_BT_final;

QT_BT1 = open(fullfile(pastaCaso1,'QT_Perdas_BT_final.mat')).QT_Perdas_BT_final;
QT_BT2 = open(fullfile(pastaCaso2,'QT_Perdas_BT_final.mat')).QT_Perdas_BT_final;
QT_BT3 = open(fullfile(pastaCaso3,'QT_Perdas_BT_final.mat')).QT_Perdas_BT_final;
QT_BT4 = open(fullfile(pastaCaso4,'QT_Perdas_BT_final.mat')).QT_Perdas_BT_final;

% Caso 5
PT_Trafo5 = open(fullfile(pastaCaso5,'PT_Perdas_Trafo_final.mat')).PT_Perdas_Trafo_final;
QT_Trafo5 = open(fullfile(pastaCaso5,'QT_Perdas_Trafo_final.mat')).QT_Perdas_Trafo_final;
PT_MT5    = open(fullfile(pastaCaso5,'PT_Perdas_MT_final.mat')).PT_Perdas_MT_final;
QT_MT5    = open(fullfile(pastaCaso5,'QT_Perdas_MT_final.mat')).QT_Perdas_MT_final;
PT_BT5    = open(fullfile(pastaCaso5,'PT_Perdas_BT_final.mat')).PT_Perdas_BT_final;
QT_BT5    = open(fullfile(pastaCaso5,'QT_Perdas_BT_final.mat')).QT_Perdas_BT_final;

PT_Trafo_Mat = [PT_Trafo1'; PT_Trafo2'; PT_Trafo3'; PT_Trafo4'; PT_Trafo5'];
QT_Trafo_Mat = [QT_Trafo1'; QT_Trafo2'; QT_Trafo3'; QT_Trafo4'; QT_Trafo5'];
PT_MT_Mat = [PT_MT1'; PT_MT2'; PT_MT3'; PT_MT4'; PT_MT5'];
QT_MT_Mat = [QT_MT1'; QT_MT2'; QT_MT3'; QT_MT4'; QT_MT5'];
PT_BT_Mat = [PT_BT1'; PT_BT2'; PT_BT3'; PT_BT4'; PT_BT5'];
QT_BT_Mat = [QT_BT1'; QT_BT2'; QT_BT3'; QT_BT4'; QT_BT5'];

if plotartodos
figure('Name', 'Decomposição das Perdas Ativas por Cenário');
    for i = 1:5
        subplot(2, 3, i);
        plot(tempo, PT_Trafo_Mat(i, :), 'LineWidth', 1.5, 'DisplayName', 'Trafo'); hold on;
        plot(tempo, PT_MT_Mat(i, :),    'LineWidth', 1.5, 'DisplayName', 'Rede MT');
        plot(tempo, PT_BT_Mat(i, :),    'LineWidth', 1.5, 'DisplayName', 'Rede BT');
        title(nomesCasos{i});
        xlabel('Tempo (h)'); ylabel('Perdas Ativas (kW)');
        xlim([1 24]); grid on; legend('Location', 'best'); hold off;
        ax = gca;
        ax.FontSize = tam-2;
    end
end
%% ========================================================================
%  PERDAS EM PORCENTAGEM (ATUALIZADO: agora com o Cenário 5)
% ========================================================================
Demand_Total_Mat = [P_C1, Demanda_P2(:), Demanda_P3(:), Demanda_P4(:), Demanda_P5(:)]';
P_Perdas_Perc = (P_Perdas ./ Demand_Total_Mat) * 100;

if plotartodos
    figure('Name','Perdas de Potência Ativa em Porcentagem')
    plot(tempo, P_Perdas_Perc', 'LineWidth', 3)
    xlabel('Tempo (h)'); ylabel('Perdas de Potência Ativa (%)');
    legend(nomesCasos, 'Location', 'best'); grid on;
    ax = gca;
    ax.FontSize = tam-2;
end
%% ========================================================================
%  COMPACTAÇÃO DE GRÁFICOS: DECOMPOSIÇÃO E PORCENTAGEM
% ========================================================================
fig_compacta = figure('Name', 'Perdas_Decomposição e Porcentagem', 'Position', [100, 100, 1000, 420]);

% --- Subplot 1: Decomposição das Perdas (Barras Empilhadas - kWh/dia) ---
subplot(1, 2, 1);

% Calcula a energia diária perdida (como o passo é de 1h, sum(kW) = kWh)
E_Trafo = sum(PT_Trafo_Mat, 2);
E_MT = sum(PT_MT_Mat, 2);
E_BT = sum(PT_BT_Mat, 2);
Matriz_Energia = [E_Trafo, E_MT, E_BT];

b = bar(Matriz_Energia, 'stacked', 'EdgeColor', 'k', 'LineWidth', 0.8);
% Paleta de cores para contraste no artigo
b(1).FaceColor = [0 0.4470 0.7410];     % Trafo (Azul)
b(2).FaceColor = [0.8500 0.3250 0.0980]; % MT (Laranja)
b(3).FaceColor = [0.9290 0.6940 0.1250]; % BT (Amarelo)

set(gca, 'XTickLabel', nomesCasos);
xtickangle(20);
ylabel('Energia Ativa Perdida (kWh/dia)', 'FontWeight', 'bold', 'FontName', 'Times New Roman');
title('Decomposição Diária por Componente', 'FontName', 'Times New Roman', 'FontSize', tam-2);
legend({'Trafo', 'Rede MT', 'Rede BT'}, 'Location', 'northwest', 'FontName', 'Times New Roman');
grid on;
set(gca, 'FontSize', tam-4, 'FontName', 'Times New Roman', 'GridAlpha', 0.4);

% --- Subplot 2: Perdas de Potência Ativa em Porcentagem (%) ao longo do tempo ---
subplot(1, 2, 2);

plot(tempo, P_Perdas_Perc', 'LineWidth', 2);
xlabel('Tempo (h)', 'FontWeight', 'bold', 'FontName', 'Times New Roman');
ylabel('Perdas de Potência Ativa (%)', 'FontWeight', 'bold', 'FontName', 'Times New Roman');
title('Evolução das Perdas em Relação à Demanda', 'FontName', 'Times New Roman', 'FontSize', tam-2);
legend(nomesCasos, 'Location', 'best', 'FontName', 'Times New Roman', 'FontSize', tam-4);
xlim([1 24]);
grid on;
set(gca, 'FontSize', tam-4, 'FontName', 'Times New Roman', 'GridAlpha', 0.4);

%% ========================================================================
%  SOBRECARGA DOS TRANSFORMADORES (ATUALIZADO: agora com o Cenário 5)
% ========================================================================
capacidade_media_sobrecarregados = NaN(5,24);
max_sobrecarga = NaN(5,24);
for n = 1:24
    t_dados = {Trafo1{:,n+1}, Trafo2{:,n+1}, Trafo3{:,n+1}, Trafo4{:,n+1}, Trafo5{:,n+1}};
    for c = 1:5
        sobrecarregados = t_dados{c}(t_dados{c} > 100);
        if ~isempty(sobrecarregados)
            capacidade_media_sobrecarregados(c,n) = mean(sobrecarregados);
            max_sobrecarga(c,n) = max(sobrecarregados);
        end
    end
end

% figure('Name', 'Análise de Sobrecarga dos Transformadores por Cenário');
% for i = 1:5
%     subplot(2, 3, i);
%     yyaxis left
%     plot(tempo, capacidade_media_sobrecarregados(i, :), '-o', 'LineWidth', 1.5, 'DisplayName', 'Fator de demanda médio(%)');
%     hold on;
%     ylabel('Fator de demanda médio(%)');
%     yyaxis right
%     bar(tempo, trafos_sobrecarregados(i, :), 'FaceAlpha', 0.3, 'EdgeColor', 'none', 'DisplayName', 'Qtd. média de sobrecarregados');
%     ylabel('Quantidade de transformadores');
%     title(nomesCasos{i});
%     xlabel('Tempo (h)');
%     xlim([1 24]);
%     grid on;
%     if i == 1
%         legend('Location', 'northwest');
%     end
%     hold off;
%     ax = gca;
%     ax.FontSize = tam-2;
% end

figure('Name', 'Análise de Sobrecarga dos Transformadores por Cenário');
for i = 1:4
    subplot(2, 2, i);
    yyaxis left
    plot(tempo, capacidade_media_sobrecarregados(i+1, :), '-o', 'LineWidth', 1.5, 'DisplayName', 'Fator de demanda médio(%)');
    hold on;
    ylabel('Fator de demanda médio(%)');
    yyaxis right
    bar(tempo, trafos_sobrecarregados(i+1, :), 'FaceAlpha', 0.3, 'EdgeColor', 'none', 'DisplayName', 'Qtd. média de sobrecarregados');
    ylabel('Quantidade de transformadores');
    title(nomesCasos{i+1});
    xlabel('Tempo (h)');
    xlim([1 24]);
    grid on;
    if i == 1
        legend('Location', 'northwest');
    end
    hold off;
    ax = gca;
    ax.FontSize = tam-4;
end

%% ========================================================================
%  PERDAS DE ENERGIA DIÁRIA (ATUALIZADO: agora com o Cenário 5)
% ========================================================================
Energia_Perdas_Diaria = sum(P_Perdas, 2);
Energia_Total_Diaria = sum(Demand_Total_Mat, 2);
E_Perdas_Perc = (Energia_Perdas_Diaria ./ Energia_Total_Diaria) * 100;

if plotartodos
    figure('Name','Perdas de Potência e Energia Diária em Porcentagem', 'Position', [100, 100, 1000, 450])
    subplot(1, 2, 1)
    plot(tempo, P_Perdas_Perc', 'LineWidth', 3)
    xlabel('Tempo (h)');
    ylabel('Perdas de Potência Ativa(%)');
    title('Perdas de Potência Ativa Diária (%)');
    legend(nomesCasos, 'Location', 'best');
    grid on;
    ax = gca;
    ax.FontSize = tam-2;
    
    subplot(1, 2, 2)
    b = bar(E_Perdas_Perc, 'FaceColor', 'flat');
    cores = lines(5);
    for k = 1:5
        b.CData(k,:) = cores(k,:);
    end
    set(gca, 'XTickLabel', nomesCasos);
    xtickangle(15);
    ylabel('Perdas de Energia Ativa(%)');
    title('Perdas de Energia Ativa Diária (%)');
    grid on;
    text(1:5, E_Perdas_Perc, num2str(E_Perdas_Perc, '%0.2f%%'), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', ...
        'FontSize', tam-4, 'FontWeight', 'bold');
    ax = gca;
    ax.FontSize = tam-4;
    
    figure('Name','Perdas de energia diaria');
    b = bar(E_Perdas_Perc, 'FaceColor', 'flat');
    cores = lines(5);
    for k = 1:5
        b.CData(k,:) = cores(k,:);
    end
    set(gca, 'XTickLabel', nomesCasos);
    xtickangle(15);
    ylabel('Perdas de Energia Ativa(%)');
    grid on;
    text(1:5, E_Perdas_Perc, num2str(E_Perdas_Perc, '%0.2f%%'), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', ...
        'FontSize', tam-4, 'FontWeight', 'bold');
    ax = gca;
    ax.FontSize = tam-2;
end
%% ========================================================================
%  TABELA DE COMPOSIÇÃO DA DEMANDA MÉDIA POR CENÁRIO (MANTIDO)
% ========================================================================
Demanda_Base_Media = mean(P_C1);
Crescimento_Nat_C2 = mean(P_C2 - P_C1);
Crescimento_Nat_C3 = mean(P_C3 - P_C1);
Crescimento_Nat_C4 = mean(P_C4 - P_C1);
Demanda_VEs_C2 = mean(Demanda_P2(:) - P_C2);
Demanda_VEs_C3 = mean(Demanda_P3(:) - P_C3);
Demanda_VEs_C4 = mean(Demanda_P4(:) - P_C4);

Cenarios_Tab = {'Cenário 1: Base'; 'Cenário 2: 10% VEs'; 'Cenário 3: 50% VEs'; 'Cenário 4: 100% VEs'};
Demanda_Base_Tab = repmat(Demanda_Base_Media, 4, 1);
Crescimento_Nat_Tab = [0; Crescimento_Nat_C2; Crescimento_Nat_C3; Crescimento_Nat_C4];
Demanda_VEs_Tab = [0; Demanda_VEs_C2; Demanda_VEs_C3; Demanda_VEs_C4];
Demanda_Total_Tab = Demanda_Base_Tab + Crescimento_Nat_Tab + Demanda_VEs_Tab;

Tabela_Demanda = table(Cenarios_Tab, Demanda_Base_Tab, Crescimento_Nat_Tab, Demanda_VEs_Tab, Demanda_Total_Tab, ...
    'VariableNames', {'Cenario', 'Base_kW', 'Crescimento_Natural_kW', 'Carga_VEs_kW', 'Total_kW'});

disp('================================================================');
disp('            COMPOSIÇÃO DA DEMANDA MÉDIA DIÁRIA (kW)             ');
disp('================================================================');
disp(Tabela_Demanda);

if plotartodos
    fig_tabela = figure('Name', 'Tabela de Composicao da Demanda', 'Position', [100, 100, 750, 150]);
    uit = uitable(fig_tabela, 'Data', table2cell(Tabela_Demanda), ...
        'ColumnName', {'Cenário', 'Base (kW)', 'Cresc. Natural (kW)', 'Carga VEs (kW)', 'Total (kW)'}, ...
        'RowName', [], 'Units', 'Normalized', 'Position', [0 0 1 1]);
    uit.ColumnWidth = {150, 120, 150, 120, 120};
end

%% ========================================================================
%  1) CONVERGÊNCIA DE MONTE CARLO - TENSÃO MÍNIMA DIÁRIA (BT)
% ========================================================================
casosConvergencia = {V_minima_total_BT2, V_minima_total_BT3, V_minima_total_BT4, V_minima_total_BT5};
nomesConvergencia = {'Cenário 2: 10% VEs', 'Cenário 3: 50% VEs', 'Cenário 4: 100% VEs', 'Cenário 5: 100% VEs (EL 23h)'};

figure('Name', 'Convergência de Monte Carlo - Tensão Mínima Diária (BT)');
for i = 1:4
    dadosBT = casosConvergencia{i};              % matriz (24 x n_iteracoes)
    tensaoMinPorIteracao = min(dadosBT, [], 1);   % tensão mínima diária por iteração
    nIter = length(tensaoMinPorIteracao);
    mediaMovel = cumsum(tensaoMinPorIteracao) ./ (1:nIter);

    subplot(2, 2, i);
    plot(1:nIter, tensaoMinPorIteracao, '-', 'Color', [0.7 0.7 0.7], 'LineWidth', 1, 'DisplayName', 'Valor por iteração');
    hold on;
    plot(1:nIter, mediaMovel, '-', 'Color', [0 0.447 0.741], 'LineWidth', 2, 'DisplayName', 'Média móvel acumulada');
    title(nomesConvergencia{i});
    xlabel('Iteração de Monte Carlo'); ylabel('Tensão mínima diária (p.u.)');
    grid on;
    if i == 1
        legend('Location', 'best');
    end
    hold off;
    ax = gca;
    ax.FontSize = tam-2;
end

%% ========================================================================
%  2) INTERVALOS DE CONFIANÇA E VARIÂNCIA - TENSÃO MÍNIMA DIÁRIA (BT)
% ========================================================================
casosEstatistica = {V_minima_total_BT1, V_minima_total_BT2, V_minima_total_BT3, V_minima_total_BT4, V_minima_total_BT5};
nomesEstatistica  = {'Cenário 1: Base', 'Cenário 2: 10% VEs', 'Cenário 3: 50% VEs', 'Cenário 4: 100% VEs', 'Cenário 5: 100% VEs (EL 23h)'};

N_cen = length(casosEstatistica);
Media_V   = zeros(N_cen,1);
Desvio_V  = zeros(N_cen,1);
N_Iter_V  = zeros(N_cen,1);
IC95_Inf  = zeros(N_cen,1);
IC95_Sup  = zeros(N_cen,1);
P5_V      = zeros(N_cen,1);
P50_V     = zeros(N_cen,1);
P95_V     = zeros(N_cen,1);

for i = 1:N_cen
    [m, s, n, ic_inf, ic_sup, p5, p50, p95] = calcula_estatisticas_MC(casosEstatistica{i});
    Media_V(i)  = m;
    Desvio_V(i) = s;
    N_Iter_V(i) = n;
    IC95_Inf(i) = ic_inf;
    IC95_Sup(i) = ic_sup;
    P5_V(i)     = p5;
    P50_V(i)    = p50;
    P95_V(i)    = p95;
end

Tabela_Estatistica_Tensao = table(nomesEstatistica', N_Iter_V, Media_V, Desvio_V, IC95_Inf, IC95_Sup, P5_V, P50_V, P95_V, ...
    'VariableNames', {'Cenario', 'N_Iteracoes', 'Media_pu', 'DesvioPadrao_pu', 'IC95_Inferior_pu', 'IC95_Superior_pu', 'P5_pu', 'P50_pu', 'P95_pu'});

disp('================================================================');
disp('   ESTATÍSTICA DA TENSÃO MÍNIMA DIÁRIA (BT) POR CENÁRIO          ');
disp('================================================================');
disp(Tabela_Estatistica_Tensao);

if plotartodos
    fig_estat = figure('Name', 'Tabela de Estatistica da Tensao Minima', 'Position', [100, 100, 950, 170]);
    uit_estat = uitable(fig_estat, 'Data', table2cell(Tabela_Estatistica_Tensao), ...
        'ColumnName', {'Cenário', 'N Iter.', 'Média (p.u.)', 'Desvio-padrão (p.u.)', 'IC95% Inf.', 'IC95% Sup.', 'P5 (p.u.)', 'P50 (p.u.)', 'P95 (p.u.)'}, ...
        'RowName', [], 'Units', 'Normalized', 'Position', [0 0 1 1]);
    uit_estat.ColumnWidth = {150, 70, 100, 130, 90, 90, 80, 80, 80};
end
%% ========================================================================
%  3) ANÁLISE DE SENSIBILIDADE - CENÁRIO 4 vs CENÁRIO 5 
% ========================================================================
nomesSensibilidade = {'Cenário 4: EL início 18h', 'Cenário 5: EL início 23h'};
if plotartodos
    % --- Perfil de tensão mínima (BT) ---
    V_BT_Sens = [BT4'; BT5'];
    figure('Name', 'Sensibilidade - Perfil de Tensão Mínima BT (Cenário 4 vs 5)')
    plot(tempo, V_BT_Sens', 'LineWidth', 1.5)
    hold on
    yline(0.92, '--k', 'LineWidth', 1.5);
    yline(1.05, '--k', 'LineWidth', 1.5);
    xlabel('Tempo (h)'); ylabel('Tensão (p.u)');
    legend([nomesSensibilidade, {'Limites regulatórios do PRODIST'}], 'Location', 'best');
    ylim([0.8 1.06]);
    grid on
    hold off
    ax = gca;
    ax.FontSize = tam-2;
end
% --- Transformadores sobrecarregados ---
trafos_sobrecarregados_sens = zeros(2,24);
for n = 1:24
    trafos_sobrecarregados_sens(1,n) = sum(Trafo4{:,n+1} > 100);
    trafos_sobrecarregados_sens(2,n) = sum(Trafo5{:,n+1} > 100);
end

if plotartodos
    figure('Name', 'Sensibilidade - Transformadores Sobrecarregados (Cenário 4 vs 5)')
    plot(tempo, trafos_sobrecarregados_sens', 'LineWidth', 1.5)
    xlabel('Tempo (h)'); ylabel('Nº de Transformadores');
    legend(nomesSensibilidade, 'Location', 'best'); grid on;
    ax = gca;
    ax.FontSize = tam-2;
end
% --- Perdas de potência ativa em porcentagem ---
Demand_Total_Sens = [Demanda_P4(:), Demanda_P5(:)]';
P_Perdas_Sens = [P_perdas4'; P_perdas5'];
P_Perdas_Perc_Sens = (P_Perdas_Sens ./ Demand_Total_Sens) * 100;

Energia_Perdas_Diaria_Sens = sum(P_Perdas_Sens, 2);
Energia_Total_Diaria_Sens = sum(Demand_Total_Sens, 2);
E_Perdas_Perc_Sens = (Energia_Perdas_Diaria_Sens ./ Energia_Total_Diaria_Sens) * 100;

if plotartodos
    figure('Name', 'Sensibilidade - Perdas de Potência e Energia (Cenário 4 vs 5)', 'Position', [100, 100, 1000, 450])
    subplot(1, 2, 1)
    plot(tempo, P_Perdas_Perc_Sens', 'LineWidth', 3)
    xlabel('Tempo (h)');
    ylabel('Perdas de Potência Ativa (%)');
    title('Perdas de Potência Ativa Diária (%)');
    legend(nomesSensibilidade, 'Location', 'best');
    grid on;
    ax = gca;
    ax.FontSize = tam-2;
    
    subplot(1, 2, 2)
    b = bar(E_Perdas_Perc_Sens, 'FaceColor', 'flat');
    cores_sens = lines(2);
    for k = 1:2
        b.CData(k,:) = cores_sens(k,:);
    end
    set(gca, 'XTickLabel', nomesSensibilidade);
    xtickangle(15);
    ylabel('Perdas de Energia Ativa (%)');
    title('Perdas de Energia Ativa Diária (%)');
    grid on;
    text(1:2, E_Perdas_Perc_Sens, num2str(E_Perdas_Perc_Sens, '%0.2f%%'), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', ...
        'FontSize', tam-4, 'FontWeight', 'bold');
    ax = gca;
    ax.FontSize = tam-4;
end
% Cálculo dos dados para os cenários 4 e 5 
capacidade_media_sobrecarregados_sens = NaN(2,24);
qtd_sobrecarregados_sens = zeros(2,24);

for n = 1:24
    % Cenário 4
    t4 = Trafo4{:, n+1};
    c4 = t4(t4 > 100);
    qtd_sobrecarregados_sens(1, n) = length(c4);
    if ~isempty(c4)
        capacidade_media_sobrecarregados_sens(1, n) = mean(c4); 
    end
    
    % Cenário 5
    t5 = Trafo5{:, n+1};
    c5 = t5(t5 > 100);
    qtd_sobrecarregados_sens(2, n) = length(c5);
    if ~isempty(c5)
        capacidade_media_sobrecarregados_sens(2, n) = mean(c5); 
    end
end

if plotartodos
    % Plotagem
    figure('Name', 'Análise de Sobrecarga - Cenários 4 e 5', 'Position', [100, 100, 1000, 400]);
    titulos = {'Cenário 4: 100% VEs', 'Cenário 5: 100% VEs (23h)'};
    
    for i = 1:2
        subplot(1, 2, i);
        
        % Eixo esquerdo (Demanda média)
        yyaxis left
        plot(tempo, capacidade_media_sobrecarregados_sens(i, :), '-o', 'LineWidth', 1.5, 'DisplayName', 'Fator de demanda médio(%)');
        ylabel('Fator de demanda médio(%)');
        
        % Eixo direito (Quantidade)
        yyaxis right
        bar(tempo, qtd_sobrecarregados_sens(i, :), 'FaceAlpha', 0.3, 'EdgeColor', 'none', 'DisplayName', 'Qtd. média de sobrecarregados');
        ylabel('Quantidade de transformadores');
        
        title(titulos{i});
        xlabel('Tempo (h)');
        xlim([1 24]);
        grid on;
        
        if i == 1
            legend('Location', 'northwest');
        end
        
        ax = gca;
        ax.FontSize = tam-2;
    end
end
% --- Tabela-resumo da sensibilidade ---
[m4, s4, n4, ic4_inf, ic4_sup] = calcula_estatisticas_MC(V_minima_total_BT4);
[m5, s5, n5, ic5_inf, ic5_sup] = calcula_estatisticas_MC(V_minima_total_BT5);

Tabela_Sensibilidade = table(nomesSensibilidade', [n4;n5], [m4;m5], [s4;s5], [ic4_inf;ic5_inf], [ic4_sup;ic5_sup], [V_pior_caso4;V_pior_caso5], [V_melhor_caso4;V_melhor_caso5], ...
    'VariableNames', {'Cenario', 'N_Iteracoes', 'Media_pu', 'DesvioPadrao_pu', 'IC95_Inferior_pu', 'IC95_Superior_pu', 'PiorCaso_pu', 'MelhorCaso_pu'});

disp('================================================================');
disp('   ANÁLISE DE SENSIBILIDADE - CENÁRIO 4 vs CENÁRIO 5             ');
disp('   (variação do horário de início da recarga lenta: 18h -> 23h) ');
disp('================================================================');
disp(Tabela_Sensibilidade);

%% ========================================================================
%  ANÁLISE DE SENSIBILIDADE - TRANSFORMADORES SOBRECARREGADOS (CASOS 2 A 5)
% ========================================================================
casos_sens = {Trafo2, Trafo3, Trafo4, Trafo5};
nomes_sens = {'Cenário 2 (10% VEs)', 'Cenário 3 (50% VEs)', 'Cenário 4 (100% VEs)', 'Cenário 5 (100% VEs, 23h)'};
cores_sens = lines(4);
fonte_artigo = 'Times New Roman';
tam_fonte = 12;

% Carregamento das matrizes 3D para cálculo da dispersão na hora de pico
Trafo3D_2 = open(fullfile(pastaCaso2,'Demanda_Diario_Trafo_3D.mat')).Demanda_Diario_Trafo_3D;
Trafo3D_3 = open(fullfile(pastaCaso3,'Demanda_Diario_Trafo_3D.mat')).Demanda_Diario_Trafo_3D;
Trafo3D_4 = open(fullfile(pastaCaso4,'Demanda_Diario_Trafo_3D.mat')).Demanda_Diario_Trafo_3D;
Trafo3D_5 = open(fullfile(pastaCaso5,'Demanda_Diario_Trafo_3D.mat')).Demanda_Diario_Trafo_3D;
casos_3D = {Trafo3D_2, Trafo3D_3, Trafo3D_4, Trafo3D_5};

% Pré-alocação de matrizes
num_sobrecarregados = zeros(4, 24);
media_fd_sobrecarregados = NaN(4, 24);
std_fd_sobrecarregados = NaN(4, 24);

% Extração de Dados 
for c = 1:4
    for n = 1:24
        carga_hora = casos_sens{c}{:, n+1};
        trafo_sobre = carga_hora(carga_hora > 100); 
        
        num_sobrecarregados(c, n) = length(trafo_sobre);
        
        if ~isempty(trafo_sobre)
            media_fd_sobrecarregados(c, n) = mean(trafo_sobre);
            if length(trafo_sobre) > 1
                std_fd_sobrecarregados(c, n) = std(trafo_sobre);
            else
                std_fd_sobrecarregados(c, n) = 0; 
            end
        end
    end
end

% Cálculos Estatísticos Diários
media_diaria_num = mean(num_sobrecarregados, 2);
std_diaria_num = std(num_sobrecarregados, 0, 2);

%% ========================================================================
%  TABELA DAS HORAS DE MAIOR SOBRECARGA
% ========================================================================
[num_pico, hora_pico] = max(num_sobrecarregados, [], 2);

% Usando cell array em vez de array de strings para compatibilidade com uitable
fd_pico_str = cell(4,1);
num_diario_str = cell(4,1);
num_pico_str = cell(4,1);

for c = 1:4
    h = hora_pico(c);
    
    % Formatação das dispersões (Média ± DP) como char
    num_diario_str{c} = sprintf('%.1f ± %.1f', media_diaria_num(c), std_diaria_num(c));
    
    if num_pico(c) > 0
        fd_pico_str{c} = sprintf('%.1f ± %.1f', media_fd_sobrecarregados(c, h), std_fd_sobrecarregados(c, h));
        
        % Cálculo da dispersão do número de transformadores na hora do pico (usando dados 3D)
        trafos_na_hora = squeeze(casos_3D{c}(:, h, :)); 
        qtd_sobre_por_iteracao = sum(trafos_na_hora > 100, 1); 
        
        media_pico_3d = mean(qtd_sobre_por_iteracao);
        std_pico_3d = std(qtd_sobre_por_iteracao);
        num_pico_str{c} = sprintf('%.1f ± %.1f', media_pico_3d, std_pico_3d);
    else
        fd_pico_str{c} = 'N/A';
        num_pico_str{c} = '0.0 ± 0.0';
        hora_pico(c) = NaN; % Sem pico de sobrecarga
    end
end

Tabela_Pico = table(nomes_sens', hora_pico, num_pico_str, num_diario_str, fd_pico_str, ...
    'VariableNames', {'Cenario', 'Hora_Pico', 'Trafos_Pico_Media_DP', 'Trafos_Diario_Media_DP', 'FD_Pico_Media_DP_perc'});

disp('--- Tabela: Horas de Maior Sobrecarga e Dispersões ---');
disp(Tabela_Pico);

if plotartodos
    % Interface gráfica da tabela para exportação
    fig_tab = figure('Name', 'Tabela de Maior Sobrecarga', 'Position', [100, 100, 950, 150]);
    uit_pico = uitable(fig_tab, 'Data', table2cell(Tabela_Pico), ...
        'ColumnName', {'Cenário', 'Hora de Pico (h)', 'Nº Trafos Pico (± DP)', 'Nº Trafos Diário (± DP)', 'Fator Dem. Pico (% ± DP)'}, ...
        'RowName', [], 'Units', 'Normalized', 'Position', [0 0 1 1]);
    uit_pico.ColumnWidth = {180, 120, 160, 180, 180};
    uit_pico.FontName = fonte_artigo;
    uit_pico.FontSize = tam_fonte;
end

%% ========================================================================
%  GRÁFICOS
% ========================================================================
% Gráfico 1: Número de Transformadores Sobrecarregados
if plotartodos
    fig1 = figure('Name', 'Sensibilidade - Quantidade de Trafos', 'Position', [100, 300, 850, 450]);
    b = bar(1:24, num_sobrecarregados', 'grouped', 'EdgeColor', 'k', 'LineWidth', 0.8);
    
    legendas_barras = cell(1, 4);
    for k = 1:4
        b(k).FaceColor = cores_sens(k, :);
        legendas_barras{k} = sprintf('%s (Média: %.1f ± %.1f)', nomes_sens{k}, media_diaria_num(k), std_diaria_num(k));
    end
    
    xlabel('Tempo (h)', 'FontWeight', 'bold', 'FontName', fonte_artigo);
    ylabel('Nº de Transformadores', 'FontWeight', 'bold', 'FontName', fonte_artigo);
    title('Quantidade de Transformadores Sobrecarregados ao Longo do Dia', 'FontName', fonte_artigo, 'FontSize', tam_fonte+2);
    legend(legendas_barras, 'Location', 'northwest', 'FontName', fonte_artigo, 'FontSize', tam_fonte-2);
    xlim([0.5 24.5]);
    grid on;
    set(gca, 'FontSize', tam_fonte, 'FontName', fonte_artigo, 'GridAlpha', 0.4);
    
    % Gráfico 2: Fator de Demanda dos Transformadores Sobrecarregados
    fig2 = figure('Name', 'Sensibilidade - Fator de Demanda', 'Position', [150, 350, 850, 450]);
    hold on;
    
    for c = 1:4
        idx = ~isnan(media_fd_sobrecarregados(c, :));
        if any(idx)
            errorbar(find(idx), media_fd_sobrecarregados(c, idx), std_fd_sobrecarregados(c, idx), ...
                '-o', 'Color', cores_sens(c, :), 'MarkerFaceColor', cores_sens(c, :), ...
                'MarkerSize', 6, 'LineWidth', 1.5, 'CapSize', 5, 'DisplayName', nomes_sens{c});
        end
    end
    
    yline(100, '--k', 'Capacidade Nominal (100%)', 'LineWidth', 1.5, ...
        'LabelHorizontalAlignment', 'left', 'LabelVerticalAlignment', 'bottom', ...
        'FontName', fonte_artigo, 'HandleVisibility', 'off');
    
    hold off;
    xlabel('Tempo (h)', 'FontWeight', 'bold', 'FontName', fonte_artigo);
    ylabel('Fator de Demanda (%)', 'FontWeight', 'bold', 'FontName', fonte_artigo);
    title('Fator de Demanda (Média e Desvio Padrão) nos Trafos Sobrecarregados', 'FontName', fonte_artigo, 'FontSize', tam_fonte+2);
    legend('Location', 'northwest', 'FontName', fonte_artigo, 'FontSize', tam_fonte-1);
    xlim([0.5 24.5]);
    grid on;
    set(gca, 'FontSize', tam_fonte, 'FontName', fonte_artigo, 'GridAlpha', 0.4);
end
%% ========================================================================
%  EXPORTAÇÃO OPCIONAL DE FIGURAS EM PDF (DESATIVADO POR PADRÃO)
% ========================================================================
salvar_figuras = false;
if salvar_figuras
    disp('Salvando figuras em PDF...');
    
    figuras = findobj('Type', 'figure'); 
    % OBS: Se quiser salvar apenas a figura 5 como estava no código original, 
    % figuras = findobj('Type', 'figure', 'Number', 9);
    
    pastaDestino = 'Graficos_TCC_PDF_Final_2';
    if ~exist(pastaDestino, 'dir')
        mkdir(pastaDestino);
    end
    
    for i = 1:length(figuras)
        fig = figuras(i); 
    
        % % Maximiza a janela da figura
        % fig.WindowState = 'maximized';
        % drawnow; % Aguarda a atualização gráfica na tela
    
        nomeBase = strrep(fig.Name, ' ', '_'); 
        if isempty(nomeBase)
            nomeBase = sprintf('Figura_%d', fig.Number);
        end
        nomeArquivoPDF = fullfile(pastaDestino, [nomeBase '.pdf']);
    
        % Exporta o gráfico ajustando automaticamente margens e tamanho
        exportgraphics(fig, nomeArquivoPDF, 'ContentType', 'vector');
    
        disp(['Salvo: ' nomeArquivoPDF]);
    end
    
    disp('Todos os gráficos foram exportados para PDF com sucesso.');
end

%% ========================================================================
%  FUNÇÃO LOCAL - ESTATÍSTICA DE MONTE CARLO (MÉDIA, DESVIO, IC95%, PERCENTIS)
% ========================================================================
function [media, desvio, n, ic_inf, ic_sup, p5, p50, p95] = calcula_estatisticas_MC(dadosBT)
    % dadosBT: matriz (24 x n_iteracoes) de tensão mínima por hora e iteração
    valorDiarioPorIteracao = min(dadosBT, [], 1); % tensão mínima diária por iteração
    n = length(valorDiarioPorIteracao);
    media = mean(valorDiarioPorIteracao);
    desvio = std(valorDiarioPorIteracao);

    if n > 1
        erro_padrao = desvio / sqrt(n);
        t_critico = tinv(0.975, n-1);
        ic_inf = media - t_critico * erro_padrao;
        ic_sup = media + t_critico * erro_padrao;
    else
        ic_inf = media;
        ic_sup = media;
    end

    p5  = prctile(valorDiarioPorIteracao, 5);
    p50 = prctile(valorDiarioPorIteracao, 50);
    p95 = prctile(valorDiarioPorIteracao, 95);
end