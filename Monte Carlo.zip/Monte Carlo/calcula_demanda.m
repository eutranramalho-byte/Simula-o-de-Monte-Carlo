function [demanda_ER, postos] = calcula_demanda(num_modo4,qtd_ER,TAXI,migrado_EL,PRIVADO)
    VEs = readtable("VEs.xlsx");
    ERs = readtable("ERs.xlsx");

    % Parâmetros da Componente 1 (Diurna)
    mu1 = 12.2;
    sigma1 = 3.8;
    
    % Parâmetros da Componente 2 (Noturna)
    mu2 = 21.0;
    sigma2 = 2.4;

    % mu = 12;
    % sigma = 2;
    mu_d = 230.5882; %TAXI.Distancia_km(1); 
    sigma_d = 67.6591; %TAXI.Distancia_km(2); 
    t_total_min = 24 * 60; % simulação em minutos;

    num_taxi_base = num_modo4 - migrado_EL;
    
    % Definir horario de recarga para cada VE
    VEs = VEs(strcmp(VEs.Tipo, 'BEV'), :);
    pesos = VEs.PROB;
    lista_VEs = table('Size', [0, 6], 'VariableTypes', {'string', 'double', 'double', 'double', 'double', 'double'}, 'VariableNames', {'ID', 'INICIO', 'KWh', 'MAX_KW', 'AUTONOMIA', 'SoC_ini'});
    for n = 1:num_modo4
        id = sprintf('veh_%g', n);
        % inicio = normrnd(mu, sigma);

        if rand < 0.5 % 50% de chance: Componente Diurna        
            inicio = normrnd(mu1, sigma1);
        else % 50% de chance: Componente Noturna    
            inicio = normrnd(mu2, sigma2);
        end
        inicio = mod(inicio, 24);

        idx_ponderado = randsample(height(VEs), 1, true, pesos);
        veh = VEs(idx_ponderado, :);
        if n <= num_taxi_base
            dis = max(0, normrnd(mu_d, sigma_d));
        else
            dis = max(0, normrnd(PRIVADO.Distancia_km(1), PRIVADO.Distancia_km(2)));
        end
        if dis > veh.AUTONOMIA; dis = veh.AUTONOMIA;end
        SoC_ini = (1 - dis / veh.AUTONOMIA);
        if SoC_ini < 0, SoC_ini = 0.01; end % Garante que o SoC não seja negativo
        novaLinha = {id, inicio, veh.KWh, veh.MAX_KW, veh.AUTONOMIA, SoC_ini};
        lista_VEs(end+1, :) = novaLinha;
    end
    
    % Definir parâmetros para cada ER
    lista_ERs = table('Size', [0, 4], 'VariableTypes', {'string', 'double', 'double','double'}, 'VariableNames', {'ID', 'KW','kv', 'PLUGUES'});
    for n = 1:qtd_ER
        id = sprintf('Posto_%g', n);
        posto = ERs(randi(length(ERs.FABRICANTE)), :);
        novaLinha = {id, posto.POTENCIA,posto.kv, posto.PLUGUES};
        lista_ERs(end+1, :) = novaLinha;
    end
    lista_VEs = sortrows(lista_VEs, 'INICIO');
    lista_VEs.INICIO = round(lista_VEs.INICIO * 60);
    
    
    SOC_CRITICO = 0.95; 
    SOC_ALVO = 1;
    
    % Adiciona colunas de estado para rastrear os VEs durante a simulação
    lista_VEs.SoC_atual = lista_VEs.SoC_ini;
    % Estados: esperando, aguardando_vaga, carregando, concluido
    lista_VEs.Estado = repmat("esperando", height(lista_VEs), 1); 
    lista_VEs.ER_ID = zeros(height(lista_VEs), 1); % ID do ER onde o VE está
    
    % Matriz para armazenar o perfil de demanda de cada eletroposto
    demanda_ERs = zeros(t_total_min, qtd_ER);
    colnames = lista_ERs.ID;
    demanda_ERs = array2table(demanda_ERs, 'VariableNames', colnames);
   
    for t_atual = 1:t_total_min
        
        % Encontra VEs cujo tempo de início é agora e que têm SoC baixo
        indices_para_carregar = find(lista_VEs.INICIO == t_atual & lista_VEs.SoC_atual < SOC_CRITICO & lista_VEs.Estado == "esperando");
        
        for i = 1:length(indices_para_carregar)
            idx_ve = indices_para_carregar(i);
            
            % Gera uma ordem aleatória para verificar os postos
            ordem_aleatoria_postos = randperm(qtd_ER);
            posto_encontrado = false;
            
            for j = 1:qtd_ER
                id_er_aleatorio = ordem_aleatoria_postos(j);
                
                % Verifica vagas no posto sorteado
                veiculos_no_posto = find(lista_VEs.ER_ID == id_er_aleatorio & (lista_VEs.Estado == "carregando" | lista_VEs.Estado == "aguardando_vaga"));
                vagas_ocupadas = length(veiculos_no_posto);
                
                if vagas_ocupadas < lista_ERs.PLUGUES(id_er_aleatorio)
                    % Vaga encontrada! Atribui o VE a este ER.
                    lista_VEs.Estado(idx_ve) = "carregando";
                    lista_VEs.ER_ID(idx_ve) = id_er_aleatorio;
                    posto_encontrado = true;
                    break; % Para de procurar postos
                end
            end
            
            % Se, após verificar todos os postos, nenhum tinha vaga
            if ~posto_encontrado
                % Deixa o veículo esperando no último posto da busca aleatória
                ultimo_posto_verificado = ordem_aleatoria_postos(end);
                lista_VEs.Estado(idx_ve) = "aguardando_vaga";
                lista_VEs.ER_ID(idx_ve) = ultimo_posto_verificado;
            end
        end
        
        % CALCULA A DEMANDA PARA CADA ELETROPOSTO E ATUALIZA SOC
        for id_er = 1:qtd_ER
            
            % Identifica os veículos que estão efetivamente carregando neste posto
            indices_ve_carregando = find(lista_VEs.Estado == "carregando" & lista_VEs.ER_ID == id_er);
            
            if isempty(indices_ve_carregando)
                demanda_ERs{t_atual, id_er} = 0; % Garante que a demanda seja zero se não houver carros
            else
                % Pega as potências desejadas
                potencias_desejadas = lista_VEs.MAX_KW(indices_ve_carregando);
                soma_desejada_kw = sum(potencias_desejadas);
    
                % Aplica o balanceamento de carga
                potencia_max_posto_kw = lista_ERs.KW(id_er);
                fator_balanceamento = min(1.0, potencia_max_posto_kw / soma_desejada_kw);
    
                % Calcula potência real, atualiza SoC e verifica conclusão
                potencia_total_real_kw = 0;
                for i = 1:length(indices_ve_carregando)
                    idx_ve = indices_ve_carregando(i);
                    pot_real_ve = potencias_desejadas(i) * fator_balanceamento;
                    potencia_total_real_kw = potencia_total_real_kw + pot_real_ve;
                    
                    energia_kwh_no_minuto = pot_real_ve * (1/60);
                    soc_adicionado = energia_kwh_no_minuto / lista_VEs.KWh(idx_ve);
                    lista_VEs.SoC_atual(idx_ve) = lista_VEs.SoC_atual(idx_ve) + soc_adicionado;
    
                    if lista_VEs.SoC_atual(idx_ve) >= SOC_ALVO
                        lista_VEs.Estado(idx_ve) = "concluido";
                        lista_VEs.ER_ID(idx_ve) = 0;
                    end
                end
                
                % Armazena a demanda total do posto neste minuto
                demanda_ERs{t_atual, id_er} = potencia_total_real_kw;
            end
            
            % PROMOVE VEÍCULOS EM ESPERA SE VAGAS FORAM LIBERADAS
            veiculos_carregando_agora = find(lista_VEs.Estado == "carregando" & lista_VEs.ER_ID == id_er);
            vagas_livres = lista_ERs.PLUGUES(id_er) - length(veiculos_carregando_agora);
            
            if vagas_livres > 0
                % Encontra os veículos que estão esperando neste posto
                indices_esperando = find(lista_VEs.Estado == "aguardando_vaga" & lista_VEs.ER_ID == id_er);
                
                % Promove para "carregando" o número de veículos correspondente às vagas livres
                num_a_promover = min(vagas_livres, length(indices_esperando));
                if num_a_promover > 0
                    lista_VEs.Estado(indices_esperando(1:num_a_promover)) = "carregando";
                end
            end
        end
    end

    intervalo_min = 15;
    num_intervalos = t_total_min / intervalo_min;
    demanda_media_15min = array2table(zeros(num_intervalos, qtd_ER), 'VariableNames', colnames);
    
    for i = 1:num_intervalos
        inicio_bloco = (i - 1) * intervalo_min + 1;
        fim_bloco = i * intervalo_min;
        bloco_dados = demanda_ERs{inicio_bloco:fim_bloco, :};
        media_intervalo = mean(bloco_dados);
        demanda_media_15min{i, :} = media_intervalo;
    end
  
    intervalos_tempo_min = (1:num_intervalos)' * intervalo_min;
    demanda_media_15min.Tempo_Final_Min = (intervalos_tempo_min)/(15*4);
    demanda_media_15min = movevars(demanda_media_15min, 'Tempo_Final_Min', 'Before', 1);

    demanda_ER=demanda_media_15min;
    postos=lista_ERs;
end

