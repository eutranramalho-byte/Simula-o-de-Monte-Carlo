function esta_rapidas = alocarEletropostos(Ali,UNTRD,UCBT,SSDMT,EQTRD,TTEN,DESCR,PRIVADO,TAXI,VEs,TAXA_GLOBAL,qtd_ER,num_caso)
    
    N2 = sprintf("Eletropostos_EL_%s",Ali);
    N3 = sprintf("Eletropostos_ES_%s",Ali);
    N4 = sprintf("Eletropostos_ER_%s",Ali);
    hora_ocupacao = 24*4;
    
    N_Carros = round(32564/9);

    % pasta_destino = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Todos os alimentadores\\Aimentador%s', Ali);
    pasta_destino = sprintf("D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Alimentador%s", num_caso,Ali);

    contador_trifasico = 1;
    contador_monofasico = 1;
    trafo_id_map = containers.Map('KeyType', 'char', 'ValueType', 'char');
    
    rows_UNTRD = size(UNTRD,1);
    for i = 1:rows_UNTRD
        codigo= string(UNTRD.COD_ID(i));
        fases1 = string(UNTRD.FAS_CON_P(i));
        switch fases1
            case {"A","B","C","AN","BN","CN"}, tipo=1; 
            case {"AB", "BC", "CA", "ABN", "BCN", "CAN"}, tipo=2; 
            case {"ABC","ABCN"}, tipo=3;
        end
        id_unico = '';
        if tipo == 3 % Trifásico
            id_unico = sprintf('T%d', contador_trifasico);
            contador_trifasico = contador_trifasico + 1;
        elseif tipo == 1 || tipo == 2 % Monofásico ou Bifásico
            id_unico = sprintf('M%d', contador_monofasico);
            contador_monofasico = contador_monofasico + 1;
        end
        
        % Armazena a associação no mapa para uso posterior
        if ~isempty(id_unico)
            trafo_id_map(codigo) = id_unico;
        end
    end

    % Escrita eletropostos
    fprintf("\nEscrevendo arquivos %s...",N2)
    nome_arquivo_el = sprintf('%s.dss', N2);
    caminho_el = fullfile(pasta_destino, nome_arquivo_el);
    fid = fopen(caminho_el, 'wt');
    
    npts = 96; %Numero de pontos no loadshape
    % interval = 1/(npts/24);
    npts_hora = npts/24;
    
    %num_total_eletropostos = round(length(UCBT(contains(UCBT.TIP_CC,"RES"),:).OBJECTID) * TAXA_GLOBAL);
    %num_total_eletropostos = min(num_total_eletropostos,N_Carros);
    num_total_eletropostos = round(TAXA_GLOBAL*N_Carros);
    
    if num_caso == 11
        prop_modo2 = 0.65;
        prop_modo4 = 0.17;
    elseif num_caso == 12
        prop_modo2 = 0.60;
        prop_modo4 = 0.22;
    elseif num_caso == 13
        prop_modo2 = 0.55;
        prop_modo4 = 0.27;
    elseif num_caso == 14
        prop_modo2 = 0.50;
        prop_modo4 = 0.32;
    else
        prop_modo2 = 0.70;
        prop_modo4 = 0.12;
    end
    prop_modo3 = 0.18;

    num_modo2 = round(num_total_eletropostos * prop_modo2);
    num_modo3 = round(num_total_eletropostos * prop_modo3);
    num_modo4 = round(num_total_eletropostos * prop_modo4);
    
    indices_residenciais = contains(UCBT.TIP_CC, "RES");
    candidatos_modo2 = UCBT(indices_residenciais, :);
    exedente2 = 0;
    exedente3 = 0;
    if length(candidatos_modo2.OBJECTID) < num_modo2
        exedente2 = num_modo2 - length(candidatos_modo2.OBJECTID);
        num_modo2  = length(candidatos_modo2.OBJECTID);
    end
    
    indices_comerciais = contains(UCBT.TIP_CC, "COM");
    candidatos_modo3 = UCBT(indices_comerciais, :);

    if length(candidatos_modo3.OBJECTID) < num_modo3
        exedente3 = num_modo3 - length(candidatos_modo3.OBJECTID);
        num_modo3  = length(candidatos_modo3.OBJECTID);
    end

    num_modo4 = num_modo4 + exedente2 + exedente3;
    migrado_EL = num_modo4 - round(0.12*num_total_eletropostos);
    
    SSDMT_TEMP = SSDMT(strcmp(SSDMT.FAS_CON,"ABC"),:);
    barramentos_mt = unique([SSDMT_TEMP.PN_CON_1; SSDMT_TEMP.PN_CON_2]);
    
    % Cria a tabela final com os consumidores residenciais que receberão os carregadores
    indices_selecionados_res = randperm(height(candidatos_modo2), num_modo2);
    EL_MODO2 = candidatos_modo2(indices_selecionados_res, :);
    
    indices_selecionados_com = randperm(height(candidatos_modo3), num_modo3);
    ES_MODO3 = candidatos_modo3(indices_selecionados_com, :);
    
    indices_selecionados_mt = randperm(length(barramentos_mt), qtd_ER);
    ER_MODO4 = barramentos_mt(indices_selecionados_mt);
    
    % CARREGADORES = readtable("Especificacoes_VEs.xlsx");
    % CARREGADORES.MODO_REC=string(CARREGADORES.MODO_REC);
    CARREGADORES_EL = readtable("ELs.xlsx");
    CARREGADORES_ES = readtable("ESs.xlsx");

    VEs_EL_Es = VEs(strcmp(VEs.Tipo,"PHEV"),:);

    pesos = VEs_EL_Es.PROB;

    mu_inicio(1:3)=[18,15,12];
    if num_caso == 5 
        mu_inicio(1) = 23; % Residencial (EL) começa em média às 23h
    elseif num_caso == 6 
        mu_inicio(1) = 16;
    elseif num_caso == 7 
        mu_inicio(1) = 21;
    elseif num_caso == 8 
        mu_inicio(1) = 1;
    elseif num_caso == 9 
        mu_inicio(1) = 2;
    elseif num_caso == 10 
        mu_inicio(1) = 3;
    else
        mu_inicio(1) = 18; % Residencial (EL) padrão às 18h
    end

    sigma_inicio=3;
    
    SoC_max = 0.97;

    for i = 1:length(EL_MODO2.OBJECTID)
        codigo = string(EL_MODO2.OBJECTID(i));
        fases = string(EL_MODO2.FAS_CON(i));
        ponto = string(EL_MODO2.PN_CON(i));
        trafo_id_da_carga = string(EL_MODO2.UNI_TR_MT(i));
     
        switch fases
            case {"A"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
            case {"B"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
            case {"C"}, conex2 = ".3.0"; conn = "wye"; phase = "1";
            case {"AN"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
            case {"BN"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
            case {"CN"}, conex2 = ".3.0"; conn = "wye"; phase = "1";
            case {"AB"}, conex2 = ".1.2"; conn = "delta"; phase = "1";
            case {"BC"}, conex2 = ".2.3"; conn = "delta"; phase = "1";
            case {"CA"}, conex2 = ".3.1"; conn = "delta"; phase = "1";
            case {"ABN"}, conex2 = ".1.2.0"; conn = "wye"; phase = "2";
            case {"BCN"}, conex2 = ".2.3.0"; conn = "wye"; phase = "2";
            case {"CAN"}, conex2 = ".3.1.0"; conn = "wye"; phase = "2";
            case {"ABC"}, conex2 = ".1.2.3"; conn = "delta"; phase = "3";
            case {"ABCN"}, conex2 = ".1.2.3.0"; conn = "wye"; phase = "3";
            otherwise, continue; % Pula se a fase não for reconhecida
        end
        
        if phase == '3'
            CARREGADORES_EL_ATUAL = CARREGADORES_EL(strcmp(CARREGADORES_EL.TIPO,'TRIFASICO'),:);
            indice = randi(height(CARREGADORES_EL_ATUAL));
        elseif ismember(phase, ["1","2"])
            CARREGADORES_EL_ATUAL = CARREGADORES_EL(strcmp(CARREGADORES_EL.TIPO,'BIFASICO'),:);
            indice = randi(height(CARREGADORES_EL_ATUAL));
        end

        
        ATUAL_EL = CARREGADORES_EL_ATUAL(indice, :);
        idx_ponderado = randsample(height(VEs_EL_Es), 1, true, pesos);
        veh = VEs_EL_Es(idx_ponderado,:);
        Pot = min(ATUAL_EL.POTENCIA,veh.MAX_KW);
        Cap = veh.KWh;
    
        linh_trafo = EQTRD(strcmp(EQTRD.UNI_TR_MT, EL_MODO2.UNI_TR_MT{i}), :);
        if isempty(linh_trafo), continue; end
    
        if ~isKey(trafo_id_map, trafo_id_da_carga)
            fprintf('AVISO: Eletroposto para carga %s pulado. O transformador ID %s não foi encontrado no mapa.\n', codigo, trafo_id_da_carga);
            continue;
        end
    
        kv = TTEN(string(TTEN.COD_ID) == linh_trafo.TEN_SEC, 2).TEM/1000;
        if linh_trafo.LIG_FAS_S == "ABCN" && (ismember(fases,["AN","BN","CN"]))
            kv = kv/sqrt(3);
        end
        if (ismember(linh_trafo.LIG_FAS_S,["AN","BN","CN"])) && (string(linh_trafo.LIG_FAS_T) ~= '0') && (ismember(fases,["AN","BN","CN"]))
            kv = kv/2;
        end
    
        id_unico = trafo_id_map(trafo_id_da_carga);
        bus_final = sprintf('BT_%s_%s%s', ponto, id_unico, conex2);

        idx_ponderado = randsample(height(VEs_EL_Es), 1, true, pesos);
        veh = VEs_EL_Es(idx_ponderado, :);
        dis = max(0, normrnd(PRIVADO.Distancia_km(1), PRIVADO.Distancia_km(2)));
        if dis > veh.AUTONOMIA; dis = veh.AUTONOMIA;end
        SoC_ini = 1 - dis/veh.AUTONOMIA;
        if SoC_ini < 0, SoC_ini = 0.01; end
        D = round(npts_hora*((Cap*(SoC_max - SoC_ini) + 2*Cap*(1 - SoC_max))/Pot));
        if D < 0, D = 0; end
    
        inicio_con = round(npts_hora*(normrnd(mu_inicio(1), sigma_inicio)));
        inicio_con = mod(inicio_con - 1, npts) + 1;
        multiplicadores_EL = zeros(1,npts);
        fim_con = inicio_con + D;
        resto=mod(fim_con,npts);
        
        if resto == fim_con
           multiplicadores_EL(inicio_con:fim_con-1)=-1;
        else
            if resto > 1
               multiplicadores_EL(inicio_con:end)=-1;
               multiplicadores_EL(1:resto-1)=-1;
            elseif resto == 1
               multiplicadores_EL(inicio_con:end)=-1;
            else
               multiplicadores_EL(inicio_con:end-1)=-1;
            end
        end
        multiplicadores_EL = Pot*(abs(multiplicadores_EL));
        multiplicadores_EL = -(sum(reshape(multiplicadores_EL, 4, []), 1)')/(4*Pot);
        % Escreve o Loadshape
        curva = sprintf('Curva_storage_EL%g', i);
        %fprintf(fid, 'New Loadshape.%s npts=%g interval=%.4f mult=[', curva,npts,interval);
        fprintf(fid, 'New Loadshape.%s npts=24 interval=1 mult=[', curva);
        fprintf(fid, ' %.4f', multiplicadores_EL); % Escreve os multiplicadores calculados
        fprintf(fid, ' ]\n\n');
    
        fprintf(fid, 'New Storage.Carregador_%s Bus1=%s Phases=%s Conn=%s kV=%g kWrated=%.2f kWhrated=%.2f PF=1.0 %%stored=%.2f %%reserve=0 %%charge=100 %%discharge=0 dispmode=follow %%EffCharge=95 daily=%s\n\n', ...
        codigo, bus_final, phase, conn, kv, Pot, Cap, SoC_ini*100, curva);
    end
    fclose(fid);
    
    fprintf("\nEscrevendo arquivos %s...",N3)
    nome_arquivo_es = sprintf('%s.dss', N3);
    caminho_el = fullfile(pasta_destino, nome_arquivo_es);
    fid = fopen(caminho_el, 'wt');
    for i = 1:length(ES_MODO3.OBJECTID)
        codigo = string(ES_MODO3.OBJECTID(i));
        fases = string(ES_MODO3.FAS_CON(i));
        ponto = string(ES_MODO3.PN_CON(i));
        trafo_id_da_carga = string(ES_MODO3.UNI_TR_MT(i));
        
        switch fases
            case {"A"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
            case {"B"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
            case {"C"}, conex2 = ".3.0"; conn = "wye"; phase = "1";
            case {"AN"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
            case {"BN"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
            case {"CN"}, conex2 = ".3.0"; conn = "wye"; phase = "1";
            case {"AB"}, conex2 = ".1.2"; conn = "delta"; phase = "1";
            case {"BC"}, conex2 = ".2.3"; conn = "delta"; phase = "1";
            case {"CA"}, conex2 = ".3.1"; conn = "delta"; phase = "1";
            case {"ABN"}, conex2 = ".1.2.0"; conn = "wye"; phase = "2";
            case {"BCN"}, conex2 = ".2.3.0"; conn = "wye"; phase = "2";
            case {"CAN"}, conex2 = ".3.1.0"; conn = "wye"; phase = "2";
            case {"ABC"}, conex2 = ".1.2.3"; conn = "delta"; phase = "3";
            case {"ABCN"}, conex2 = ".1.2.3.0"; conn = "wye"; phase = "3";
            otherwise, continue; % Pula se a fase não for reconhecida
        end

        if phase == '3'
            CARREGADORES_ES_ATUAL = CARREGADORES_ES(strcmp(CARREGADORES_ES.TIPO,'TRIFASICO'),:);
            indice = randi(height(CARREGADORES_ES_ATUAL));
        elseif ismember(phase, ["1","2"])
            CARREGADORES_ES_ATUAL = CARREGADORES_ES(strcmp(CARREGADORES_ES.TIPO,'BIFASICO'),:);
            indice = randi(height(CARREGADORES_ES_ATUAL));
        end

        
        ATUAL_ES = CARREGADORES_ES_ATUAL(indice, :);
        idx_ponderado = randsample(height(VEs_EL_Es), 1, true, pesos);
        veh = VEs_EL_Es(idx_ponderado,:);
        Pot = min(ATUAL_ES.POTENCIA,veh.MAX_KW);
        Cap = veh.KWh;
    
        linh_trafo = EQTRD(strcmp(EQTRD.UNI_TR_MT, ES_MODO3.UNI_TR_MT{i}), :);
        if isempty(linh_trafo), continue; end
    
        if ~isKey(trafo_id_map, trafo_id_da_carga)
            fprintf('AVISO: Eletroposto para carga %s pulado. O transformador ID %s não foi encontrado no mapa.\n', codigo, trafo_id_da_carga);
            continue;
        end
    
        kv = TTEN(string(TTEN.COD_ID) == linh_trafo.TEN_SEC, 2).TEM/1000;
        if linh_trafo.LIG_FAS_S == "ABCN" && (ismember(fases,["AN","BN","CN"]))
            kv = kv/sqrt(3);
        end
        if (ismember(linh_trafo.LIG_FAS_S,["AN","BN","CN"])) && (string(linh_trafo.LIG_FAS_T) ~= '0') && (ismember(fases,["AN","BN","CN"]))
            kv = kv/2;
        end
    
        id_unico = trafo_id_map(trafo_id_da_carga);
        bus_final = sprintf('BT_%s_%s%s', ponto, id_unico, conex2);

        dis = max(0, normrnd(PRIVADO.Distancia_km(1), PRIVADO.Distancia_km(2)));
        if dis > veh.AUTONOMIA; dis = veh.AUTONOMIA;end
        SoC_ini = 1 - dis/veh.AUTONOMIA;
     
        if SoC_ini < 0, SoC_ini = 0.01; end
        D = round(npts_hora*((Cap*(SoC_max - SoC_ini) + 2*Cap*(1 - SoC_max))/Pot));
        if D < 0, D = 0; end
    
        inicio_con = round(npts_hora*(normrnd(mu_inicio(2), sigma_inicio)));
        inicio_con = mod(inicio_con - 1, npts) + 1;
    
        multiplicadores_EL = zeros(1,npts);
        fim_con = inicio_con + D;
        resto=mod(fim_con,npts);
        
        if resto == fim_con
           multiplicadores_EL(inicio_con:fim_con-1)=-1;
        else
            if resto > 1
               multiplicadores_EL(inicio_con:end)=-1;
               multiplicadores_EL(1:resto-1)=-1;
            elseif resto == 1
               multiplicadores_EL(inicio_con:end)=-1;
            else
               multiplicadores_EL(inicio_con:end-1)=-1;
            end
        end
        multiplicadores_EL = Pot*(abs(multiplicadores_EL));
        multiplicadores_EL = -(sum(reshape(multiplicadores_EL, 4, []), 1)')/(4*Pot);
        % Escreve o Loadshape
        curva = sprintf('Curva_storage_ES%g', i);
        % fprintf(fid, 'New Loadshape.%s npts=%g interval=%.4f mult=[', curva,npts,interval);
        fprintf(fid, 'New Loadshape.%s npts=24 interval=1 mult=[', curva);
        fprintf(fid, ' %.4f', multiplicadores_EL); % Escreve os multiplicadores calculados
        fprintf(fid, ' ]\n\n');
    
        fprintf(fid, 'New Storage.Carregador_%s Bus1=%s Phases=%s Conn=%s kV=%g kWrated=%.2f kWhrated=%.2f PF=1.0 %%stored=%.2f %%reserve=0 %%charge=100 %%discharge=0 dispmode=follow %%EffCharge=95 daily=%s\n\n', ...
        codigo, bus_final, phase, conn, kv, Pot, Cap, SoC_ini*100, curva);
    end
    fclose(fid);
    
    fprintf("\nEscrevendo arquivos %s...",N4)
    nome_arquivo_er = sprintf('%s.dss', N4);
    caminho_er = fullfile(pasta_destino, nome_arquivo_er);
    fid = fopen(caminho_er, 'wt');
    
    [demanda_ER, postos] = calcula_demanda(num_modo4,qtd_ER,TAXI,migrado_EL,PRIVADO);
    
    UNTRD_TEMP=UNTRD(strcmp(UNTRD.FAS_CON_P,"ABC"),:);
    EQTRD_TEMP=EQTRD(strcmp(EQTRD.FAS_CON,"ABC"),:);
    for i = 1:qtd_ER
        MODO4_TEMP = SSDMT_TEMP(strcmp(SSDMT_TEMP.PN_CON_1,ER_MODO4(i)),:);
        if isempty(MODO4_TEMP)
            MODO4_TEMP = SSDMT_TEMP(strcmp(SSDMT_TEMP.PN_CON_2,ER_MODO4(i)),:);
        end
        codigo = string(MODO4_TEMP.OBJECTID(1));
        PN_2 = string(ER_MODO4(i));           
    
        Pot = postos.KW(i);
        Cap = sum(demanda_ER{:,1+i}*0.25);
    
        trafo_filtrado = UNTRD_TEMP(UNTRD_TEMP.POT_NOM >= Pot,:);
        trafo_filtrado = sortrows(trafo_filtrado,"POT_NOM");
    
        fases1 = string(trafo_filtrado.FAS_CON_P(1));
        fases2 = string(trafo_filtrado.FAS_CON_S(1));
    
        eqtrd_fil = EQTRD_TEMP(strcmp(string(EQTRD_TEMP.UNI_TR_MT),string(trafo_filtrado.COD_ID(1))),:);
        
        kva = trafo_filtrado.POT_NOM(1);
        xhl=eqtrd_fil.XHL(1);
        noloadloss = trafo_filtrado.PER_FER(1)/(kva*10);
        loadloss = (trafo_filtrado.PER_TOT(1) - trafo_filtrado.PER_FER(1))/(kva*10);
        res=eqtrd_fil.R(1);
        tap = trafo_filtrado.TAP(1);
        kva = trafo_filtrado.POT_NOM(1);
    
        switch fases1
            case {"A"}, conn1="wye"; phase="1";conex1 = ".1";
            case {"B"}, conn1="wye"; phase="1";conex1 = ".2";
            case {"C"}, conn1="wye"; phase="1";conex1 = ".3";
            case {"AN"}, conn1="wye"; phase="1";conex1 = ".1.0";
            case {"BN"}, conn1="wye"; phase="1";conex1 = ".2.0";
            case {"CN"}, conn1="wye"; phase="1";conex1 = ".3.0";
            case {"AB"}, conn1="delta"; phase="2";conex1 = ".1.2";
            case {"BC"}, conn1="delta"; phase="2";conex1 = ".2.3";
            case {"CA"}, conn1="delta"; phase="2";conex1 = ".3.1";
            case {"ABN"}, conn1="wye"; phase="2";conex1 = ".1.2.0";
            case {"BCN"}, conn1="wye"; phase="2";conex1 = ".2.3.0";
            case {"CAN"}, conn1="wye"; phase="2";conex1 = ".3.1.0";
            case {"ABC"}, conn1="delta"; phase="3";conex1 = ".1.2.3";
            case {"ABCN"}, conn1="wye"; phase="3";conex1 = ".1.2.3.0";
        end
    
        switch fases2
            case {"A"},conn2="wye"; conex2 = ".1";
            case {"B"}, conn2="wye"; conex2 = ".2";
            case {"C"}, conn2="wye"; conex2 = ".3";
            case {"AN"}, conn2="wye"; conex2 = ".1.0";
            case {"BN"}, conn2="wye"; conex2 = ".2.0";
            case {"CN"}, conn2="wye"; conex2 = ".3.0";
            case {"AB"}, conn2="delta"; conex2 = ".1.2";
            case {"BC"}, conn2="delta"; conex2 = ".2.3";
            case {"CA"}, conn2="delta"; conex2 = ".3.1";
            case {"ABN"}, conn2="wye"; conex2 = ".1.2.0";
            case {"BCN"}, conn2="wye"; conex2 = ".2.3.0";
            case {"CAN"}, conn2="wye"; conex2 = ".3.1.0";
            case {"ABC"}, conn2="delta"; conex2 = ".1.2.3";
            case {"ABCN"}, conn2="wye"; conex2 = ".1.2.3.0";
        end
        
        if isempty(eqtrd_fil), continue; end
    
        %kv = TTEN(string(TTEN.COD_ID) == eqtrd_fil.TEN_SEC, 2).TEM/1000;
        kv = postos.kv(i);
        
        SoC_ini = 0;
        multiplicadores_EL = (demanda_ER{:,1+i}/Pot);
        multiplicadores_EL = -(sum(reshape(multiplicadores_EL, 4, []), 1)')/4;
    
        %Escreve o trafo dedicado
    
        fprintf(fid,'New transformer.ER%g_%s xhl = %g windings = 2 %%loadloss = %g %%noloadloss = %g phases = %s  \n', i, codigo, xhl, loadloss, noloadloss, phase);
        fprintf(fid,'~ wdg = 1 bus = %s%s kv = %g kva = %g conn = %s %%r = %g tap = 0.99 \n',PN_2,conex1, DESCR, kva, conn1, res);
        fprintf(fid,'~ wdg = 2 bus = BT_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n\n', PN_2, conex2, kv, kva, conn2, res, tap);
    
        % Escreve o Loadshape
        curva = sprintf('Curva_storage_ER%g', i);
        % fprintf(fid, 'New Loadshape.%s npts=%g interval=%.4f mult=[', curva,npts,interval);
        fprintf(fid, 'New Loadshape.%s npts=24 interval=1 mult=[', curva);
        fprintf(fid, ' %.4f', multiplicadores_EL); % Escreve os multiplicadores calculados
        fprintf(fid, ' ]\n\n');
    
        fprintf(fid, 'New Storage.Carregador_ER%g_%s Bus1=BT_%s%s Phases=%s Conn=%s kv=%g kWrated=%.2f kWhrated=%.2f PF=1.0 %%stored=%.2f %%reserve=0 %%charge=100 %%discharge=0 dispmode=follow %%EffCharge=95 daily=%s\n\n', ...
        i, codigo, PN_2 , conex2, phase, conn2, kv, Pot, Cap, SoC_ini*100, curva);
    end
    fclose(fid);

    taxa_ocupacao = zeros(length(ER_MODO4),1);
    esta_rapidas = table(postos.ID,ER_MODO4,taxa_ocupacao,'VariableNames',{'Postos','Barra','Taxa_Ocupacao'});
    N1 = length(ER_MODO4);
    for n = 1:N1
        auxiliar = demanda_ER{:,n+1};
        auxiliar = length(auxiliar( auxiliar > 0))/hora_ocupacao;
        esta_rapidas.Taxa_Ocupacao(n) = auxiliar;
    end
end