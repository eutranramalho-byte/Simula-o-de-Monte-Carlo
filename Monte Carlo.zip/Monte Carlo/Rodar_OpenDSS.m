clc
clear
close all
clear vars
%clear functions

%% ========================================================================
%  CARREGAR E FILTRAR OS DADOS BDGD
% ========================================================================

Ali='JMLT308';
%caso = [2;3;4;5];
%caso = [6;7;8;9;10]; % Variando horário médio de recarga em EL em: 16, 19, 1, 2 e 3 horas
caso = [11;12;13;14]; % Migrando VEs de ELs para ERs (ES fixo)--> 65/17 - 60/22 - 55/27 - 50/32
qtd_ER = 6;
taxa_aco_min = 0.3;
taxa_aco_max = 0.7;

% pasta_cenario = sprintf('Compile "D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Todos os alimentadores\\Aimentador%s\\MainCode.dss"', Ali);
% pasta_capacidades = sprintf("D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Todos os alimentadores\\Aimentador%s\\%s_EXP_CAPACITY.CSV", Ali,Ali);
% arquivo_tensoes= sprintf("D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Todos os alimentadores\\Aimentador%s\\%s_EXP_VOLTAGES.CSV", Ali,Ali);

UNTRD = readtable('D:\1_UFOP\ELÉTRICA\9º periodo\TCC 1\Todos os alimentadores\UNTRMT.xlsx');
UCBT = readtable('D:\1_UFOP\ELÉTRICA\9º periodo\TCC 1\Todos os alimentadores\UCBT.xlsx');
SSDMT = readtable('D:\1_UFOP\ELÉTRICA\9º periodo\TCC 1\Todos os alimentadores\SSDMT.xlsx');
EQTRD = readtable('D:\1_UFOP\ELÉTRICA\9º periodo\TCC 1\Todos os alimentadores\EQTRMT.xlsx');
CTMT = readtable('D:\1_UFOP\ELÉTRICA\9º periodo\TCC 1\Todos os alimentadores\CTMT.xlsx');
TTEN = readtable('TTEN.xlsx');
PRIVADO = readtable('D:\1_UFOP\ELÉTRICA\9º periodo\TCC 1\Monte Carlo\Dados do Sumo\Resultados_privado.xlsx');
TAXI = readtable('D:\1_UFOP\ELÉTRICA\9º periodo\TCC 1\Monte Carlo\Dados do Sumo\Resultados_taxi.xlsx');
VEs = readtable("VEs.xlsx");

feeder_info = CTMT(strcmp(CTMT.COD_ID, Ali), :);
tension_code = feeder_info.TEN_NOM(1);
DESCR_table = TTEN(TTEN.COD_ID == str2double(tension_code), 3);
DESCR = str2double(DESCR_table{1,1});

SSDMT = SSDMT(strcmp(SSDMT.CTMT, Ali), :);
SSDMT.PN_CON_1 = string(SSDMT.PN_CON_1); % Converte colunas de conexão para string
SSDMT.PN_CON_2 = string(SSDMT.PN_CON_2);
UCBT = UCBT(strcmp(UCBT.CTMT, Ali), :);
UNTRD = UNTRD(strcmp(UNTRD.CTMT, Ali), :);

%% ========================================================================
%  PARÂMETROS DA SIMULAÇÃO MONTE CARLO
% =========================================================================
stepsize_h = 1; % Passo de tempo em horas
n_pontos = 24;     % Número total de pontos (24h / 0.25h)

max_cenario = 100;
tolerancia = 0.0000001;

for nc = 1:length(caso)
    if caso(nc) == 1
        TAXA_GLOBAL = 0;
    elseif caso(nc) == 2
        TAXA_GLOBAL = 0.10;
    elseif caso(nc) == 3
        TAXA_GLOBAL = 0.50;
    elseif caso(nc) == 4
        TAXA_GLOBAL = 1.00;
    elseif caso(nc) == 5
        TAXA_GLOBAL = 1.00;
    else
        TAXA_GLOBAL = 1.00;
    end

    pasta_cenario = sprintf('Compile "D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Alimentador%s\\MainCode.dss"', caso(nc),Ali);
    pasta_capacidades = sprintf("D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Alimentador%s\\%s_EXP_CAPACITY.CSV", caso(nc),Ali,Ali);
    arquivo_tensoes= sprintf("D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Alimentador%s\\%s_EXP_VOLTAGES.CSV", caso(nc),Ali,Ali);
    pasta_monitor = sprintf("D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Alimentador%s\\%s_Mon_monitor_power_1.csv", caso(nc),Ali,Ali);

    arquivo_EL= sprintf("D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Alimentador%s\\Eletropostos_EL_%s.dss", caso(nc),Ali,Ali);
    arquivo_ES= sprintf("D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Alimentador%s\\Eletropostos_ES_%s.dss", caso(nc),Ali,Ali);
    arquivo_ER= sprintf("D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Alimentador%s\\Eletropostos_ER_%s.dss", caso(nc),Ali,Ali);
    
    pastaDestino = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s',caso(nc),Ali);
    if ~exist(pastaDestino, 'dir')
        mkdir(pastaDestino);
    end

    pastaPior = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s\\VOLTAGES_PIOR_CASO.csv',caso(nc),Ali);
    pastaPior_EL = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s\\Eletropostos_EL_PIOR.dss',caso(nc),Ali);
    pastaPior_ES = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s\\Eletropostos_ES_PIOR.dss',caso(nc),Ali);
    pastaPior_ER = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s\\Eletropostos_ER_PIOR.dss',caso(nc),Ali);

    pastaMelhor = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s\\VOLTAGES_MELHOR_CASO.csv',caso(nc),Ali);
    pastaMelhor_EL = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s\\Eletropostos_EL_MELHOR.dss',caso(nc),Ali);
    pastaMelhor_ES = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s\\Eletropostos_ES_MELHOR.dss',caso(nc),Ali);
    pastaMelhor_ER = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Monte Carlo\\Resultados\\caso%g\\Dados_Alimentador%s\\Eletropostos_ER_MELHOR.dss',caso(nc),Ali);

    Relatorio_ER = table('Size', [0, 8], ...
                         'VariableTypes', {'double', 'double', 'double', 'cell', 'double', 'double', 'string', 'double'}, ...
                         'VariableNames', {'Caso', 'Iteracao_MC', 'Qtd_ER_Input', 'Taxas_Ocupacao', 'Taxa_Min', 'Taxa_Max', 'Ajuste', 'Qtd_ER_Output'});
    VM_min = [];
    VB_min = [];
    
    Tensao_minima_diaria_MT = [];
    Tensao_minima_diaria_BT = [];
    
    flag_trafo = 0;
    flag_Vmin = 0;

    P_Total = [];
    Q_Total = [];
        
    PT_Perdas = [];
    QT_Perdas = [];

    PT_Perdas_Trafo = [];
    QT_Perdas_Trafo = [];

    PT_Perdas_MT = [];
    QT_Perdas_MT = [];

    PT_Perdas_BT = [];
    QT_Perdas_BT = [];

    T_min_med = [];
    med_anterior = 0;
    med_atual = 0;
    melhor_caso = 0;
    pior_caso = 2;
    
    %% ========================================================================
    %  INICIALIZAÇÃO DO OPENDSS
    % ========================================================================
    disp('Iniciando a interface com o OpenDSS...');
    % Criando objetos da interface COM
    DSSobj = actxserver('OpenDSSEngine.DSS');
    if ~DSSobj.Start(0)
        disp("O OpenDSS não iniciou. Verifique a instalação.");
        return
    end
    DSSText = DSSobj.Text;
    DSSCircuit = DSSobj.ActiveCircuit;
    DSSCktElement = DSSCircuit.ActiveCktElement;
    DSSBus = DSSCircuit.ActiveBus;
    DSSSolution = DSSCircuit.Solution;
    DSSLines = DSSCircuit.Lines;
    DSSLoads = DSSCircuit.Loads;
    DSSMeters = DSSCircuit.Meters;
    DSSLoses  = DSSCircuit.Losses;
    DSSMonitors = DSSCircuit.Monitors;
    DSSTransformers = DSSCircuit.Transformers;
    
    %% ========================================================================
    %  ETAPA 1: ANÁLISE DO HORÁRIO DE PICO (Ex: 20h)
    % ========================================================================
    for nt = 1:max_cenario
        fprintf("\nInteração %g\n",nt);
        disp('ETAPA 1: Analisando o final da simulação diária...');

        if caso(nc) ~= 1
            esta_rapidas = alocarEletropostos(Ali,UNTRD,UCBT,SSDMT,EQTRD,TTEN,DESCR,PRIVADO,TAXI,VEs,TAXA_GLOBAL,qtd_ER,caso(nc));

            taxas_atuais = esta_rapidas.Taxa_Ocupacao;
            taxa_min_atual = min(taxas_atuais);
            taxa_max_atual = max(taxas_atuais);

            qtd_ER_input = qtd_ER; 
            ajuste_decisao = "Manteve";

            if taxa_min_atual < taxa_aco_min 
                % Reduz para a próxima iteração, com mínimo de 1
                qtd_ER = max(1, qtd_ER - 1); 
                ajuste_decisao = "Diminuiu";
            elseif taxa_max_atual > taxa_aco_max
                % Aumenta para a próxima iteração
                qtd_ER = qtd_ER + 1; 
                ajuste_decisao = "Aumentou";
            end
            nova_linha = {caso(nc), nt, qtd_ER_input, {taxas_atuais'}, taxa_min_atual, taxa_max_atual, ajuste_decisao, qtd_ER};
            Relatorio_ER = [Relatorio_ER; nova_linha];
        end

        % Compila o circuito, preparando-o para a primeira simulação
        DSSText.command = pasta_cenario;
        
        % Configura e resolve para o dia todo. O resultado final será o do último instante (t=24h)
        DSSText.Command = 'set mode=daily';
        % DSSText.Command = 'set hour=19';
        % DSSSolution.Solve;
        DSSText.Command = ['set stepsize=' num2str(stepsize_h) 'h'];
        DSSText.Command = 'set number=1';
  
        P_Perdas = zeros(n_pontos,1);
        Q_Perdas = zeros(n_pontos,1);
        perda_P_trafo = zeros(n_pontos,1);
        perda_Q_trafo = zeros(n_pontos,1);
        perdas_P_MT_diaria = zeros(n_pontos,1);
        perdas_Q_MT_diaria = zeros(n_pontos,1); 
        perdas_P_BT_diaria = zeros(n_pontos,1);
        perdas_Q_BT_diaria = zeros(n_pontos,1);
        for nn = 1:n_pontos
            DSSSolution.Solve;
            disp('Coletando dados de tensão no final da simulação...');
            %% Inicializa os vetores para armazenar os dados de MT
            DistA = []; VA = [];
            DistB = []; VB = [];
            DistC = []; VC = [];
            AllBusNames = DSSCircuit.AllBusNames;
            tensao_base_mt_minima = 1.0; 
            for i = 1:length(AllBusNames)
                DSSCircuit.SetActiveBus(AllBusNames{i});
                if DSSBus.kVBase > tensao_base_mt_minima
                    distancia = DSSBus.Distance;
                    nodes = DSSBus.Nodes;
                    puV = DSSBus.puVmagAngle;
                    if any(nodes == 1)
                        idx = find(nodes == 1);
                        DistA = [DistA; distancia];
                        VA = [VA; puV(2*idx - 1)];
                    end
                    if any(nodes == 2)
                        idx = find(nodes == 2);
                        DistB = [DistB; distancia];
                        VB = [VB; puV(2*idx - 1)];
                    end
                    if any(nodes == 3)
                        idx = find(nodes == 3);
                        DistC = [DistC; distancia];
                        VC = [VC; puV(2*idx - 1)];
                    end
                end
            end
       
            %% Inicializa os vetores para armazenar os dados de BT
            DistA_BT = []; VA_BT = [];
            DistB_BT = []; VB_BT = [];
            DistC_BT = []; VC_BT = [];
           
            limite_tensao_bt = 1.0;  % Define o limite de tensão para identificar as barras de BT (qualquer barra abaixo de 1.0 kV)

            AllBusNames = DSSCircuit.AllBusNames;
            for i = 1:length(AllBusNames)
                DSSCircuit.SetActiveBus(AllBusNames{i});
                
                % Filtro: seleciona apenas as barras com tensão base ABAIXO do limite e maior que zero
                if DSSBus.kVBase < limite_tensao_bt && DSSBus.kVBase > 0
                    distancia = DSSBus.Distance; 
                    nodes = DSSBus.Nodes;        
                    puV = DSSBus.puVmagAngle;    
                    
                    if any(nodes == 1)
                        idx = find(nodes == 1, 1);
                        DistA_BT = [DistA_BT; distancia];
                        VA_BT = [VA_BT; puV(2*idx - 1)];
                    end
                    
                    if any(nodes == 2)
                        idx = find(nodes == 2, 1);
                        DistB_BT = [DistB_BT; distancia];
                        VB_BT = [VB_BT; puV(2*idx - 1)];
                    end
            
                    if any(nodes == 3)
                        idx = find(nodes == 3, 1);
                        DistC_BT = [DistC_BT; distancia];
                        VC_BT = [VC_BT; puV(2*idx - 1)];
                    end
                end
            end
    
            Tensao_minima_diaria_MT(nn,nt) = min( [VA(:); VB(:); VC(:)] );
            Tensao_minima_diaria_BT(nn,nt) = min( [VA_BT(:); VB_BT(:); VC_BT(:)] );

            tensao_minima_atual = min(Tensao_minima_diaria_BT(Tensao_minima_diaria_BT ~= 0));
            
            if tensao_minima_atual < pior_caso && caso(nc) ~= 1
                pior_caso = tensao_minima_atual;
                DSSText.Command = 'Export Voltages';
                movefile(arquivo_tensoes, pastaPior);
                copyfile(arquivo_EL, pastaPior_EL);
                copyfile(arquivo_ES, pastaPior_ES);
                copyfile(arquivo_ER, pastaPior_ER);
            end
            
            %% Demanda diária dos transformadores
            DSSText.Command = 'Export Capacity';
            Capacidades = readtable(pasta_capacidades, 'VariableNamingRule', 'preserve');
            Capacidades = Capacidades((contains(Capacidades.Name,'Transformer')),:);
            Capacidades = Capacidades(~(contains(Capacidades.Name,'ER')),:);
            if flag_trafo == 0
                trafos = string(Capacidades.Name);
                flag_trafo = 1;
                Demanda_Diario_Trafo = zeros(length(trafos),n_pontos);
                Demanda_Diario_Trafo_3D = zeros(length(trafos), n_pontos, max_cenario);
            end
            trafos1 = string(Capacidades.Name);
            if isequal(trafos, trafos1)
                m_capacidades(:,nn) = Capacidades.("%normal");
            else
                for m = 1:length(trafos)
                    aux1 = Capacidades(strcmp(string(Capacidades.Name),trafos(m)),:);
                    m_capacidades(m,nn) = aux1.("%normal");
                end
            end
            %% Perdas de potência diárias
            disp(['Calculando perdas para o ponto: ' num2str(nn)]);
            perdas_atuais = DSSCircuit.Losses;
            P_Perdas(nn) = perdas_atuais(1);
            Q_Perdas(nn) = perdas_atuais(2);
                
            % Demanda diária
            if nn == n_pontos
                DSSText.Command = 'Export monitors monitor_power';
                arquivo_monitor = pasta_monitor; 
                demanda_diaria = readtable(arquivo_monitor, 'Delimiter', ',', 'ReadVariableNames', true, 'VariableNamingRule', 'preserve');
                
                P_A = table2array(demanda_diaria(:,3)); Q_A = table2array(demanda_diaria(:,4));
                P_B = table2array(demanda_diaria(:,5)); Q_B = table2array(demanda_diaria(:,6));
                P_C = table2array(demanda_diaria(:,7)); Q_C = table2array(demanda_diaria(:,8));

                P_Total(:,nt) = P_A + P_B + P_C;
                Q_Total(:,nt) = Q_A + Q_B + Q_C;
            end
            
            % Perdas nos transformadores
            soma_perda_P_trafo = 0;
            soma_perda_Q_trafo = 0;
            aux_t = DSSTransformers.First;
            while aux_t > 0
                lossArray = DSSCktElement.Losses; 
                soma_perda_P_trafo = soma_perda_P_trafo + lossArray(1);
                soma_perda_Q_trafo = soma_perda_Q_trafo + lossArray(2);
                aux_t = DSSTransformers.Next;
            end
            perda_P_trafo(nn) = soma_perda_P_trafo / 1000;
            perda_Q_trafo(nn) = soma_perda_Q_trafo / 1000;
            
            % Perdas nas linhas de BT e MT
            soma_perda_P_MT = 0;
            soma_perda_Q_MT = 0;
            soma_perda_P_BT = 0;
            soma_perda_Q_BT = 0;
            
            aux_t = DSSLines.First;
            while aux_t > 0
                % Verifica a tensão da barra 1 da linha para saber se é MT ou BT
                busName = DSSLines.Bus1;
                DSSCircuit.SetActiveBus(busName);
                kv_base = DSSCircuit.ActiveBus.kvBase;
                
                % Pega perdas
                lossArray = DSSCktElement.Losses;
                p_loss = lossArray(1); % Watts
                q_loss = lossArray(2);
                
                % Critério: > 1.0 kV é Média Tensão 
                if kv_base > 1.0
                    soma_perda_P_MT = soma_perda_P_MT + p_loss;
                    soma_perda_Q_MT = soma_perda_Q_MT + q_loss; 
                else
                    soma_perda_P_BT = soma_perda_P_BT + p_loss;
                    soma_perda_Q_BT = soma_perda_Q_BT + q_loss;
                end
                
                aux_t = DSSLines.Next;
            end
            
            perdas_P_MT_diaria(nn) = soma_perda_P_MT / 1000; % kW
            perdas_Q_MT_diaria(nn) = soma_perda_Q_MT / 1000; 
            perdas_P_BT_diaria(nn) = soma_perda_P_BT / 1000; % kW
            perdas_Q_BT_diaria(nn) = soma_perda_Q_BT / 1000;

        end %Fim da simulação diária

        Demanda_Diario_Trafo = Demanda_Diario_Trafo + m_capacidades;
        Demanda_Diario_Trafo_3D(:,:,nt) = m_capacidades;

        P_Perdas = P_Perdas/1000; % Em kW
        Q_Perdas = Q_Perdas/1000; % Em kVAr
    
        PT_Perdas(:,nt) = P_Perdas;
        QT_Perdas(:,nt) = Q_Perdas;

        PT_Perdas_Trafo(:,nt) = perda_P_trafo;
        QT_Perdas_Trafo(:,nt) = perda_Q_trafo;

        PT_Perdas_MT(:,nt) = perdas_P_MT_diaria;
        QT_Perdas_MT(:,nt) = perdas_Q_MT_diaria;
    
        PT_Perdas_BT(:,nt) = perdas_P_BT_diaria;
        QT_Perdas_BT(:,nt) = perdas_Q_BT_diaria;
        
        clc 

        tensao_minima_atual = min(Tensao_minima_diaria_BT(:,nt));
            
        if tensao_minima_atual > melhor_caso && caso(nc) ~= 1
            melhor_caso = tensao_minima_atual;
            indice = find(Tensao_minima_diaria_BT(:,nt) == tensao_minima_atual);
            DSSText.command = pasta_cenario;
            DSSText.Command = 'set mode=daily';
            DSSText.Command = ['set stepsize=' num2str(stepsize_h) 'h'];
            DSSText.Command = ['set number=' num2str(indice(1))];
            DSSSolution.Solve;
            DSSText.Command = 'Export Voltages';
            movefile(arquivo_tensoes, pastaMelhor);
            copyfile(arquivo_EL, pastaMelhor_EL);
            copyfile(arquivo_ES, pastaMelhor_ES);
            copyfile(arquivo_ER, pastaMelhor_ER);
        end

        T_min_med(nt,1) = tensao_minima_atual;        
        med_anterior = med_atual;
        med_atual = mean(T_min_med);
        if abs(med_atual-med_anterior) <= tolerancia
            fprintf("\nSimulação de Monte Carlo atingiu a convergencia na interação %g\n",nt)
            break
        end
    end
    Demanda_Diario_Trafo_3D = Demanda_Diario_Trafo_3D(:,:,1:nt); 
    Demanda_Diario_Trafo = Demanda_Diario_Trafo/nt;
    nomes_colunas = ["Trafo", "Hora_" + string(1:24)];
    Demanda_Diario_Trafo_final = [table(trafos),array2table(Demanda_Diario_Trafo)];
    Demanda_Diario_Trafo_final.Properties.VariableNames = nomes_colunas;
    P_Perdas_final = mean(PT_Perdas,2);
    Q_Perdas_final = mean(QT_Perdas,2);

    P_Media = mean(P_Total,2);
    Q_Media = mean(Q_Total,2);
    
    Tensao_minima_diaria_MT_final = mean(Tensao_minima_diaria_MT,2);
    Tensao_minima_diaria_BT_final = mean(Tensao_minima_diaria_BT,2);

    PT_Perdas_Trafo_final = mean(PT_Perdas_Trafo,2);
    QT_Perdas_Trafo_final = mean(QT_Perdas_Trafo,2);

    PT_Perdas_MT_final = mean(PT_Perdas_MT,2);
    QT_Perdas_MT_final = mean(QT_Perdas_MT,2);

    PT_Perdas_BT_final = mean(PT_Perdas_BT,2);
    QT_Perdas_BT_final = mean(QT_Perdas_BT,2);

    if caso(nc) ~= 1
        writetable(Relatorio_ER, fullfile(pastaDestino, 'Relatorio_ER.xlsx'));
    end

    qtd_ER = 6;

    save(fullfile(pastaDestino, 'Tensao_minima_diaria_MT.mat'), 'Tensao_minima_diaria_MT');
    save(fullfile(pastaDestino, 'Tensao_minima_diaria_BT.mat'), 'Tensao_minima_diaria_BT');
    save(fullfile(pastaDestino, 'P_Perdas_final.mat'), 'P_Perdas_final');
    save(fullfile(pastaDestino, 'Q_Perdas_final.mat'), 'Q_Perdas_final');
    save(fullfile(pastaDestino, 'Tensao_minima_diaria_MT_final.mat'), 'Tensao_minima_diaria_MT_final');
    save(fullfile(pastaDestino, 'Tensao_minima_diaria_BT_final.mat'), 'Tensao_minima_diaria_BT_final');
    save(fullfile(pastaDestino, 'Demanda_Diario_Trafo_3D.mat'), 'Demanda_Diario_Trafo_3D');
    save(fullfile(pastaDestino, 'Demanda_Diario_Trafo_final.mat'), 'Demanda_Diario_Trafo_final');
    save(fullfile(pastaDestino, 'V_melhor_caso.mat'), 'melhor_caso');
    save(fullfile(pastaDestino, 'V_pior_caso.mat'), 'pior_caso');
    save(fullfile(pastaDestino, 'P_Media.mat'), 'P_Media');
    save(fullfile(pastaDestino, 'Q_Media.mat'), 'Q_Media');

    save(fullfile(pastaDestino, 'PT_Perdas_Trafo_final.mat'), 'PT_Perdas_Trafo_final');
    save(fullfile(pastaDestino, 'QT_Perdas_Trafo_final.mat'), 'QT_Perdas_Trafo_final');
    save(fullfile(pastaDestino, 'PT_Perdas_MT_final.mat'), 'PT_Perdas_MT_final');
    save(fullfile(pastaDestino, 'QT_Perdas_MT_final.mat'), 'QT_Perdas_MT_final');
    save(fullfile(pastaDestino, 'PT_Perdas_BT_final.mat'), 'PT_Perdas_BT_final');
    save(fullfile(pastaDestino, 'QT_Perdas_BT_final.mat'), 'QT_Perdas_BT_final');
    
end

figure('Name','Demanda Diaria dos Tranformadores')
for n = 1:length(Demanda_Diario_Trafo(:,1))
    plot(1:n_pontos,Demanda_Diario_Trafo(n,:))
    hold on
end
plot([0,25],[100,100],'--')
xlabel("Tempo [horas]");ylabel("Capacidade [%]");title("Capacidade dos transformadores");
hold off