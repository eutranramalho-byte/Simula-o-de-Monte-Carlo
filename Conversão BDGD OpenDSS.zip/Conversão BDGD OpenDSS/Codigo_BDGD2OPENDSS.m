clc
clear
clear vars
close all
%clear functions

% //Dados de entrada
%-------------------------------------------//
%-------------------------------------------//
% prompt= 'Alimentador (BDGD) COD_ID da camada (CTMT): ';
% Ali=input(prompt,'s');
% 
% freq=60;
% 
% prompt= 'Potência de curto-circuito trifásica (MVA): ';
% mvasc3=input(prompt,'s');
% 
% prompt= 'Potência de curto-circuito monofásica (MVA): ';
% mvasc1=input(prompt,'s');
% 
% prompt= 'Analise-> Dias úteis(UT), Sábados(SAB) ou Domingos(DOM): ';
% Dia_analise=input(prompt,'s');
% %-------------------------------------------//

Ali='JMLT308';
freq=60;
mvasc3='300';
mvasc1='100';
Dia_analise='UT';
fator_aumento = 1;

%prompt = 'Digite o numero do caso que vai analizar: ';

% Defina o caminho completo para a pasta onde os arquivos .dss serão salvos
%numero_caso = input(prompt, 's');
numero_caso = '4';
%pasta_destino = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Alimentador_JMLT310\\Caso%s', numero_caso);
pasta_destino = sprintf('D:\\1_UFOP\\ELÉTRICA\\9º periodo\\TCC 1\\Todos os alimentadores\\Testes\\Aimentador%s', Ali);
pasta_simulacao = sprintf('C:\\Users\\Eutran\\PycharmProjects\\Sumo_python\\Simulação Final\\Resultados_Caso%s', numero_caso);
%fprintf('A pasta de destino foi definida como: %s\n', pasta_destino);

% O código abaixo cria a pasta automaticamente se ela não existir
if ~exist(pasta_destino, 'dir')
   mkdir(pasta_destino);
   fprintf('Pasta de destino criada em: %s\n', pasta_destino);
end

if numero_caso == '2'
    PROB_EL = 0.2;
elseif numero_caso == '3'
    PROB_EL = 0.5;
elseif numero_caso == '4'
    PROB_EL = 1;
end
fprintf("Taxa de penetração: %f\n", PROB_EL)

% Leitura das tabelas
%-------------------------------------------//
% Tabela de domínio para tensões (TTEN), conforme Anexo II do manual BDGD 
COD_ID = [0;1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16;17;18;19;20;21;22;23;24;25;26;27;28;29;30;31;32;33;34;35;36;37;38;39;40;41;42;43;44;45;46;47;48;49;50;51;52;53;54;55;56;57;58;59;60;61;62;63;64;65;66;67;68;69;70;71;72;73;74;75;76;77;78;79;80;81;82;83;84;85;86;87;88;89;90;91;92;93;94;95;96;97;98;99;100];
TEM = [0;110;115;120;121;125;127;208;216;216.5;220;230;231;240;254;380;400;440;480;500;600;750;1000;2200;3200;3600;3785;3800;3848;3985;4160;4200;4207;4368;4560;5000;6000;6600;6930;7960;8670;11400;11900;12000;12600;12700;13200;13337;13530;13800;13860;14140;14190;14400;14835;15000;15200;19053;19919;21000;21500;22000;23000;23100;23827;24000;24200;25000;25800;27000;30000;33000;34500;36000;38000;40000;44000;45000;45400;48000;60000;66000;69000;72500;88000;88200;92000;100000;120000;121000;123000;131600;131630;131635;138000;145000;230000;345000;500000;750000;1000000];
DESCR={'Não informado';'0.110';'0.115';'0.120';'0.121';'0.125';'0.127';'0.208';'0.216';'0.2165';'0.220';'0.230';'0.231';'0.240';'0.254';'0.380';'0.400';'0.440';'0.480';'0.500';'0.600';'0.750';'1';'2.2';'3.2';'3.6';'3.785';'3.8';'3.848';'3.985';'4.16';'4.2';'4.207';'4.368';'4.56';'5';'6';'6.6';'6.93';'7.96';'8.67';'11.4';'11.9';'12';'12.6';'12.7';'13.2';'13.337';'13.53';'13.8';'13.86';'14.14';'14.19';'14.4';'14.835';'15';'15.2';'19.053';'19.919';'21';'21.5';'22';'23';'23.1';'23.827';'24';'24.2';'25';'25.8';'27';'30';'33';'34.5';'36';'38';'40';'44';'45';'45.4';'48';'60';'66';'69';'72.5';'88';'88.2';'92';'100';'120';'121';'123';'131.6';'131.63';'131.635';'138';'145';'230';'345';'500';'750';'1000'};
TTEN = table(COD_ID,TEM,DESCR);
clear COD_ID TEM DESCR

fprintf("\nLendo arquivos BDGD...")
CTMT = readtable('CTMT.xlsx');
SSDMT = readtable('SSDMT.xlsx');
SSDBT = readtable('SSDBT.xlsx');
SEGCON = readtable('SEGCON.xlsx');
EQTRD = readtable('EQTRMT.xlsx');
UNTRD = readtable('UNTRMT.xlsx');
UCBT = readtable('UCBT.xlsx');
UCMT = readtable('UCMT.xlsx');
PIP = readtable('PIP.xlsx');
UNRE = readtable('UNREMT.xlsx');
EQRE = readtable('EQRE.xlsx');

nome_arquivo_csv = 'perfil_agregado_carga_lenta.csv';
caminho_do_arquivo_para_ler = fullfile(pasta_simulacao, nome_arquivo_csv);
EL = readtable(caminho_do_arquivo_para_ler);

%-------------------------------------------//
% //Equivalente Thevenin/Circuit
% //----------------------------------------//
feeder_info = CTMT(strcmp(CTMT.COD_ID, Ali), :); % Filtra a tabela CTMT para o alimentador escolhido
bus_PAC = string(feeder_info.PAC_INI(1)); % Pega o Ponto de Acoplamento Comum Inicial como a barra da fonte
bus1 = string(SSDMT.PN_CON_1(strcmp(string(SSDMT.PAC_1),bus_PAC)));
first_line_info = SSDMT(strcmp(SSDMT.PN_CON_1, bus1),:);
Code_first_line = string(first_line_info.COD_ID(1));

if isempty(bus1)
    bus1 = string(SSDMT.PN_CON_2(strcmp(string(SSDMT.PAC_2),bus_PAC)));
    first_line_info = SSDMT(strcmp(SSDMT.PN_CON_2, bus1),:);
    Code_first_line = string(first_line_info.COD_ID(1));
end

tension_code = feeder_info.TEN_NOM(1);
DESCR_table = TTEN(TTEN.COD_ID == str2double(tension_code), 3);
DESCR = str2double(DESCR_table{1,1}); % Coleta a tensão base do alimentador (kV)

% Filtra as tabelas para conter apenas dados do alimentador selecionado
fprintf("\nFiltrando entidades para o alimentador %s...",Ali)
SSDBT = SSDBT(strcmp(SSDBT.CTMT, Ali), :);
SSDMT = SSDMT(strcmp(SSDMT.CTMT, Ali), :);
SSDMT.PN_CON_1 = string(SSDMT.PN_CON_1); % Converte colunas de conexão para string
SSDMT.PN_CON_2 = string(SSDMT.PN_CON_2);

% //----------------------------------------//
% //LineCodes
% //----------------------------------------//
SSDMT_13 = unique(SSDMT.TIP_CND(:),'stable');
SEGCON_MT = SEGCON(ismember(SEGCON.COD_ID, SSDMT_13), :);
rows_MT = size(SEGCON_MT,1);

SSDBT_14 = unique(SSDBT.TIP_CND(:),'stable');
SEGCON_BT = SEGCON(ismember(SEGCON.COD_ID, SSDBT_14), :);
rows_BT = size(SEGCON_BT,1);

% //----------------------------------------//
% //Lines
% //----------------------------------------//
filtro_linhas_validas = string(SSDBT.PN_CON_1) ~= string(SSDBT.PN_CON_2);
SSDBT = SSDBT(filtro_linhas_validas, :);

rows_SSDMT = size(SSDMT,1);
rows_SSDBT = size(SSDBT,1);

% //----------------------------------------//
% //Trafos
% //----------------------------------------//
UNTRD = UNTRD(strcmp(UNTRD.CTMT, Ali), :);
rows_UNTRD = size(UNTRD,1);
PN_2_UNTRD = table([], 'VariableNames', {'Codigo'}); %Para coletar o poste da unidade transformadora
COD_UNI_TR_MT = table([], 'VariableNames', {'Codigo'});%Para coletar o codigo da unidade transformadora

if ~isempty(UNTRD)
    base_kv_ten_lin = UNTRD.TEN_LIN_SE(1); % Tensão secundária para o VoltageBases
else
    base_kv_ten_lin = 0.22; % Valor default se não houver trafos
end

% //----------------------------------------//
% //Loads/LoadsShapes
% //----------------------------------------//
UCBT = UCBT(strcmp(UCBT.CTMT, Ali), :);
UCMT = UCMT(strcmp(UCMT.CTMT, Ali), :);
PIP = PIP(strcmp(PIP.CTMT, Ali), :);
rows_UCBT = size(UCBT,1);
rows_UCMT = size(UCMT,1);
rows_PIP = size(PIP,1);

% Definições de Curvas de Carga (LoadShapes)
R_UTEIS = "0.875718121, 0.7379304, 0.659207807, 0.633476025, 0.61442096, 0.678764605, 0.804322151, 0.925609108, 0.812108228, 0.738965351, 0.841846193, 0.950237106, 0.976420214, 0.851260093, 0.761985332, 0.77603361, 0.837538914, 1.369080181, 2.392437728, 1.778169959, 1.383523896, 1.353454872, 1.166310245, 1.081178899";
C_UTEIS = "0.540290381, 0.522840237, 0.500970213, 0.490532996, 0.508517788, 0.547920027, 0.571156332, 0.702277961, 1.102078597, 1.403910599, 1.577798928, 1.549089466, 1.283974133, 1.426076057, 1.579967453, 1.589447048, 1.55488613, 1.453487725, 1.202275416, 1.006271074, 0.859995139, 0.770251199, 0.670245313, 0.585739789";
IN_UTEIS = "0.371480548, 0.336803009, 0.342382469, 0.356678593, 0.422471297, 0.550753421, 0.654840865, 1.110008527, 1.596005663, 1.705449919, 1.852359559, 1.730589546, 1.008336908, 1.532508343, 1.870899751, 1.799217941, 1.690571957, 1.463406208, 0.925729658 0.739420845, 0.559664929, 0.520173023, 0.45983599, 0.40041103";
SP_UTEIS = "0.715469742, 0.667620058, 0.66107404, 0.682765098, 0.652029173, 0.698830552, 0.861324277, 1.01744213, 1.137088058, 1.209694169, 1.250450996, 1.263345256, 1.250983732, 1.204525696, 1.187173553, 1.171167595, 1.187824991, 1.180237526, 1.160738967, 1.084776851, 1.040818453, 0.998823054, 0.915379224, 0.80041681";
A4_UTEIS = "0.797062444, 0.776931084, 0.770858997, 0.788911111, 0.826906519, 0.91039443, 0.995234812, 1.154512925, 1.264221535, 1.292436805, 1.326093804, 1.295605964, 1.182864062, 1.318314054, 1.347710884, 1.338456486, 1.309773825, 1.158663378, 0.740455996, 0.53623314, 0.508044577, 0.65548448, 0.869557771, 0.835270918";
IP_UTEIS = "2.013976041, 2.013976041, 2.013976041, 2.013976041, 2.013976041, 2.013976041, 1.594394572, 0.167832588, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.251748882, 1.846143453, 2.013976041, 2.013976041, 2.013976041, 2.013976041";

R_SAB = "0.9479247 0.778990851 0.644163368 0.622945212 0.599629318 0.631423811 0.624300097 0.784340665 0.875381538 0.921509082 0.976392549 1.073391253 1.020256255 1.095033215 1.052651324 1.11871709 1.173223331 1.241993938 1.359572292 1.487065095 1.47764092 1.301080174 1.138071683 1.054302238";
C_SAB = "0.745844961 0.695560012 0.660555887 0.656953401 0.6675735 0.706258203 0.697273586 0.741337801 0.997543038 1.270040175 1.46779961 1.474424886 1.360264397 1.25427073 1.249090243 1.196283151 1.18359598 1.041567259 1.094021382 1.114351578 1.048219812 0.969091752 0.908246631 0.799832026";
IN_SAB = "0.719701223 0.678856369 0.65797677 0.688729903 0.740285843 0.824971236 0.974840711 1.249931292 1.558711053 1.626715041 1.578187507 1.487839002 1.16260595 1.127922538 1.195249562 1.166267331 1.106884403 1.007627862 0.937038061 0.882564052 0.738361397 0.649525851 0.643271554 0.59593549";
SP_SAB = "0.764124928 0.705296903 0.701858516 0.663284763 0.66956166 0.689300838 0.818684876 0.945400647 1.050293212 1.174812297 1.197044164 1.205997552 1.209776334 1.206965474 1.202857298 1.168455913 1.178516186 1.146120392 1.165970522 1.14098204 1.091501285 1.052795445 0.971168566 0.879230189";
A4_SAB = "1.051824318 1.027558766 1.022662475 1.033062567 1.032821183 1.073151932 1.104095753 1.149256352 1.189917618 1.206903066 1.194106858 1.141280143 1.049368708 1.030409138 1.020566211 0.996503977 0.957821268 0.909606485 0.88206375 0.851650023 0.817218272 0.785744757 0.750715532 0.721690847";

R_DOM = "0.902446549 0.793209114 0.762242413 0.634578965 0.612704677 0.619183942 0.61238264 0.686929606 0.828068989 1.037885774 1.243109979 1.336588186 1.179317195 1.068303868 1.00666421 0.974474563 1.055412957 1.188204305 1.328681513 1.366134223 1.275224649 1.357337019 1.114345767 1.016568896";
C_DOM = "0.993897432 0.972326705 0.936434735 0.892515887 0.874446892 0.895711227 0.907327765 0.891246254 0.94811259 1.031648282 1.129049038 1.125414381 1.050651267 1.034211027 1.014083065 1.005260628 0.946590527 0.978046403 1.087096631 1.155707182 1.096008472 1.061153529 1.006011016 0.967049066";
IN_DOM = "0.864017127 0.839475836 0.816636209 0.868310784 0.899163682 0.914429973 0.919112742 0.982321722 1.066884737 1.03857701 1.102481975 1.062662815 1.02392571 1.027317706 1.028976738 1.026373181 1.067446416 1.0949689 1.180691398 1.097615015 0.988605309 0.969014647 1.086182031 1.034808338";
SP_DOM = "0.792237795 0.770612686 0.758954136 0.771332012 0.712239535 0.741435859 0.917681788 0.938596341 1.014057683 1.134204229 1.178114981 1.191946067 1.170631599 1.197045856 1.156067675 1.153229582 1.172034243 1.144135328 1.164647755 1.085417461 1.046097267 1.002677709 0.981975564 0.804626847";
A4_DOM = "0.966397294 0.953181849 0.942987579 0.932101485 0.940800001 0.925168058 0.92901207 0.954305205 0.981923834 1.00508849 1.026816252 1.015473749 0.978544231 0.985969777 0.99257738 0.981376001 0.98515142 0.99085031 1.017522936 1.016404235 1.003221898 1.04150091 1.176262898 1.257362137";

if Dia_analise == "UT"
    caminho_loadshapes = fullfile(pasta_destino, 'LoadShapes.dss');
    fid = fopen(caminho_loadshapes, 'wt');
    fprintf(fid, 'New loadshape.Residencial npts = 24 interval = 1 mult = (%s) \n', R_UTEIS);
    fprintf(fid, 'New loadshape.Rural npts = 24 interval = 1 mult = (%s) \n', R_UTEIS);    
    fprintf(fid, 'New loadshape.Comercial npts = 24 interval = 1 mult = (%s) \n', C_UTEIS);   
    fprintf(fid, 'New loadshape.Industrial npts = 24 interval = 1 mult = (%s) \n', IN_UTEIS);
    fprintf(fid, 'New loadshape.Serv_Pub npts = 24 interval = 1 mult = (%s) \n', SP_UTEIS);
    fprintf(fid, 'New loadshape.A4 npts = 24 interval = 1 mult = (%s) \n', A4_UTEIS);
    fprintf(fid, 'New loadshape.IP npts = 24 interval = 1 mult = (%s) \n', IP_UTEIS);     
    fclose(fid);
elseif Dia_analise == "SAB"
    caminho_loadshapes = fullfile(pasta_destino, 'LoadShapes.dss');
    fid = fopen(caminho_loadshapes, 'wt');
    fprintf(fid, 'New loadshape.Residencial npts = 24 interval = 1 mult = (%s) \n', R_SAB);
    fprintf(fid, 'New loadshape.Rural npts = 24 interval = 1 mult = (%s) \n', R_SAB);        
    fprintf(fid, 'New loadshape.Comercial npts = 24 interval = 1 mult = (%s) \n', C_SAB);   
    fprintf(fid, 'New loadshape.Industrial npts = 24 interval = 1 mult = (%s) \n', IN_SAB);
    fprintf(fid, 'New loadshape.Serv_Pub npts = 24 interval = 1 mult = (%s) \n', SP_SAB);
    fprintf(fid, 'New loadshape.A4 npts = 24 interval = 1 mult = (%s) \n', A4_SAB);
    fprintf(fid, 'New loadshape.IP npts = 24 interval = 1 mult = (%s) \n', IP_UTEIS);  
    fclose(fid);
elseif Dia_analise == "DOM"
    caminho_loadshapes = fullfile(pasta_destino, 'LoadShapes.dss');
    fid = fopen(caminho_loadshapes, 'wt');
    fprintf(fid, 'New loadshape.Residencial npts = 24 interval = 1 mult = (%s) \n', R_DOM);
    fprintf(fid, 'New loadshape.Rural npts = 24 interval = 1 mult = (%s) \n', R_DOM);          
    fprintf(fid, 'New loadshape.Comercial npts = 24 interval = 1 mult = (%s) \n', C_DOM);   
    fprintf(fid, 'New loadshape.Industrial npts = 24 interval = 1 mult = (%s) \n', IN_DOM);
    fprintf(fid, 'New loadshape.Serv_Pub npts = 24 interval = 1 mult = (%s) \n', SP_DOM);
    fprintf(fid, 'New loadshape.A4 npts = 24 interval = 1 mult = (%s) \n', A4_DOM);
    fprintf(fid, 'New loadshape.IP npts = 24 interval = 1 mult = (%s) \n', IP_DOM);  
    fclose(fid);
else
end

% //----------------------------------------//
% //Escrever TXTs
% //----------------------------------------//
N1 = sprintf("LineCode_SSDBT_%s",Ali);
N2 = sprintf("LineCode_SSDMT_%s",Ali);
N3 = sprintf("Lines_SSDMT_%s",Ali);
N4 = sprintf("Lines_SSDBT_trifasicas_%s",Ali);
N5 = "LoadShapes";
N6 = sprintf("Loads_UCBT_trifasicas_%s",Ali);
N7 = sprintf("Loads_UCMT_%s",Ali);
N8 = sprintf("Transformers_trifasicos_%s",Ali);
N9 = sprintf("PIP_trifasica_%s",Ali);
N10 = sprintf("Eletroposots_EL_%s",Ali);
N11 = sprintf("Transformers_monofasicos_%s",Ali);
N12 = sprintf("Lines_SSDBT_monofasicas_%s",Ali);
N13 = sprintf("PIP_monofasicas_%s",Ali);
N14 = sprintf("Loads_UCBT_monofasicas_%s",Ali);
N15 = sprintf("Bases_%s",Ali);
N16 = sprintf("Regulador_%s",Ali);

% Escrita do arquivo principal MainCode.dss
fprintf("\nEscrevendo arquivo principal MainCode.dss...")
caminho_main = fullfile(pasta_destino, 'MainCode.dss');
fid = fopen(caminho_main, 'wt');
% fid = fopen( 'MainCode.dss', 'wt' );
fprintf(fid, 'clear\n\n');
fprintf(fid, 'New Circuit.%s bus1=%s basekv=%g pu=1.00 phases=3 frequency=%g mvasc3=%s mvasc1=%s\n\n', Ali, bus1, DESCR, freq, mvasc3, mvasc1);
fprintf(fid, 'Redirect %s.dss\n',N1);
fprintf(fid, 'Redirect %s.dss\n',N2);
fprintf(fid, 'Redirect %s.dss\n',N3);
fprintf(fid, 'Redirect %s.dss\n',N4);
fprintf(fid, 'Redirect %s.dss\n',N5);
fprintf(fid, 'Redirect %s.dss\n',N6);
fprintf(fid, 'Redirect %s.dss\n',N7);
fprintf(fid, 'Redirect %s.dss\n',N8);
fprintf(fid, 'Redirect %s.dss\n',N9);
fprintf(fid, '//Redirect %s.dss\n',N10);
fprintf(fid, 'Redirect %s.dss\n',N11);
fprintf(fid, 'Redirect %s.dss\n',N12);
fprintf(fid, 'Redirect %s.dss\n',N13);
fprintf(fid, 'Redirect %s.dss\n',N14);
fprintf(fid, '//Redirect BESS_%s.dss\n',Ali);
fprintf(fid, 'Redirect %s.dss\n',N16);
fprintf(fid, '\n//Set VoltageBases = [13.8, 0.127, 0.20784]');
fprintf(fid, '\nSet VoltageBases = [%g, %g]\nCalcVoltageBases\n', DESCR, base_kv_ten_lin);
fprintf(fid, 'Redirect %s.dss\n',N15);
fprintf(fid, '\nNew energymeter.medidor element=line.%s terminal=1\n', Code_first_line);
fprintf(fid, 'New monitor.monitor_power element=Line.%s terminal=1 mode=1 ppolar=no\n', Code_first_line);
fprintf(fid, 'New Loadshape.MyLDCurve npts=24 interval=1 mult=(0.8 0.85 0.9 0.95 1 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.35 1.3 1.25 1.2 1.15 1.1 1.05 1 0.95 0.9 0.85)\n');
fprintf(fid, 'Set LDCurve=MyLDCurve\n');
fprintf(fid, '\nset tolerance=1e-7\nset Maxiter=500\nset mode=daily\nset stepsize=1h\nset number=24\nsolve\n');
fprintf(fid, '\n\nBusCoords Coordenadas_%s.dss\n',Ali);
fprintf(fid, '\nBusCoords Coordenadas_%s_BT.dss\n', Ali);
fclose(fid); 

% Escrita linecode MT
fprintf("\nEscrevendo arquivo %s...",N2)
nome_arquivo_lc_mt = sprintf('%s.dss', N2);
caminho_lc_mt = fullfile(pasta_destino, nome_arquivo_lc_mt);
fid = fopen(caminho_lc_mt, 'wt');
for i = 1:rows_MT
    codigo= string(SEGCON_MT.COD_ID(i));
    corrente= SEGCON_MT.CNOM(i);
    R1= SEGCON_MT.R1(i);
    X1= SEGCON_MT.X1(i);
    % -> NOTA: A contagem de fases aqui é uma aproximação. O ideal seria casar com a FAS_CON da linha que usa este linecode.
    phase = 0;
    if str2double(SEGCON_MT.MAT_FAS_1(i)) ~= 0, phase = phase + 1; end
    if str2double(SEGCON_MT.MAT_FAS_2(i)) ~= 0, phase = phase + 1; end
    if str2double(SEGCON_MT.MAT_FAS_3(i)) ~= 0, phase = phase + 1; end
    if str2double(SEGCON_MT.MAT_NEU(i)) ~= 0, phase = phase + 1; end
    
    fprintf(fid,'New linecode.%s nphases=%d basefreq=%g units=km Normamps=%g R1=%g X1=%g\n\n', codigo, phase, freq, corrente, R1, X1);
end
fclose(fid);

% Escrita linecode BT
fprintf("\nEscrevendo arquivo %s...",N1)
nome_arquivo_lc_bt = sprintf('%s.dss', N1);
caminho_lc_bt = fullfile(pasta_destino, nome_arquivo_lc_bt);
fid = fopen(caminho_lc_bt, 'wt');
for i = 1:rows_BT
    codigo= string(SEGCON_BT.COD_ID(i));
    corrente= SEGCON_BT.CNOM(i);
    R1= SEGCON_BT.R1(i);
    X1= SEGCON_BT.X1(i);
    phase = 0;
    if str2double(SEGCON_BT.MAT_FAS_1(i)) ~= 0, phase = phase + 1; end
    if str2double(SEGCON_BT.MAT_FAS_2(i)) ~= 0, phase = phase + 1; end
    if str2double(SEGCON_BT.MAT_FAS_3(i)) ~= 0, phase = phase + 1; end
    if str2double(SEGCON_BT.MAT_NEU(i)) ~= 0, phase = phase + 1; end

    fprintf(fid,'New linecode.%s nphases=%d basefreq=%g units=km Normamps=%g R1=%g X1=%g\n\n', codigo, phase, freq, corrente, R1, X1);
end
fclose(fid);

% Escrita Lines MT
fprintf("\nEscrevendo arquivo %s...",N3)
nome_arquivo_lines_mt = sprintf('%s.dss', N3);
caminho_lines_mt = fullfile(pasta_destino, nome_arquivo_lines_mt);
fid = fopen(caminho_lines_mt, 'wt');
for i = 1:rows_SSDMT
    fases = string(SSDMT.FAS_CON(i));
    switch fases
        case {"A"}, phase = "1"; conex = ".1";
        case {"B"}, phase = "1"; conex = ".2";
        case {"C"}, phase = "1"; conex = ".3";
        case {"N"}, phase = "1"; conex = ".0"; % Neutro sozinho
        case {"AN"}, phase = "2"; conex = ".1.0";
        case {"BN"}, phase = "2"; conex = ".2.0";
        case {"CN"}, phase = "2"; conex = ".3.0";
        case {"AB"}, phase = "2"; conex = ".1.2";
        case {"BC"}, phase = "2"; conex = ".2.3";
        case {"CA"}, phase = "2"; conex = ".3.1";
        case {"ABN"}, phase = "3"; conex = ".1.2.0";
        case {"BCN"}, phase = "3"; conex = ".2.3.0";
        case {"CAN"}, phase = "3"; conex = ".3.1.0";
        case {"ABC"}, phase = "3"; conex = ".1.2.3";
        case {"ABCN"}, phase = "4"; conex = ".1.2.3.0"; % Em MT, o neutro geralmente não é modelado como condutor na linha
        otherwise, continue;
    end
    
    codigo = string(SSDMT.COD_ID(i));
    barra1 = string(SSDMT.PN_CON_1(i));
    barra2 = string(SSDMT.PN_CON_2(i));
    comprimento = string(SSDMT.COMP(i));
    tipo_condutor = string(SSDMT.TIP_CND(i));
    fprintf(fid,'New line.%s phases=%s bus1=%s%s bus2=%s%s length=%s units=m linecode=%s\n\n', codigo, phase, barra1, conex, barra2, conex, comprimento, tipo_condutor);
end
fclose(fid);

% Escrita dos Religadores
TPOTAPRT = table('Size',[2,2],'VariableTypes',{'double','double'},'VariableNames',{'COD_ID','POT'});
TPOTAPRT.COD_ID = [45;48];
TPOTAPRT.POT = [1000;1500];
UNRE = UNRE(strcmp(UNRE.CTMT,Ali),:);
fprintf("\nEscrevendo arquivo %s...",N16)
nome_arquivo = sprintf('%s.dss', N16);
caminho = fullfile(pasta_destino, nome_arquivo);
fid = fopen(caminho, 'wt'); 
for i = 1:length(UNRE.OBJECTID)
    
    EQRE_FIL = EQRE(strcmp(string(EQRE.UN_RE), string(UNRE.COD_ID(i))),:);

    if isempty(EQRE_FIL), continue; end % Pula se não encontrar equipamento correspondente
    PAC_1=string(UNRE.PAC_1(i));
        
    SSDMT_PN_2=SSDMT(strcmp(string(SSDMT.PAC_2), PAC_1), :);

    if isempty(SSDMT_PN_2)
        SSDMT_PN_1=SSDMT(strcmp(string(SSDMT.PAC_1), PAC_1), :);
        if isempty(SSDMT_PN_1), continue; end
        PN_2=string(SSDMT_PN_1.PN_CON_1(1));
    else
        PN_2=string(SSDMT_PN_2.PN_CON_2(1));
    end
    
    for n = 1:length(EQRE_FIL.OBJECTID)
        xhl=EQRE_FIL.XHL(n);
        res=EQRE_FIL.R(n);
        codigo = string(EQRE_FIL.COD_ID(n));
        
        kva = TPOTAPRT.POT(strcmp(string(TPOTAPRT.COD_ID),string(EQRE_FIL.POT_NOM(n))),1);
        fases = string(EQRE_FIL.LIG_FAS_P(n));
        switch fases
            case {"A"}, conn1="wye"; phase="1";conex1 = ".1";
            case {"B"}, conn1="wye"; phase="1";conex1 = ".2";
            case {"C"}, conn1="wye"; phase="1";conex1 = ".3";
            case {"AN"}, conn1="wye"; phase="1";conex1 = ".1";
            case {"BN"}, conn1="wye"; phase="1";conex1 = ".2";
            case {"CN"}, conn1="wye"; phase="1";conex1 = ".3";
            case {"AB"}, conn1="delta"; phase="2";conex1 = ".1.2";
            case {"BC"}, conn1="delta"; phase="2";conex1 = ".2.3";
            case {"CA"}, conn1="delta"; phase="2";conex1 = ".3.1";
            case {"ABN"}, conn1="wye"; phase="2";conex1 = ".1.2";
            case {"BCN"}, conn1="wye"; phase="2";conex1 = ".2.3";
            case {"CAN"}, conn1="wye"; phase="2";conex1 = ".3.1";
            case {"ABC"}, tipo=3; conn1="delta"; phase="3";conex1 = ".1.2.3";
            case {"ABCN"}, tipo=3; conn1="wye"; phase="3";conex1 = ".1.2.3";
        end
             
        if kva > 0
            noloadloss = EQRE_FIL.PER_FER(n)/(kva*10);
            loadloss = (EQRE_FIL.PER_TOT(n) - EQRE_FIL.PER_FER(n))/(kva*10);
        else
            noloadloss = 0;
            loadloss = 0;
        end
     
        DESCR = DESCR/sqrt(3);
        Vreg = floor((EQRE_FIL.TEN_REG(n)*DESCR*1000)/60);

        fprintf(fid,'New transformer.REG_%s phases=%s windings=2 %%loadloss = %.4f %%noloadloss = %.4f \n', codigo, phase, loadloss, noloadloss);
        fprintf(fid,'~ buses=(%s%s, %s_R%s) \n',PN_2,conex1,PN_2,conex1);
        fprintf(fid,'~ conns=(%s, %s)\n', conn1, conn1); 
        fprintf(fid,'~ kVs=(%g, %g)\n', DESCR, DESCR); 
        fprintf(fid,'~ kVAs=(%g, %g)\n',kva,kva ); 
        fprintf(fid,'~ %%r=%g xhl=%g NumTaps=32\n\n',res,xhl);

        fprintf(fid,'New RegControl.Ctrl_%s Transformer=REG_%s winding=2\n',codigo,codigo); 
        fprintf(fid,'~ ptratio=60 Vreg=%g band=2 delay=15\n\n',Vreg);
    
        DESCR = DESCR*sqrt(3);
    end
end  
fclose(fid);


% Escrita TRAFOS
fprintf("\nEscrevendo arquivos %s e %s...",N8,N11)
contador_trifasico = 1;
contador_monofasico = 1;
trafo_id_map = containers.Map('KeyType', 'char', 'ValueType', 'char');

% UCBT_temp = [];
% PIP_temp = [];
% SSDBT_temp = [];

FASES_SEC_UNTRD = table('Size', [0, 1], 'VariableTypes', {'string'}, 'VariableNames', {'FaseSecundaria'});
nome_arquivo_trafos_tri = sprintf('%s.dss', N8);
caminho_trafos_tri = fullfile(pasta_destino, nome_arquivo_trafos_tri);
nome_arquivo_trafos_mono = sprintf('%s.dss', N11);
caminho_trafos_mono = fullfile(pasta_destino, nome_arquivo_trafos_mono);
fid_tri = fopen(caminho_trafos_tri, 'wt');  % Arquivo para trafos trifásicos
fid_mono = fopen(caminho_trafos_mono, 'wt'); % Arquivo para trafos monofásicos/bifásicos
for i = 1:rows_UNTRD 
    codigo= string(UNTRD.COD_ID(i));
    PAC_2_id = string(UNTRD.COD_ID(i)); % O ID da unidade transformadora
    
    % aux_ssdbt=SSDBT(strcmp(string(SSDBT.UNI_TR_MT),PAC_2_id),:);
    % aux_ucbt=UCBT(strcmp(string(UCBT.UNI_TR_MT),PAC_2_id),:);
    % aux_pip=PIP(strcmp(string(PIP.UNI_TR_MT),PAC_2_id),:);
    % 
    % SSDBT_temp = [SSDBT_temp;aux_ssdbt];
    % UCBT_temp = [UCBT_temp;aux_ucbt];
    % PIP_temp = [PIP_temp;aux_pip];

    EQTRD.UNI_TR_MT = string(EQTRD.UNI_TR_MT);
    EQTRD_FIL = EQTRD(strcmp(EQTRD.UNI_TR_MT, PAC_2_id),:);

    if isempty(EQTRD_FIL), continue; end % Pula se não encontrar equipamento correspondente
    
    xhl=EQTRD_FIL.XHL(1);
    xlt=EQTRD_FIL.XLT(1);
    xht=EQTRD_FIL.XHT(1);
    PAC_1=string(UNTRD.PAC_1(i));
    
    SSDMT_PN_2=SSDMT(strcmp(SSDMT.PAC_2, PAC_1), :);

    if isempty(SSDMT_PN_2)
        SSDMT_PN_1=SSDMT(strcmp(SSDMT.PAC_1, PAC_1), :);
        if isempty(SSDMT_PN_1), continue; end
        PN_2=string(SSDMT_PN_1.PN_CON_1(1));
    else
        PN_2=string(SSDMT_PN_2.PN_CON_2(1));
    end
    
    kva = UNTRD.POT_NOM(i);
    fases1 = string(UNTRD.FAS_CON_P(i));
    switch fases1
        case {"A"}, tipo=1; conn1="wye"; phase="1";conex1 = ".1";
        case {"B"}, tipo=1; conn1="wye"; phase="1";conex1 = ".2";
        case {"C"}, tipo=1; conn1="wye"; phase="1";conex1 = ".3";
        case {"AN"}, tipo=1; conn1="wye"; phase="1";conex1 = ".1.0";
        case {"BN"}, tipo=1; conn1="wye"; phase="1";conex1 = ".2.0";
        case {"CN"}, tipo=1; conn1="wye"; phase="1";conex1 = ".3.0";
        case {"AB"}, tipo=2; conn1="delta"; phase="2";conex1 = ".1.2";
        case {"BC"}, tipo=2; conn1="delta"; phase="2";conex1 = ".2.3";
        case {"CA"}, tipo=2; conn1="delta"; phase="2";conex1 = ".3.1";
        case {"ABN"}, tipo=2; conn1="wye"; phase="2";conex1 = ".1.2.0";
        case {"BCN"}, tipo=2; conn1="wye"; phase="2";conex1 = ".2.3.0";
        case {"CAN"}, tipo=2; conn1="wye"; phase="2";conex1 = ".3.1.0";
        case {"ABC"}, tipo=3; conn1="delta"; phase="3";conex1 = ".1.2.3";
        case {"ABCN"}, tipo=3; conn1="wye"; phase="3";conex1 = ".1.2.3.0";
    end

    fases2 = string(UNTRD.FAS_CON_S(i));
    switch fases2
        case {"A"},conn2="wye"; conex2 = ".1";
        case {"B"}, conn2="wye"; conex2 = ".2";
        case {"C"}, conn2="wye"; conex2 = ".3";
        case {"AN"}, conn2="wye"; conex2 = ".1.0";
        case {"BN"}, conn2="wye"; conex2 = ".2.0";
        case {"CN"}, conn2="wye"; conex2 = ".3.0";
        case {"AB"}, conn2="delta"; conex2 = ".1.2";
        case {"BC"}, conn2="delta"; conex2 = ".2.3";
        case {"CA"}, conn2="delta"; conex2 = ".3.1";
        case {"ABN"}, conn2="wye"; conex2 = ".1.2.0";
        case {"BCN"}, conn2="wye"; conex2 = ".2.3.0";
        case {"CAN"}, conn2="wye"; conex2 = ".3.1.0";
        case {"ABC"}, conn2="delta"; conex2 = ".1.2.3";
        case {"ABCN"}, conn2="wye"; conex2 = ".1.2.3.0";
    end
    
    enrolamento = 2;
    fases3 = string(UNTRD.FAS_CON_T(i));
    switch fases3
        case {"A"},conn3="wye"; conex3 = ".1";enrolamento = 3;
        case {"B"}, conn3="wye"; conex3 = ".2";enrolamento = 3;
        case {"C"}, conn3="wye"; conex3 = ".3";enrolamento = 3;
        case {"AN"}, conn3="wye"; conex3 = ".1.0";enrolamento = 3;
        case {"BN"}, conn3="wye"; conex3 = ".2.0";enrolamento = 3;
        case {"CN"}, conn3="wye"; conex3 = ".3.0";enrolamento = 3;
        case {"AB"}, conn3="delta"; conex3 = ".1.2";enrolamento = 3;
        case {"BC"}, conn3="delta"; conex3 = ".2.3";enrolamento = 3;
        case {"CA"}, conn3="delta"; conex3 = ".3.1";enrolamento = 3;
        case {"ABN"}, conn3="wye"; conex3 = ".1.2.0";enrolamento = 3;
        case {"BCN"}, conn3="wye"; conex3 = ".2.3.0";enrolamento = 3;
        case {"CAN"}, conn3="wye"; conex3 = ".3.1.0";enrolamento = 3;
        case {"ABC"}, conn3="delta"; conex3 = ".1.2.3";enrolamento = 3;
        case {"ABCN"}, conn3="wye"; conex3 = ".1.2.3.0";enrolamento = 3;
    end

    res=EQTRD_FIL.R(1);
    kv=UNTRD.TEN_LIN_SE(i);
    tap = UNTRD.TAP(i);

    id_unico = '';
    if tipo == 3 % Trifásico
        id_unico = sprintf('T%d', contador_trifasico);
        contador_trifasico = contador_trifasico + 1;
    elseif tipo == 1 || tipo == 2 % Monofásico ou Bifásico
        id_unico = sprintf('M%d', contador_monofasico);
        contador_monofasico = contador_monofasico + 1;
    end
    
    % Armazena a associação no mapa para uso posterior
    if ~isempty(id_unico)
        trafo_id_map(codigo) = id_unico;
    end

    fase_para_mapa = fases2;
    if (tipo == 1 || tipo == 2) && (enrolamento == 3) && (fases3 ~= "0")
       string_combinada = strcat(fases2, fases3);
        % Pega os caracteres únicos e os ordena para criar uma fase padronizada (ex: 'ABN')
        fase_final_correta = string(sort(unique(char(string_combinada)))); % <-- LINHA CORRIGIDA
        fase_para_mapa = fase_final_correta;
    end
    FASES_SEC_UNTRD(i,:) = {fase_para_mapa};
    
    if kva > 0
        noloadloss = UNTRD.PER_FER(i)/(kva*10);
        loadloss = (UNTRD.PER_TOT(i) - UNTRD.PER_FER(i))/(kva*10);
    else
        noloadloss = 0;
        loadloss = 0;
    end

    PN_2_UNTRD(i,:) = {PN_2};
    COD_UNI_TR_MT(i,:) = {EQTRD_FIL.UNI_TR_MT};

    if tipo == 3 % Trifáfico
        fprintf(fid_tri,'New transformer.%s xhl = %g windings = 2 %%loadloss = %g %%noloadloss = %g phases = %s  \n', codigo, xhl, loadloss, noloadloss, phase);
        fprintf(fid_tri,'~ wdg = 1 bus = %s%s kv = %g kva = %g conn = %s %%r = %g tap = 0.985 \n',PN_2,conex1, DESCR, kva, conn1, res);
        %fprintf(fid_tri,'~ wdg = 2 bus = BT_%s_T%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n\n', PN_2, conex2, kv, kva, conn2, res, tap);
        fprintf(fid_tri,'~ wdg = 2 bus = BT_%s_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n\n', PN_2, id_unico, conex2, kv, kva, conn2, res, tap);
    
    elseif tipo == 1 || tipo == 2
        if enrolamento == 3
            DESCR = DESCR/sqrt(3);
            fprintf(fid_mono,'New transformer.%s xhl = %g  xlt = %g xht = %g  windings = 3 %%loadloss = %g %%noloadloss = %g phases = %s  \n', codigo, xhl, xlt, xht, loadloss, noloadloss, phase);
            fprintf(fid_mono,'~ wdg = 1 bus = %s%s kv = %g kva = %g conn = %s %%r = %g tap = 0.985 \n',PN_2,conex1, DESCR, kva, conn1, res);
            % fprintf(fid_mono,'~ wdg = 2 bus = BT_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n', PN_2, conex2, kv/2, kva/2, conn2, res, tap);
            % fprintf(fid_mono,'~ wdg = 3 bus = BT_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n\n', PN_2, conex3, kv/2, kva/2, conn3, res, tap);
            fprintf(fid_mono,'~ wdg = 2 bus = BT_%s_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n', PN_2, id_unico, conex2, kv/2, kva/2, conn2, res, tap);
            fprintf(fid_mono,'~ wdg = 3 bus = BT_%s_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n\n', PN_2, id_unico, conex3, kv/2, kva/2, conn3, res, tap);

            DESCR = DESCR*sqrt(3);
        else
            if tipo == 2 %fase-fase
                fprintf(fid_mono,'New transformer.%s xhl = %g windings = 2 %%loadloss = %g %%noloadloss = %g phases = %s  \n', codigo, xhl, loadloss, noloadloss, phase);
                fprintf(fid_mono,'~ wdg = 1 bus = %s%s kv = %g kva = %g conn = %s %%r = %g tap = 0.985 \n',PN_2,conex1, DESCR, kva, conn1, res);
                % fprintf(fid_mono,'~ wdg = 2 bus = BT_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n\n', PN_2, conex2, kv, kva, conn2, res, tap);
                fprintf(fid_mono,'~ wdg = 2 bus = BT_%s_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n\n', PN_2, id_unico, conex2, kv, kva, conn2, res, tap);

            elseif tipo == 1 %fase-neutro
                DESCR = DESCR/sqrt(3);
                kv = kv/sqrt(3);
                fprintf(fid_mono,'New transformer.%s xhl = %g windings = 2 %%loadloss = %g %%noloadloss = %g phases = %s  \n', codigo, xhl, loadloss, noloadloss, phase);
                fprintf(fid_mono,'~ wdg = 1 bus = %s%s kv = %g kva = %g conn = %s %%r = %g tap = 0.985 \n',PN_2,conex1, DESCR, kva, conn1, res);
                % fprintf(fid_mono,'~ wdg = 2 bus = BT_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n\n', PN_2, conex2, kv, kva, conn2, res, tap);
                fprintf(fid_mono,'~ wdg = 2 bus = BT_%s_%s%s kv = %g kva = %g conn = %s %%r = %g tap = %g\n\n', PN_2, id_unico, conex2, kv, kva, conn2, res, tap); 

                DESCR = DESCR*sqrt(3);
            end
        end
    end
end  
fclose(fid);

Trafo_MT = table(string(PN_2_UNTRD.Codigo), string(COD_UNI_TR_MT.Codigo), FASES_SEC_UNTRD.FaseSecundaria, 'VariableNames',{'Poste','Codigo_MT', 'Fase_Secundaria'});
Trafo_MT_M = Trafo_MT(Trafo_MT.Fase_Secundaria ~="ABCN",:);
Trafo_MT_T = Trafo_MT(Trafo_MT.Fase_Secundaria =="ABCN",:);

fprintf("\nEscrevendo as bases das barras do alimentador %s", Ali);
nome_arquivo_bases = sprintf('%s.dss', N15);
caminho_lines_bases = fullfile(pasta_destino, nome_arquivo_bases);
fid_bases = fopen(caminho_lines_bases, 'wt');  % Arquivo para linhas BT trifásicas

for n=1:length(Trafo_MT.Poste)
    trafo_atual = UNTRD(strcmp(UNTRD.COD_ID,Trafo_MT.Codigo_MT(n)),:);
    base=trafo_atual.TEN_LIN_SE(1);
    if string(trafo_atual.FAS_CON_T) ~= '0'
        base = sqrt(3)*(base/2);
    end
    
    barras_trafo_atual = SSDBT(strcmp(string(SSDBT.UNI_TR_MT),Trafo_MT.Codigo_MT(n)),:);
    barras_trafo_atual = string(unique([barras_trafo_atual.PN_CON_1;barras_trafo_atual.PN_CON_2]));
    id=trafo_id_map(Trafo_MT.Codigo_MT(n));
    poste = Trafo_MT.Poste(n);
    fprintf(fid_bases,'SetkVBase bus=BT_%s_%s kvll=%g\n',poste,id,base);

    for n1=1:length(barras_trafo_atual)
        poste = barras_trafo_atual(n1);
        fprintf(fid_bases,'SetkVBase bus=BT_%s_%s kvll=%g\n',poste,id,base);
    end

end
fclose(fid_bases);

% SSDBT = SSDBT_temp;
% UCBT = UCBT_temp;
% PIP = PIP_temp;

rows_SSDBT = size(SSDBT,1);
rows_UCBT = size(UCBT,1);
rows_PIP = size(PIP,1);

% Escrita Lines BT
fprintf("\nEscrevendo arquivos %s e %s...",N4,N12)
nome_arquivo_lines_bt_tri = sprintf('%s.dss', N4);
caminho_lines_bt_tri = fullfile(pasta_destino, nome_arquivo_lines_bt_tri);
nome_arquivo_lines_bt_mono = sprintf('%s.dss', N12);
caminho_lines_bt_mono = fullfile(pasta_destino, nome_arquivo_lines_bt_mono);
fid_bt_tri = fopen(caminho_lines_bt_tri, 'wt');  % Arquivo para linhas BT trifásicas
fid_bt_mono = fopen(caminho_lines_bt_mono, 'wt'); % Arquivo para linhas BT monofásicas/bifásicas
for i = 1:rows_SSDBT 
    codigo= string(SSDBT.COD_ID(i));
    fases=string(SSDBT.FAS_CON(i));
    
    switch fases
        case {"A"}, phase="1"; conex_t=".1"; conex_o=".1";
        case {"B"}, phase="1"; conex_t=".2"; conex_o=".2";
        case {"C"}, phase="1"; conex_t=".3"; conex_o=".3";
        case {"AN"}, phase="2"; conex_t=".1.0"; conex_o=".1.0";
        case {"BN"}, phase="2"; conex_t=".2.0"; conex_o=".2.0";
        case {"CN"}, phase="2"; conex_t=".3.0"; conex_o=".3.0";
        case {"AB"}, phase="2"; conex_t=".1.2"; conex_o=".1.2";
        case {"BC"}, phase="2"; conex_t=".2.3"; conex_o=".2.3";
        case {"CA"}, phase="2"; conex_t=".3.1"; conex_o=".3.1";
        case {"ABC"}, phase="3"; conex_t=".1.2.3"; conex_o=".1.2.3";
        case {"ABN"}, phase="3"; conex_t=".1.2.0"; conex_o=".1.2.0";
        case {"BCN"}, phase="3"; conex_t=".2.3.0"; conex_o=".2.3.0";
        case {"CAN"}, phase="3"; conex_t=".3.1.0"; conex_o=".3.1.0";
        case {"ABCN"}, phase="4"; conex_t=".1.2.3.0"; conex_o=".1.2.3.0";
        otherwise, continue;
    end
    
     trafo_da_linha_atual = string(SSDBT.UNI_TR_MT(i));
    
    % Verifica se o transformador desta linha existe no nosso mapa. Se não, pula.
    if ~isKey(trafo_id_map, trafo_da_linha_atual)
        continue;
    end
    
    % Pega o ID único (T1, M5, etc.) do mapa
    id_unico = trafo_id_map(trafo_da_linha_atual);
    
    barra1 = string(SSDBT.PN_CON_1(i));
    barra2 = string(SSDBT.PN_CON_2(i)); 
    if barra1 == barra2
        continue; 
    end
    
    comprimento = string(SSDBT.COMP(i));
    tipo_condutor = string(SSDBT.TIP_CND(i));

    % Constrói o nome completo das barras
    bus1_final = sprintf('BT_%s_%s%s', barra1, id_unico, conex_o); % conex_o é a conexão de fase (.1.2.3 etc)
    bus2_final = sprintf('BT_%s_%s%s', barra2, id_unico, conex_o);

    if fases == "ABCN" || fases == "ABC" % Escreve no arquivo de linhas trifásicas 
        fprintf(fid_bt_tri,'New line.%s phases=%s bus1=%s bus2=%s length=%s units=m linecode=%s\n\n', codigo, phase, bus1_final, bus2_final, comprimento, tipo_condutor);
    
    else % Escreve no arquivo de linhas monofásicas/bifásicas
        fprintf(fid_bt_mono,'New line.%s phases=%s bus1=%s bus2=%s length=%s units=m linecode=%s\n\n', codigo, phase, bus1_final, bus2_final, comprimento, tipo_condutor);
    end
end 
fclose(fid_mono);
fclose(fid_tri);

% Escrita loads MT
fprintf("\nEscrevendo arquivo %s...",N7)
nome_arquivo_loads_mt = sprintf('%s.dss', N7);
caminho_loads_mt = fullfile(pasta_destino, nome_arquivo_loads_mt);
fid = fopen(caminho_loads_mt, 'wt');
for i = 1:rows_UCMT 
    objeto = string(UCMT.OBJECTID(i));
    ponto = string(UCMT.PN_CON(i));
    kv = (TTEN(string(TTEN.COD_ID) == UCMT.TEN_FORN(i), 2).TEM)/1000;
    
    kw_load = fator_aumento*(sum(UCMT{i,37:48},2) /(30*12*24));
    
    fases = string(UCMT.FAS_CON(i));
    switch fases
        case {"A","B","C","AN","BN","CN"}, phase="1"; conn="wye";
        case {"AB","BC","CA","ABC"}, phase="3"; conn="delta";
        case {"ABN","BCN","CAN","ABCN"}, phase="3"; conn="delta";
        otherwise, phase="1"; conn="wye";
    end

    fprintf(fid,'New load.%s phases=%s bus=%s kv=%g pf=0.92 kw=%g conn=%s daily=A4 model=8 ZIPV=[0.5,0,0.5,0,0,1,0.9]\n\n', objeto, phase, ponto, kv, kw_load, conn);
end   
fclose(fid);

% Escrita loads BT
fprintf("\nEscrevendo arquivos %s e %s...",N6,N14)
nome_arquivo_loads_bt_tri = sprintf('%s.dss', N6);
caminho_loads_bt_tri = fullfile(pasta_destino, nome_arquivo_loads_bt_tri);
nome_arquivo_loads_bt_mono = sprintf('%s.dss', N14);
caminho_loads_bt_mono = fullfile(pasta_destino, nome_arquivo_loads_bt_mono);
fid_loads_tri = fopen(caminho_loads_bt_tri, 'wt');
fid_loads_mono = fopen(caminho_loads_bt_mono, 'wt');
cargas = table('Size',[0 2], 'VariableTypes',{'string','double'},'VariableNames',{'Codigo','KW'});
for i = 1:rows_UCBT
    codigo = string(UCBT.OBJECTID(i));
    fases = string(UCBT.FAS_CON(i));
    ponto = string(UCBT.PN_CON(i));
    trafo_id_da_carga = string(UCBT.UNI_TR_MT(i));

    %Para colocar as cargas de BT no barramento do transformador
    %--------------------------------------------------------------------------------%
    % indi = find(Trafo_MT.Codigo_MT == str2double(UCBT.UNI_TR_MT(i)));
    % ponto = string(Trafo_MT.Poste(indi));
    %--------------------------------------------------------------------------------%

    tip_cc = string(UCBT.TIP_CC(i));

    if contains(tip_cc,"COM"), daily = "Comercial"; 
    elseif contains(tip_cc,"RES"), daily = "Residencial";   
    elseif contains(tip_cc,"IND"), daily = "Industrial";
    elseif contains(tip_cc,"RUR"), daily = "Rural";                     
    elseif contains(tip_cc,"SER"), daily = "Serv_Pub";         
    else, daily = "Residencial"; % Default
    end
    
    switch fases
        case {"A"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
        case {"B"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
        case {"C"}, conex2 = ".3.0"; conn = "wye"; phase = "1";      
        case {"AN"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
        case {"BN"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
        case {"CN"}, conex2 = ".3.0"; conn = "wye"; phase = "1";        
        case {"AB"}, conex2 = ".1.2"; conn = "delta"; phase = "1";
        case {"BC"}, conex2 = ".2.3"; conn = "delta"; phase = "1";
        case {"CA"}, conex2 = ".3.1"; conn = "delta"; phase = "1";        
        case {"ABN"}, conex2 = ".1.2.0"; conn = "wye"; phase = "2";
        case {"BCN"}, conex2 = ".2.3.0"; conn = "wye"; phase = "2";
        case {"CAN"}, conex2 = ".3.1.0"; conn = "wye"; phase = "2";      
        case {"ABC"}, conex2 = ".1.2.3"; conn = "delta"; phase = "3";
        case {"ABCN"}, conex2 = ".1.2.3.0"; conn = "wye"; phase = "3";
    end
    
    linh_trafo = EQTRD(strcmp(EQTRD.UNI_TR_MT, UCBT.UNI_TR_MT{i}), :);
    if isempty(linh_trafo), continue; end

    kv = TTEN(string(TTEN.COD_ID) == linh_trafo.TEN_SEC, 2).TEM/1000;
    kw_load = fator_aumento*(sum(UCBT{i,27:38},2) /(30*12*24));
    cargas = [cargas;{string(codigo),kw_load}];

    if ~isKey(trafo_id_map, trafo_id_da_carga)
          fprintf('AVISO: Carga %s pulada. O transformador ID %s não foi encontrado no mapa.\n', UCBT.OBJECTID(i), trafo_id_da_carga);
        continue;
    end
    
    id_unico = trafo_id_map(trafo_id_da_carga);

    % Constrói o nome da barra final
    bus_final = sprintf('BT_%s_%s%s', ponto, id_unico, conex2);
    
    if phase == "3"
        fprintf(fid_loads_tri,'New load.%s phases=%s bus=%s kv=%g pf=0.92 kw=%g conn=%s daily=%s model=2\n\n', codigo, phase, bus_final, kv, kw_load, conn, daily);
    else
        if linh_trafo.LIG_FAS_S == "ABCN" && (ismember(fases,["AN","BN","CN"]))
            % continue
            kv = kv/sqrt(3);
        end
        if (ismember(linh_trafo.LIG_FAS_S,["AN","BN","CN"])) && (string(linh_trafo.LIG_FAS_T) ~= '0') && (ismember(fases,["AN","BN","CN"]))
            kv = kv/2;
        %     if ~ismember(Trafo_MT_M.Codigo_MT(1:end),linh_trafo.UNI_TR_MT(1))
        %         continue
        %     end
        % else
            %continue
        end
        fprintf(fid_loads_mono,'New load.%s phases=%s bus=%s kv=%g pf=0.92 kw=%g conn=%s daily=%s model=2\n\n', codigo, phase, bus_final, kv, kw_load, conn, daily);
    end
end
fclose(fid_loads_tri);
fclose(fid_loads_mono);

% Escrita PIP (Iluminação Pública)
fprintf("\nEscrevendo arquivos %s e %s...",N9,N13)
nome_arquivo_pip_tri = sprintf('%s.dss', N9);
caminho_pip_tri = fullfile(pasta_destino, nome_arquivo_pip_tri);
nome_arquivo_pip_mono = sprintf('%s.dss', N13);
caminho_pip_mono = fullfile(pasta_destino, nome_arquivo_pip_mono);
fid_pip_tri = fopen(caminho_pip_tri, 'wt');
fid_pip_mono = fopen(caminho_pip_mono, 'wt');
for i = 1:rows_PIP
    codigo = string(PIP.COD_ID(i));
    fases = string(PIP.FAS_CON(i));

    ponto = string(PIP.PN_CON(i)); 
    
    %Para colocar as cargas de BT no barramento do transformador
    %--------------------------------------------------------------------------------%
    % indi = find(Trafo_MT.Codigo_MT == str2double(PIP.UNI_TR_MT(i)));
    % ponto = string(Trafo_MT.Poste(indi));
    %--------------------------------------------------------------------------------%

    switch fases
        case {"A"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
        case {"B"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
        case {"C"}, conex2 = ".3.0"; conn = "wye"; phase = "1";        
        case {"AN"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
        case {"BN"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
        case {"CN"}, conex2 = ".3.0"; conn = "wye"; phase = "1";        
        case {"AB"}, conex2 = ".1.2"; conn = "delta"; phase = "1";
        case {"BC"}, conex2 = ".2.3"; conn = "delta"; phase = "1";
        case {"CA"}, conex2 = ".3.1"; conn = "delta"; phase = "1";        
        case {"ABN"}, conex2 = ".1.2.0"; conn = "wye"; phase = "2";
        case {"BCN"}, conex2 = ".2.3.0"; conn = "wye"; phase = "2";
        case {"CAN"}, conex2 = ".3.1.0"; conn = "wye"; phase = "2";       
        case {"ABC"}, conex2 = ".1.2.3"; conn = "delta"; phase = "3";
        case {"ABCN"}, conex2 = ".1.2.3.0"; conn = "wye"; phase = "3";
        
        otherwise, continue;
    end

    linh_trafo = EQTRD(strcmp(EQTRD.UNI_TR_MT, PIP.UNI_TR_MT{i}), :);
    if isempty(linh_trafo), continue; end

    kv = TTEN(string(TTEN.COD_ID) == PIP.TEN_FORN(i), 2).TEM/1000;
    kw_load = fator_aumento*(sum(PIP{i,27:38},2) /(30*12*24));

    trafo_id_da_carga = string(PIP.UNI_TR_MT(i));
    
    % Se o trafo não estiver no mapa, pula a carga
    if ~isKey(trafo_id_map, trafo_id_da_carga)
          fprintf('AVISO: Carga %s pulada. O transformador ID %s não foi encontrado no mapa.\n', UCBT.OBJECTID(i), trafo_id_da_carga);
        continue;
    end
    
    id_unico = trafo_id_map(trafo_id_da_carga);

    % Constrói o nome da barra final
    bus_final = sprintf('BT_%s_%s%s', ponto, id_unico, conex2);
    
    if phase == "3"
        fprintf(fid_pip_tri,'New load.%s phases=%s bus=%s kv=%g pf=0.92 kw=%g conn=%s daily=%s model=1\n\n', codigo, phase, bus_final, kv, kw_load, conn, daily);
    else
        if linh_trafo.LIG_FAS_S == "ABCN" && (ismember(fases,["AN","BN","CN"]))
            %continue
            kv = kv/sqrt(3);
        end
        if (ismember(linh_trafo.LIG_FAS_S,["AN","BN","CN"])) && (string(linh_trafo.LIG_FAS_T) ~= '0') && (ismember(fases,["AN","BN","CN"]))
            kv = kv/2;
        end
        fprintf(fid_pip_mono,'New load.%s phases=%s bus=%s kv=%g pf=0.92 kw=%g conn=%s daily=%s model=1\n\n', codigo, phase, bus_final, kv, kw_load, conn, daily);
    end
end
fclose(fid_pip_mono);
fclose(fid_pip_tri);

% Escrita eletropostos BT
fprintf("\nEscrevendo arquivo %s...",N10)
nome_arquivo_el = sprintf('%s.dss', N10);
caminho_el = fullfile(pasta_destino, nome_arquivo_el);
fid = fopen(caminho_el, 'wt');
demanda_EL = EL.Potencia_Agregada_kW';
p_nom_EL = max(demanda_EL); %Potência nominal [kW]
energia_EL = sum(EL.Potencia_Agregada_kW);
demanda_EL = -demanda_EL./p_nom_EL;

% Define o nome base e o nome completo da curva de carga para ser usado em ambos os locais
nome_posto = 'EL_Residencial';
nome_completo_curva = sprintf('Curva_storage_%s', nome_posto);

% Escreve o Loadshape usando o nome completo
fprintf(fid, 'New Loadshape.%s npts=24 interval=1 mult=[', nome_completo_curva);
fprintf(fid, ' %.4f', demanda_EL); % Escreve os multiplicadores calculados
fprintf(fid, ' ]\n\n');

for i = 1:rows_UCBT
    if rand < PROB_EL
        codigo = string(UCBT.OBJECTID(i));
        fases = string(UCBT.FAS_CON(i));
        ponto = string(UCBT.PN_CON(i));
        trafo_id_da_carga = string(UCBT.UNI_TR_MT(i));

        %Para colocar as cargas de BT no barramento do transformador
        %--------------------------------------------------------------------------------%
        % indi = find(Trafo_MT.Codigo_MT == str2double(UCBT.UNI_TR_MT(i)));
        % ponto = string(Trafo_MT.Poste(indi));
        %--------------------------------------------------------------------------------%

        switch fases
            case {"A"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
            case {"B"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
            case {"C"}, conex2 = ".3.0"; conn = "wye"; phase = "1";
            case {"AN"}, conex2 = ".1.0"; conn = "wye"; phase = "1";
            case {"BN"}, conex2 = ".2.0"; conn = "wye"; phase = "1";
            case {"CN"}, conex2 = ".3.0"; conn = "wye"; phase = "1";
            case {"AB"}, conex2 = ".1.2"; conn = "delta"; phase = "1";
            case {"BC"}, conex2 = ".2.3"; conn = "delta"; phase = "1";
            case {"CA"}, conex2 = ".3.1"; conn = "delta"; phase = "1";
            case {"ABN"}, conex2 = ".1.2.0"; conn = "wye"; phase = "2";
            case {"BCN"}, conex2 = ".2.3.0"; conn = "wye"; phase = "2";
            case {"CAN"}, conex2 = ".3.1.0"; conn = "wye"; phase = "2";
            case {"ABC"}, conex2 = ".1.2.3"; conn = "delta"; phase = "3";
            case {"ABCN"}, conex2 = ".1.2.3.0"; conn = "wye"; phase = "3";
            otherwise, continue; % Pula se a fase não for reconhecida
        end

        linh_trafo = EQTRD(strcmp(EQTRD.UNI_TR_MT, UCBT.UNI_TR_MT{i}), :);
        if isempty(linh_trafo), continue; end

        if ~isKey(trafo_id_map, trafo_id_da_carga)
            fprintf('AVISO: Eletroposto para carga %s pulado. O transformador ID %s não foi encontrado no mapa.\n', codigo, trafo_id_da_carga);
            continue;
        end

        kv = TTEN(string(TTEN.COD_ID) == linh_trafo.TEN_SEC, 2).TEM/1000;
        if linh_trafo.LIG_FAS_S == "ABCN" && (ismember(fases,["AN","BN","CN"]))
            kv = kv/sqrt(3);
        end
        if (ismember(linh_trafo.LIG_FAS_S,["AN","BN","CN"])) && (string(linh_trafo.LIG_FAS_T) ~= '0') && (ismember(fases,["AN","BN","CN"]))
            kv = kv/2;
        end

        id_unico = trafo_id_map(trafo_id_da_carga);
        bus_final = sprintf('BT_%s_%s%s', ponto, id_unico, conex2);

        % CORREÇÃO: A propriedade 'daily' deve referenciar o nome completo da Loadshape criada
        fprintf(fid, 'New Storage.Carregador_%s Bus1=%s Phases=%s Conn=%s kV=%g kWrated=%.2f kWhrated=%.2f PF=1.0 %%stored=0 %%reserve=0 %%charge=100 %%discharge=0 dispmode=follow %%EffCharge=95 daily=%s\n\n', ...
        codigo, bus_final, phase, conn, kv, p_nom_EL, energia_EL, nome_completo_curva);
    end
end
fclose(fid);

fprintf('\nIniciando a geração do arquivo de coordenadas...\n');

% Nome do arquivo de coordenadas e da planilha de saída
arquivo_coordenadas_excel = 'Coordenadas_MT.xlsx';
nome_arquivo_saida = sprintf('Coordenadas_%s.dss', Ali);
caminho_saida_coords = fullfile(pasta_destino, nome_arquivo_saida);

try
    % 1. Ler a tabela de coordenadas
    TabelaCoords_Raw = readtable(arquivo_coordenadas_excel);
    
    % 2. Filtrar a tabela para conter apenas dados do alimentador em análise
    TabelaCoords = TabelaCoords_Raw(strcmp(TabelaCoords_Raw.CTMT, Ali), :);
    
    if isempty(TabelaCoords)
        warning('Nenhuma coordenada encontrada para o alimentador %s no arquivo %s.', Ali, arquivo_coordenadas_excel);
    else
        % 3. Criar um mapa para armazenar as coordenadas de cada poste único
        %    Isso é eficiente para evitar buscas repetidas.
        mapa_coords = containers.Map('KeyType', 'double', 'ValueType', 'any');
        
        % 4. Iterar sobre cada linha da tabela de segmentos para extrair as coordenadas
        for i = 1:height(TabelaCoords)
            wkt_geom = TabelaCoords.wkt_geom{i}; % Pega a string de geometria
            pn1 = TabelaCoords.PN_CON_1(i);
            pn2 = TabelaCoords.PN_CON_2(i);
            
            % Usar expressão regular para encontrar todos os números na string
            numeros = regexp(wkt_geom, '-?\d+\.\d+', 'match');
            
            % Se encontramos os 4 números (X1, Y1, X2, Y2)
            if numel(numeros) >= 4
                coords_pn1 = [str2double(numeros{1}), str2double(numeros{2})]; % [X, Y] do PN_CON_1
                coords_pn2 = [str2double(numeros{3}), str2double(numeros{4})]; % [X, Y] do PN_CON_2
                
                % Adiciona ao mapa se a chave (ID do poste) ainda não existir.
                % A primeira vez que um poste aparece, suas coordenadas são salvas.
                if ~isKey(mapa_coords, pn1)
                    mapa_coords(pn1) = coords_pn1;
                end
                
                if ~isKey(mapa_coords, pn2)
                    mapa_coords(pn2) = coords_pn2;
                end
            end
        end
        
        % 5. Escrever o arquivo de saída .dss
        fid_coords = fopen(caminho_saida_coords, 'wt');
        
        % Pega todos os postes únicos que foram mapeados
        postes_unicos = cell2mat(keys(mapa_coords));
        
        for i = 1:length(postes_unicos)
            poste_id = postes_unicos(i);
            coordenadas = mapa_coords(poste_id);
            cord_x = coordenadas(1);
            cord_y = coordenadas(2);
            
            fprintf(fid_coords, '%d %f %f\n', poste_id, cord_x, cord_y);
        end
        
        fclose(fid_coords);
        fprintf('Arquivo de coordenadas "%s" gerado com sucesso!\n', nome_arquivo_saida);
    end
    
catch ME
    warning('Ocorreu um erro ao processar o arquivo de coordenadas: %s', ME.message);
    warning('Verifique se o arquivo "%s" está na pasta correta.', arquivo_coordenadas_excel);
end
fclose('all');

disp('Iniciando a geração do arquivo de coordenadas para a rede de Baixa Tensão...');

% Nome do arquivo de coordenadas de BT
arquivo_coordenadas_bt_excel = 'Coordenadas_BT.xlsx';
nome_arquivo_saida_bt = sprintf('Coordenadas_%s_BT.dss', Ali);
caminho_saida_coords_bt = fullfile(pasta_destino, nome_arquivo_saida_bt);

% Verifica se a variável 'trafo_id_map' existe, pois ela é essencial
if ~exist('trafo_id_map', 'var')
    error('A variável "trafo_id_map" não foi encontrada. Coloque este bloco de código após a seção de processamento de transformadores.');
end

try
    % 1. Ler a tabela de coordenadas de Baixa Tensão
    TabelaCoordsBT_Raw = readtable(arquivo_coordenadas_bt_excel);
    
    % 2. Filtrar a tabela para o alimentador em análise
    TabelaCoordsBT = TabelaCoordsBT_Raw(strcmp(TabelaCoordsBT_Raw.CTMT, Ali), :);
    
    if isempty(TabelaCoordsBT)
        warning('Nenhuma coordenada de Baixa Tensão encontrada para o alimentador %s no arquivo %s.', Ali, arquivo_coordenadas_bt_excel);
    else
        % 3. Criar um mapa para armazenar as coordenadas de cada barra de BT única
        mapa_coords_bt = containers.Map('KeyType', 'char', 'ValueType', 'any');
        
        % 4. Iterar sobre cada linha da tabela para extrair coordenadas
        for i = 1:height(TabelaCoordsBT)
            wkt_geom_bt = TabelaCoordsBT.wkt_geom{i};
            pn1_bt = TabelaCoordsBT.PN_CON_1(i);
            pn2_bt = TabelaCoordsBT.PN_CON_2(i);
            
            % --- CORREÇÃO APLICADA AQUI ---
            % Usa parênteses (i) para acessar dados de um vetor numérico
            trafo_code = string(TabelaCoordsBT.UNI_TR_MT(i));
            
            if ~isKey(trafo_id_map, trafo_code)
                continue;
            end
            
            id_unico_trafo = trafo_id_map(trafo_code);
            
            nome_barra1 = sprintf('BT_%d_%s', pn1_bt, id_unico_trafo);
            nome_barra2 = sprintf('BT_%d_%s', pn2_bt, id_unico_trafo);
            
            numeros_bt = regexp(wkt_geom_bt, '-?\d+\.\d+', 'match');
            
            if numel(numeros_bt) >= 4
                coords_pn1_bt = [str2double(numeros_bt{1}), str2double(numeros_bt{2})];
                coords_pn2_bt = [str2double(numeros_bt{3}), str2double(numeros_bt{4})];
                
                if ~isKey(mapa_coords_bt, nome_barra1)
                    mapa_coords_bt(nome_barra1) = coords_pn1_bt;
                end
                
                if ~isKey(mapa_coords_bt, nome_barra2)
                    mapa_coords_bt(nome_barra2) = coords_pn2_bt;
                end
            end
        end
        
        % 5. Escreve em um novo arquivo .dss
        fid_coords_bt = fopen(caminho_saida_coords_bt, 'wt');
        
        barras_bt_unicas = keys(mapa_coords_bt);
        
        for i = 1:length(barras_bt_unicas)
            nome_barra = barras_bt_unicas{i};
            coordenadas = mapa_coords_bt(nome_barra);
            cord_x = coordenadas(1);
            cord_y = coordenadas(2);
            
            fprintf(fid_coords_bt, '%s %f %f\n', nome_barra, cord_x, cord_y);
        end
        
        fclose(fid_coords_bt);
        fprintf('Arquivo de coordenadas de BT "%s" gerado com sucesso!\n', nome_arquivo_saida_bt);
    end
    
catch ME
    warning('Ocorreu um erro ao processar o arquivo de coordenadas de BT: %s', ME.message);
    fprintf(2, 'O erro ocorreu na linha %d do arquivo %s.\n', ME.stack(1).line, ME.stack(1).name); % Linha para depuração
    warning('Verifique se o arquivo "%s" está na pasta correta.', arquivo_coordenadas_bt_excel);
end
fclose('all');
disp('Arquivos .dss gerados com sucesso!');
