clc
close all
clear

tam = 20;
ano_max = 2100;
%% Lendo os dados
dados_demanda = readtable('D:\1_UFOP\ELÉTRICA\9º periodo\TCC 1\AUMENTO DE DEMANDA\Dados_Historicos.xlsx');

demanda = dados_demanda.JMLT308;
anos = dados_demanda.ANO;
id_anos = (1:length(dados_demanda.ANO))';

% cftool(anos,demanda);
[fitresult, gof] = createFit(id_anos, demanda);


anos_proj = (dados_demanda.ANO(end)+1:ano_max)'; 
id_anos_proj = (length(id_anos)+1:length(anos_proj)+length(id_anos));
demanda_proj = feval(fitresult, id_anos_proj);


figure('Name','Projeção de Demanda do Alimentador')
plot(anos, demanda, 'bo', 'MarkerFaceColor','b')          % dados reais
hold on
plot(anos_proj, demanda_proj, 'r*-', 'LineWidth',1.5)     % projeção
xlabel('Ano')
ylabel('Demanda (kW)')
legend('Histórico','Projeção','Location','NorthWest')
%title('Projeção de Demanda do Alimentador')
grid on
hold off
ax = gca;
ax.FontSize = tam-2;

figure
plot(anos, demanda/demanda(3), 'bo', 'MarkerFaceColor','b')          % dados reais
hold on
plot(anos_proj, demanda_proj/demanda(3), 'r*-', 'LineWidth',1.5)     % projeção
xlabel('Ano')
ylabel('Demanda (MW)')
legend('Histórico','Projeção','Location','NorthWest')
title('Projeção de Demanda do Alimentador')

%% Projeção de carros

%Dados Históricos dos Veículos Elétricos (VEs)
anos_hist_ev = [2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023]'; % Anos
taxa_ano = [0.03, 0.03, 0.05, 0.15, 0.16, 0.44, 1.01, 1.77, 2.51, 3.99]'; % Taxa de VEs da frota total em %
dados_brutos = [1, 1, 1, 3, 4, 12, 20, 35, 49, 78]'; % Numero de VEs na frota total em milhares

id_anos_hist_ev = (1:length(anos_hist_ev))';
anos_proj_ve = (anos_hist_ev(end)+1:ano_max)';
id_anos_proj_ve = (length(anos_hist_ev)+1 : length(anos_hist_ev)+length(anos_proj_ve))';
% cftool(id_anos_hist_ev,taxa_ano);

[fitresult, gof] = createFit4(id_anos_hist_ev, taxa_ano);
taxa_proj = feval(fitresult, id_anos_proj_ve);

figure('Name','Projeção da Taxa de Emplacamentos de Veículos Elétricos')
plot(anos_hist_ev, taxa_ano, 'bo', 'MarkerFaceColor','b', 'DisplayName','Histórico')
hold on
plot(anos_proj_ve, taxa_proj, 'r*-', 'LineWidth',1.5, 'DisplayName','Projeção')
xlabel('Ano')
ylabel('Taxa de VEs (%)')
legend('Location','NorthWest')
%title('Projeção da Taxa de Emplacamentos de Veículos Elétricos')
grid on
hold off
ax = gca;
ax.FontSize = tam-2;

%Frota de automoveis
anos_auto = (2013:2025)';
quantidade_auto = [23214;24536;25305;25795;26570;27571;28141;28849;29754;30374;30794;32184;32629]/9;

id_anos_auto = (1:length(anos_auto))';

anos_auto_proj = (anos_auto(end)+1:ano_max)';
id_anos_auto_proj = (length(anos_auto)+1:length(anos_auto_proj)+length(anos_auto))';

[fitresult, gof] = createFit(id_anos_auto, quantidade_auto);

quantidade_auto_proj = feval(fitresult, id_anos_auto_proj);

figure
plot(anos_auto, quantidade_auto, 'bo', 'MarkerFaceColor','b')          % dados reais
hold on
plot(anos_auto_proj, quantidade_auto_proj, 'r*-', 'LineWidth',1.5)     % projeção
xlabel('Ano')
ylabel('Demanda (MW)')
legend('Histórico','Projeção','Location','NorthWest')
title('Projeção da Demanda de automeoveis')
grid on
hold off

Casos = ['Cenário1';'Cenário2';'Cenário3'];
Taxas = [10;50;100];
ind = zeros(length(Taxas),1);
for n = 1:length(Taxas)
    [~,ind(n)] = min(abs(taxa_proj-Taxas(n)));
end
Ano_Ocorrencia = anos_proj_ve(ind);
Aumento_Demanda_cenario = demanda_proj(ismember(string(anos_proj),string(Ano_Ocorrencia)))/demanda(3);
Demanda_MVA = demanda_proj(ismember(string(anos_proj),string(Ano_Ocorrencia)));
Num_Automoveis = round(quantidade_auto_proj(ismember(string(anos_auto_proj),string(Ano_Ocorrencia))))

Resultados = table(Casos,Taxas,Ano_Ocorrencia,Aumento_Demanda_cenario,Demanda_MVA,Num_Automoveis)

% writetable(Resultados,'Projeção_JMLT308.xlsx')

%% ========================================================================
%  SALVANDO RESULTADOS EM PDF (Otimizado com exportgraphics)
% ========================================================================
disp('Salvando figuras em PDF...');

figuras = findobj('Type', 'figure'); 
% OBS: Se quiser salvar apenas a figura 5 como estava no código original, 
% figuras = findobj('Type', 'figure', 'Number', 9);

pastaDestino = 'Graficos_TCC_PDF_Final_2';
if ~exist(pastaDestino, 'dir')
    mkdir(pastaDestino);
end

for i = 1:length(figuras)
    fig = figuras(i); 

    % Maximiza a janela da figura
    fig.WindowState = 'maximized';
    drawnow; % Aguarda a atualização gráfica na tela
    
    nomeBase = strrep(fig.Name, ' ', '_'); 
    if isempty(nomeBase)
        nomeBase = sprintf('Figura_%d', fig.Number);
    end
    nomeArquivoPDF = fullfile(pastaDestino, [nomeBase '.pdf']);
    
    % Exporta o gráfico ajustando automaticamente margens e tamanho
    exportgraphics(fig, nomeArquivoPDF, 'ContentType', 'vector');
    
    disp(['Salvo: ' nomeArquivoPDF]);
end

disp('Todos os gráficos foram exportados para PDF com sucesso.');