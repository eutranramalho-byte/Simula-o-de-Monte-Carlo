import os
import sys
import traci
import pandas as pd

# --- CONFIGURAÇÕES GERAIS DA SIMULAÇÃO ---
SUMO_HOME = "C:/Program Files (x86)/Eclipse/Sumo"
sumo_config_file = "C:/Users/Eutran/Sumo/MAPA_JM/osm_Taxis.sumocfg"
SIMULATION_DURATION_SEC = 100000

# --- INICIALIZAÇÃO DA SIMULAÇÃO ---
tools_path = os.path.join(SUMO_HOME, 'tools')
if tools_path not in sys.path:
    sys.path.append(tools_path)

sumo_binary = os.path.join(SUMO_HOME, "bin", "sumo-gui")
sumo_command = [sumo_binary, '-c', sumo_config_file, '--start', '--quit-on-end', '--time-to-teleport', '-1']

print("Iniciando a simulação no SUMO...")
try:
    traci.start(sumo_command)
    print("Simulação iniciada.")
except traci.TraCIException as e:
    print(f"Erro ao iniciar o TraCI: {e}")
    sys.exit(1)

# --- DICIONÁRIOS PARA ARMAZENAR OS DADOS ---
# MODIFICADO: Agora vamos rastrear a distância de TODOS os veículos que já existiram
distancias_finais = {}
classes_veiculos = {}

# --- LOOP PRINCIPAL DA SIMULAÇÃO ---
for step in range(SIMULATION_DURATION_SEC):
    traci.simulationStep()

    # Rastreia a classe e a distância de todos os veículos que entram e se movem
    veiculos_ativos = traci.vehicle.getIDList()
    for vehicle_id in veiculos_ativos:
        try:
            # Se o veículo é novo, armazena sua classe
            if vehicle_id not in classes_veiculos:
                classes_veiculos[vehicle_id] = traci.vehicle.getVehicleClass(vehicle_id)

            # Atualiza a distância percorrida para todos os veículos ativos
            distancia_metros = traci.vehicle.getDistance(vehicle_id)
            distancias_finais[vehicle_id] = distancia_metros / 1000.0  # Converte para km
        except traci.TraCIException:
            # O veículo pode ter acabado de sair da simulação neste passo
            pass

# --- FINALIZAÇÃO DA SIMULAÇÃO ---
traci.close()
print(f"\nSimulação de {SIMULATION_DURATION_SEC / 3600:.1f}h finalizada.")

# --- NOVA LÓGICA DE GERAÇÃO DO ARQUIVO DE SAÍDA ---
print("\nGerando arquivo de saída com as distâncias finais dos veículos...")

# Dicionário para agregar distâncias (se necessário para veículos de fluxo)
distancias_agregadas = {}
classes_agregadas = {}

# Itera sobre TODOS os veículos que foram rastreados durante a simulação
for vehicle_id, distancia_km in distancias_finais.items():
    vehicle_class = classes_veiculos.get(vehicle_id)

    # Filtra para incluir apenas 'passenger' e 'taxi'
    if vehicle_class in ['passenger', 'taxi']:
        # Lógica para agregar distâncias de veículos de um mesmo fluxo (ex: 'flow.0', 'flow.1')
        base_id = vehicle_id.split(':')[0] if ':' in vehicle_id else vehicle_id

        distancia_total_anterior = distancias_agregadas.get(base_id, 0)
        distancias_agregadas[base_id] = distancia_total_anterior + distancia_km

        if base_id not in classes_agregadas:
            classes_agregadas[base_id] = vehicle_class

if distancias_agregadas:
    lista_de_dados = []
    for base_id, distancia_total in distancias_agregadas.items():
        vehicle_class = classes_agregadas.get(base_id, 'desconhecida')
        lista_de_dados.append({
            'ID_Base_Veiculo': base_id,
            'Classe': vehicle_class,
            'Distancia_Total_Agregada_km': distancia_total
        })

    df_distancias = pd.DataFrame(lista_de_dados)

    output_filename = "distancias_finais_veiculos_e_taxis.csv"
    df_distancias.to_csv(output_filename, index=False)

    print(f"Arquivo '{output_filename}' gerado com sucesso!")
    print(
        f"Total de {len(distancias_agregadas)} veículos únicos (automóveis e táxis) tiveram suas distâncias registradas.")
else:
    print("Nenhum automóvel ou táxi foi detectado na simulação para gerar o relatório.")