import os
import sys
import traci
import pandas as pd

# --- CONFIGURAÇÕES GERAIS DA SIMULAÇÃO ---
SUMO_HOME = "C:/Program Files (x86)/Eclipse/Sumo"
sumo_config_file = "C:/Users/Eutran/Sumo/MAPA_JM/osm.sumocfg"
SIMULATION_DURATION_SEC = 100000

# --- INICIALIZAÇÃO DA SIMULAÇÃO ---
tools_path = os.path.join(SUMO_HOME, 'tools')
if tools_path not in sys.path:
    sys.path.append(tools_path)

sumo_binary = os.path.join(SUMO_HOME, "bin", "sumo-gui")
sumo_command = [sumo_binary, '-c', sumo_config_file, '--start', '--quit-on-end', '--time-to-teleport', '-1']

print("Iniciando a simulação no SUMO...")
traci.start(sumo_command)
print("Simulação iniciada.")

# --- DICIONÁRIOS PARA ARMAZENAR OS DADOS ---
distancias_atuais = {}
classes_veiculos = {}
resultados_veiculos = {}

# --- LOOP PRINCIPAL DA SIMULAÇÃO ---
for step in range(SIMULATION_DURATION_SEC):
    traci.simulationStep()

    # Registra a classe dos veículos que acabaram de entrar na simulação
    veiculos_partiram = traci.simulation.getDepartedIDList()
    for vehicle_id in veiculos_partiram:
        try:
            classes_veiculos[vehicle_id] = traci.vehicle.getVehicleClass(vehicle_id)
        except traci.TraCIException:
            pass

    # LÓGICA DE MONITORAMENTO DE DISTÂNCIA
    veiculos_ativos = traci.vehicle.getIDList()
    for vehicle_id in veiculos_ativos:
        try:
            distancia_metros = traci.vehicle.getDistance(vehicle_id)
            distancias_atuais[vehicle_id] = distancia_metros
        except traci.TraCIException:
            pass

    # LÓGICA PARA REGISTRAR CHEGADAS E AGREGAR DADOS
    veiculos_chegaram = traci.simulation.getArrivedIDList()
    for vehicle_id in veiculos_chegaram:
        vehicle_class = classes_veiculos.get(vehicle_id)

        if vehicle_class == 'passenger':
            distancia_viagem_metros = distancias_atuais.get(vehicle_id, 0)
            distancia_viagem_km = distancia_viagem_metros / 1000.0

            base_id = vehicle_id.split(':')[0]

            # <--- MODIFICAÇÃO 2: Atualizar distância e tempo no novo dicionário
            # Garante que o ID base já exista no dicionário
            if base_id not in resultados_veiculos:
                resultados_veiculos[base_id] = {'distancia_km': 0, 'tempo_final_s': 0}

            # Soma a distância da viagem atual
            resultados_veiculos[base_id]['distancia_km'] += distancia_viagem_km
            # Atualiza (sobrescreve) o tempo de chegada. O último valor será o final.
            resultados_veiculos[base_id]['tempo_final_s'] = step

            dist_total = resultados_veiculos[base_id]['distancia_km']
            print(f"Tempo: {step}s | Viagem de '{vehicle_id}' concluída (+{distancia_viagem_km:.2f} km). "
                  f"Distância total para '{base_id}': {dist_total:.2f} km.")

        # LIMPAR MEMÓRIA (dos dicionários de rastreamento)
        if vehicle_id in distancias_atuais:
            del distancias_atuais[vehicle_id]
        if vehicle_id in classes_veiculos:
            del classes_veiculos[vehicle_id]

# --- FINALIZAÇÃO DA SIMULAÇÃO ---
traci.close()
print(f"\nSimulação de {SIMULATION_DURATION_SEC / 3600:.1f}h finalizada.")

# --- GERAÇÃO DO ARQUIVO DE SAÍDA ---
print("\nGerando arquivo de saída com os dados agregados dos veículos...")
# <--- MODIFICAÇÃO 3: Adaptar a criação do DataFrame para o novo formato do dicionário
if resultados_veiculos:
    # Converte o dicionário aninhado em um DataFrame
    df_resultados = pd.DataFrame.from_dict(resultados_veiculos, orient='index')

    # Renomeia as colunas e o índice para um formato mais claro
    df_resultados.reset_index(inplace=True)
    df_resultados.rename(columns={
        'index': 'ID_Veiculo',
        'distancia_km': 'Distancia_Total_km',
        'tempo_final_s': 'Tempo_Final_s'
    }, inplace=True)

    output_filename = "resultados_veiculos.csv"
    df_resultados.to_csv(output_filename, index=False)

    print(f"Arquivo '{output_filename}' gerado com sucesso!")
    print(f"Total de {len(resultados_veiculos)} veículos únicos (automóveis) tiveram seus dados registrados.")
else:
    print("Nenhum automóvel completou viagens para gerar o relatório.")